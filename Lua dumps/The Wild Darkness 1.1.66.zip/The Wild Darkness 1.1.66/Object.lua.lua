Object={
defFade=0.05,
mcNickPath="\236\152\164\235\184\140\236\160\157\237\138\184\236\157\180\235\166\132",
mcFloatMenu="\236\152\164\235\184\140\236\160\157\237\138\184\235\169\148\235\137\1801\236\185\1842",
mcFloatMenuSize={40,70};
height=_Z.tileH/4,
mcNickOffset={0,-_Z.tileH/4},
dieT=0.6,
slotParticleBurn="particle_fire",
isObject=true,
spineScale=1,
};

function Object:new(o)
o=o or{};
setmetatable(o,self)
self.__index=self
return o
end


function Object:init(guid,sdata,loaded)
assert(sdata.x and sdata.y,sdata);
self.tile={x=sdata.x,y=sdata.y};
self.front={x=sdata.x,y=sdata.y};
self.center={};
self.center.x,self.center.y=world.ground:TileToMap(self.tile.x,self.tile.y);
self.guid=guid;
self.pos={};
self.pos.x,self.pos.y=world.ground:TileToMap(self.tile.x,self.tile.y);
self.canvas=world.ground.layer:CreateEmptyMovieClip("");
self.ui=world.ground.ui:CreateEmptyMovieClip("");
self.sdata=sdata;
self.tb=objecttable[self.sdata.id];
if self.sdata.state=="\236\153\132\235\163\140"and self.tb["\236\153\132\235\163\140\236\160\156\237\149\156"]and self.tb["\236\153\132\235\163\140\236\160\156\237\149\156"]<0 then
self.sdata.state=nil;
end
if self.tb["\236\130\173\236\160\156"]then
self.sdata.willDie=self.sdata.willDie or self.tb["\236\130\173\236\160\156"];
end
assert(self.tb,self.sdata.id);
self.timer=Timer();

if self.tb["\237\148\188\234\178\169\234\176\128\235\138\165"]then
self.data=monstertable[self.tb["\237\148\188\234\178\169\234\176\128\235\138\165"]];
elseif table.find(self.tb["\235\169\148\235\137\180"],"\235\169\148\235\137\180_\235\182\128\236\136\152\234\184\176")then
self.data=monstertable["\236\152\164\235\184\140\236\160\157\237\138\184"];
end

if self.tb.LifeT then
self.sdata.LifeT=countkcc(self.tb.LifeT);
end

if self.tb.HP then
self.sdata.HP=self.sdata.HP or self.tb.HP;
end


if self.tb.spine then
local sk,error=spine.buildSkeleton(
"media/spine/"..self.tb.spine..".json",
"media/spine/"..self.tb.spine..".atlas",
1)
assert(sk,error);
local obj=self.canvas:CreateObject(sk,"_");
local this=self;
obj:SetPos(0,0);
obj:SetScale(self.spineScale or 1,self.spineScale or 1);
self.mc=obj;
self.skeleton=sk;
sk:enableEvent("onAnimationEvent");
sk:setAnimation(0,self.tb["\234\184\176\235\179\184 \236\149\160\235\139\136"],true);
if _G.type(self.tb.skin)=="table"then
self.sdata.skin=self.sdata.skin or table.choice(self.tb.skin);
end
do
local skin=self.tb.skin;
if self.tb["\236\167\128\236\151\173\235\179\132skin"]then
local area=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\167\128\236\151\173"];
skin=self.tb["\236\167\128\236\151\173\235\179\132skin"][area]or skin;
end
sk:setSkin(self.sdata.skin or skin or"default");
end
sk:update(0);

if self.tb.attachment then
if _G.type(self.tb.attachment)=="table"then
self.sdata.attachment=self.sdata.attachment or table.choice(self.tb.attachment);
end
sk:setAttachment(nil,self.sdata.attachment or self.tb.attachment);
end
for k,v in safe_pairs(self.sdata.attachments)do
sk:setAttachment(k,v);
end
function sk:onAnimationEvent(...)
this:onAnimationEvent(...)
end

do
local i=1;
while true do
local name=sk:getSlotName(i);
if not name then
break;
end
if name==self.slotParticleBurn or string.find(name,"(d)",nil,true)then
sk:setSlotZ(i,_Z.Object_FrontZ+i);


end
if self.tb["\236\138\172\235\161\175\235\172\188\235\134\146\236\157\180"]and self.tb["\236\138\172\235\161\175\235\172\188\235\134\146\236\157\180"][name]then

sk:setSlotH(i,self.tb["\236\138\172\235\161\175\235\172\188\235\134\146\236\157\180"][name]);
end
i=i+1;
end
end












end

if _Z.ShowObjectNick and self.mcNickPath~=""then
self.mcNick=self.ui:AddSymbol(self.mcNickPath,"_");
if self.mcNick.nick then

if self.sdata.key and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.key]then
self.mcNick.nick:SetText(ToDoorKeyName(self:getName(),_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.key]));
elseif self:getName()then
self.mcNick.nick:SetText(self:getName());
end
end
if self.mcNick.guid then
self.mcNick.guid:SetText(guid);
end
self.mcNick:SetPos(self.mcNickOffset[1],(self.tb["\235\139\137\235\134\146\236\157\180"]or 0)+self.mcNickOffset[2]);
self.mcNick:SetZOrder(99999);
end


if self.tb["\235\176\169\237\150\165"]then
if not self.sdata.a then
if self.tb["\235\176\169\237\150\165"]==1 then
self.sdata.a="left";
elseif self.tb["\235\176\169\237\150\165"]==2 then
self.sdata.a=table.choice({"right","left"});
elseif self.tb["\235\176\169\237\150\165"]=="\235\172\184R"then
if world.ground:getTile(self.tile.x+1,self.tile.y)==TT.WALL then
self.sdata.a="left";
else
self.sdata.a="right";
end
elseif self.tb["\235\176\169\237\150\165"]=="\235\172\184L"then
if world.ground:getTile(self.tile.x+1,self.tile.y)==TT.WALL then
self.sdata.a="right";
else
self.sdata.a="left";
end
end
end
end

if(self.sdata["\236\157\128\235\176\128\235\143\132"]or 0)>0 then
self:undetect();
end
if self.tb["\237\148\140\235\160\136\236\157\180\236\150\180 \236\149\161\236\133\152 \237\154\159\236\136\152"]then
self.sdata.touchC=self.sdata.touchC or self.tb["\237\148\140\235\160\136\236\157\180\236\150\180 \236\149\161\236\133\152 \237\154\159\236\136\152"];
end
self:setArrow(self.sdata.a or"right");
self:updateMC();
self:updateTileProp();
self:place();

if self.skeleton then
self.skeleton:setUpdateWhenRender(false);
self.skeleton:update(0);
self.skeleton:setUpdateWhenRender(true);
local x,y,cx,cy=self.skeleton:getBound();

local l,t=math.min(x,-_Z.tileW/2),math.min(y,-_Z.tileH/2);
local r,b=math.max(x+cx,_Z.tileW/2),math.max(y+cy,_Z.tileH/2);
self.mc:SetBound(l,t,r-l,b-t);
end

if self.tb.stickyO then
self:sticky();
end

self:idle(loaded);

if self.sdata.menuCool then
for k,v in pairs(self.sdata.menuCool)do
if self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"]and self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"][k]then
self:applyOption(1,self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"][k]);
end
end
end

self:onResetTurn(0);

if self.skeleton then
self.skeleton:setUpdateWhenRender(false);
self.skeleton:update(0);
self.skeleton:setMix(nil,nil,self.defFade);
self.skeleton:setUpdateWhenRender(true);
end
end


function Object:isOppositeDir(from,cx,cy)
end

function Object:getName()
return self.sdata.name or self.tb.name;
end

function Object:getNearFront()
if self.arrow=="left"then
return self.tile.x+1,self.tile.y;
else
return self.tile.x,self.tile.y+1;
end
end

function Object:undetect()
if self.mc then
self.mc:SetVisible(false);
end
end

function Object:detect()
if self.sdata["\236\157\128\235\176\128\235\143\132"]then
self.sdata["\236\157\128\235\176\128\235\143\132"]=nil;
self.mc:SetVisible(true);
end
end

function Object:isDetected()
return(self.sdata["\236\157\128\235\176\128\235\143\132"]or 0)<=0;
end

function Object:onAnimationEvent(track,name,type,evt,loop,param1)



if type=="START"then
self.skeleton:setUpdateWhenRender(loop>0);
elseif type=="COMPLETE"and loop==0 then

self.skeleton:setUpdateWhenRender(false);
if self.eventCB then
local cb=self.eventCB;
self.eventCB=nil;
cb(type);
end
if name==self.tb["\235\182\136\237\131\128\235\138\148 \236\149\160\235\139\136"]then
if self.tb["\235\182\136\237\131\144\236\160\132\236\157\180"]then
local o=world:createObject(self.tb["\235\182\136\237\131\144\236\160\132\236\157\180"],self.tile.x,self.tile.y)
if not self.sdata.willDie then
o.sdata["\236\163\189\236\157\140\236\160\132\236\157\180"]=self.sdata.id;
end
self:die(true);
else
self:die();
end
end
if not self.dying then
self:idle();
end
end
if type=="EVENT"then
if evt then
if self.eventCB then
self.eventCB(evt,param1);
end
trace("evt",self:getType(),evt,param1);
if string.find(evt,"particle")then
local t=string.split(param1,",")
self:addParticle({{slot=string.trim(t[1]),particle=string.trim(t[2])}});
elseif string.find(evt,"sound")and param1 then
self:playSndQueue(param1);
end
end
end
end

function Object:queryObject(pos,radius)
local function query(o)
if o==self or not o.isObject or o.dying or o:isHide()then
return false;
end
return true;
end
return world.grid:QueryR(pos.x or pos[1],pos.y or pos[2],radius or 0,query);
end

function Object:queryEnemy(pos,radius)
local function query(o)
if o.isObject or o.dying then
return false;
elseif self:getTeam()==o:getTeam()then
return false;
end
return true;
end
return world.grid:QueryR(pos.x or pos[1],pos.y or pos[2],radius or 0,query);
end


function Object:burn()
if self.tb["\237\131\128\235\138\148 \236\139\156\234\176\132"]then
local tile=world.ground:getTile(self.tile.x,self.tile.y);
if tile~=TT.WATER then
self.sdata.burnT=self.sdata.burnT or countkcc(self.tb["\237\131\128\235\138\148 \236\139\156\234\176\132"]);
world.ground:addTileBlockRef(self.tile.x,self.tile.y,Block_Danger,self);
self:idle();
end
end
end


function Object:burnDie()
world.ground:delTileBlockRef(self.tile.x,self.tile.y,Block_Danger,self);
end

function Object:burnOut()
world.ground:delTileBlockRef(self.tile.x,self.tile.y,Block_Danger,self);
end


function Object:dispel()
end

function Object:impact(key)
if string.starts(key,"\237\153\148\236\151\188")then
if math.randpercent(self.tb["\237\153\148\236\151\188\235\182\136"])then
self:burn();
end
elseif key=="\235\178\136\234\176\156"and self.tb["\237\131\128\235\138\148 \236\139\156\234\176\132"]then
if self.tb["\235\182\136\237\131\144\236\160\132\236\157\180"]then
local o=world:createObject(self.tb["\235\182\136\237\131\144\236\160\132\236\157\180"],self.tile.x,self.tile.y)
if not self.sdata.willDie then
o.sdata["\236\163\189\236\157\140\236\160\132\236\157\180"]=self.sdata.id;
end
self:die(true);
end
if math.randpercent(self.tb["\235\178\136\234\176\156\235\182\136"])then
self:burn();
end
end
end

function Object:idle(first)
if self:isCompleted()then
if self.tb["\236\153\132\235\163\140\237\154\140\236\131\137"]then
if self.mc then
self.mc:SetBlendType(2);
end
end

if self.tb["\236\153\132\235\163\140 \234\184\176\235\179\184"]then
self:play(self.tb["\236\153\132\235\163\140 \234\184\176\235\179\184"],true);
else
if first then


self:play(self.tb["\236\153\132\235\163\140 \236\149\160\235\139\136"]or self.tb["\236\149\161\236\133\152 \236\149\160\235\139\136"],false,-0.0001);
else
if self.skeleton then
self.skeleton:setUpdateWhenRender(true);
end
end
end
self:delParticle(self.tb.particle);
if self.tb.cparticle then
local dt=0;
if first then dt=1;end
self:addParticle(self.tb.cparticle,dt);
end
else
if self.tb["\236\191\168\236\149\160\235\139\136"]and self.sdata.menuCool then
self:play(self.tb["\236\191\168\236\149\160\235\139\136"],true);
elseif self.tb["\234\184\176\235\179\184 \236\149\160\235\139\136"]then
self:play(self.tb["\234\184\176\235\179\184 \236\149\160\235\139\136"],true);
elseif self.tb["\236\149\161\236\133\152 \236\149\160\235\139\136"]then
if first then
self:play(self.tb["\236\149\161\236\133\152 \236\149\160\235\139\136"],false,-0.0001);
end
end
if self.tb["\236\153\132\235\163\140\237\154\140\236\131\137"]then
if self.mb then
self.mc:SetBlendType(0);
end
end

self:delParticle(self.tb.cparticle);
if self.tb.particle then
local dt=0;
if first then dt=1;end
self:addParticle(self.tb.particle,dt);
end
end
if self.sdata.burnT then
if self.mc then
local _,_,cx,cy=self.mc:GetBound();
local dt=0;
if first then dt=1;end
self.skeleton:setChild(self.slotParticleBurn,{
particle="media/particle/particle_fire_wood.json",
scale=cy/200,
dt=dt});
self:playSnd("\235\182\136 \235\182\153\236\157\140",true);
end
else
self:stopSnd("\235\182\136 \235\182\153\236\157\140");
end





end

function Object:destroy()

if self.sdata["\235\182\128\235\170\168"]then
world.player:delBuff(nil,self.guid);
local parent=world:findCharac(self.sdata["\235\182\128\235\170\168"]);
if parent then
parent:onChildDie(self.guid);
end
world.player:updateIcon();
end

for k,v in safe_ipairs(self.tb["\236\132\164\236\185\152\236\157\180\235\166\132"]or self.sdata.id)do
DelBuilding(v,self.guid);
end

self:unplace();
self.skeleton=nil;
self.mc=nil;
self.arrow=nil;
if self.canvas then
self.canvas:Remove();
self.canvas=nil;
end

if self.ui then
self.ui:Remove();
self.ui=nil;
end
end
function Object:optionEnabled(k)
return true;
end


function Object:applyOption(mult,tb)
tb=tb or self.tb["\236\152\181\236\133\152"];
if tb then
for k,v in pairs(tb)do
if self:optionEnabled(k)then
if k=="\236\139\156\236\149\188"then
local R=v;
for i=-R,R,1 do
for j=-R,R,1 do
local v=1-math.sqrt(i*i+j*j)/(R+1);
world.ground:addSuperVision(self.tile.x+i,self.tile.y+j,mult*v);
end
end
elseif k=="\236\152\168\235\143\132"then
assert(type(v.V)=="number",self.sdata.id,v.V);
local R=v["\235\178\148\236\156\132"];
for i=-R,R,1 do
for j=-R,R,1 do
world.ground:addTemperature(self.tile.x+i,self.tile.y+j,mult*v.V);
end
end
elseif k=="\236\152\164\236\151\188"then
local R=v["\235\178\148\236\156\132"];
for i=-R,R,1 do
for j=-R,R,1 do
world.ground:addDarkforce(self.tile.x+i,self.tile.y+j,mult*v.V);
end
end
elseif k=="\235\182\136 \236\156\160\236\167\128"then
end
end
end
end
end

function Object:unplace()

local x,y=self.tile.x,self.tile.y;
if world.grid:unplace(self,x,y)then
local R=math.max((self.tb["\237\129\172\234\184\176"]or 0)-1,0);
for i=x-R,x+R,1 do
for j=y-R,y+R,1 do
if(self.tb["\234\184\184\235\167\137"]or 0)>0 and not self.tb["\235\166\172\236\160\160 \236\139\156\234\176\132"]then
world.ground.pathFinder:SetWalkability(i*tileSize,j*tileSize,-Block_Object);
end
if(self.tb["\236\160\129\235\182\136"]or 0)>0 then
world.ground.pathFinder:SetWalkability(i*tileSize,j*tileSize,-Block_MyObject);
end
if(self.tb["\237\138\184\235\158\169"]or 0)>0 then
world.ground.pathFinder:SetWalkability(i*tileSize,j*tileSize,-Block_Trap);
end
if self.sdata.burnT or((self.tb["\236\154\176\237\154\140"]or 0)>0)then
world.ground:delTileBlockRef(i,j,Block_Danger,self);
end
if(self.tb["\236\139\156\236\149\188"]or 0)>0 then
world.ground.pathFinder:SetVisibility(i*tileSize,j*tileSize,-Block_Object);
world.ground:invalidateSight();
end
if self.tb["\235\176\156\235\134\146\236\157\180"]then
world.ground:AddFloorCurve(i,j,self.tb["\235\176\156\235\134\146\236\157\180"]);
end
world.grid:unplace(self,i,j);
end
end

if string.starts(self.tb["\236\160\149\235\169\180"],"\236\167\132\236\158\133")then
if self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133"then
if self.sdata.a=="left"then
world.ground.pathFinder:SetBlock((x+R)*tileSize,y*tileSize,0);
else
world.ground.pathFinder:SetBlock(x*tileSize,(y+R)*tileSize,0);
end
elseif self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133C"then
world.ground.pathFinder:SetBlock(x*tileSize,y*tileSize,0);
elseif self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133L"then
if self.sdata.a=="left"then
world.ground.pathFinder:SetBlock(x*tileSize,(y+R)*tileSize,0);
else
world.ground.pathFinder:SetBlock((x+R)*tileSize,y*tileSize,0);
end
elseif self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133U"then
if self.sdata.a=="left"then
world.ground.pathFinder:SetBlock((x-R)*tileSize,y*tileSize,0);
else
world.ground.pathFinder:SetBlock(x*tileSize,(y-R)*tileSize,0);
end
end
end
self:applyOption(-1);
end

end


function Object:place()
if not self:isCompleted()or self.tb["\236\152\129\234\181\172"]or self.tb["\236\178\160\234\177\176"]then
local x,y=self.tile.x,self.tile.y;
local R=math.max((self.tb["\237\129\172\234\184\176"]or 0)-1,0);
for i=x-R,x+R,1 do
for j=y-R,y+R,1 do
if(self.tb["\234\184\184\235\167\137"]or 0)>0 then
world.ground.pathFinder:SetWalkability(i*tileSize,j*tileSize,Block_Object);
end
if(self.tb["\236\160\129\235\182\136"]or 0)>0 then
world.ground.pathFinder:SetWalkability(i*tileSize,j*tileSize,Block_MyObject);
end
if(self.tb["\237\138\184\235\158\169"]or 0)>0 then
world.ground.pathFinder:SetWalkability(i*tileSize,j*tileSize,Block_Trap);
end
if self.sdata.burnT or((self.tb["\236\154\176\237\154\140"]or 0)>0 and(self.sdata["\236\157\128\235\176\128\235\143\132"]or 0)<=0)then
world.ground:addTileBlockRef(i,j,Block_Danger,self);
end
if(self.tb["\236\139\156\236\149\188"]or 0)>0 then
world.ground.pathFinder:SetVisibility(i*tileSize,j*tileSize,Block_Object);
world.ground:invalidateSight();
end
if self.tb["\235\176\156\235\134\146\236\157\180"]then
world.ground:AddFloorCurve(i,j,-self.tb["\235\176\156\235\134\146\236\157\180"]);
end
world.grid:place(self,i,j,self.sdata.z);
end
end

if self.tb["\236\160\149\235\169\180"]then
if self.tb["\236\160\149\235\169\180"]=="\236\160\145\234\183\188"then
if self.sdata.a=="left"then
self.front.x=self.front.x+R+1;
else
self.front.y=self.front.y+R+1;
end
elseif self.tb["\236\160\149\235\169\180"]=="\236\160\145\234\183\188U"then
if self.sdata.a=="left"then
self.front.y=self.front.y-(R+1);
else
self.front.x=self.front.x-(R+1);
end
elseif self.tb["\236\160\149\235\169\180"]=="\236\160\145\234\183\188L"then
if self.sdata.a=="left"then
self.front.y=self.front.y+R+1;
else
self.front.x=self.front.x+R+1;
end
elseif string.starts(self.tb["\236\160\149\235\169\180"],"\236\167\132\236\158\133")then
if self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133"then
if self.sdata.a=="left"then
self.front.x=self.front.x+R;
world.ground.pathFinder:SetWalkability((x+R)*tileSize,y*tileSize,-Block_Object);
world.ground.pathFinder:SetBlock((x+R)*tileSize,y*tileSize,2+4+8);
else
self.front.y=self.front.y+R;
world.ground.pathFinder:SetWalkability(x*tileSize,(y+R)*tileSize,-Block_Object);
world.ground.pathFinder:SetBlock(x*tileSize,(y+R)*tileSize,1+4+8);
end
elseif self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133C"then
world.ground.pathFinder:SetWalkability(x*tileSize,y*tileSize,-Block_Object);
world.ground.pathFinder:SetBlock(x*tileSize,y*tileSize,4+8);
elseif self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133L"then
if self.sdata.a=="left"then
self.front.y=self.front.y+R;
world.ground.pathFinder:SetWalkability(x*tileSize,(y+R)*tileSize,-Block_Object);
world.ground.pathFinder:SetBlock(x*tileSize,(y+R)*tileSize,1+4+8);
else
self.front.x=self.front.x+R;
world.ground.pathFinder:SetWalkability((x+R)*tileSize,y*tileSize,-Block_Object);
world.ground.pathFinder:SetBlock((x+R)*tileSize,y*tileSize,2+4+8);
end
elseif self.tb["\236\160\149\235\169\180"]=="\236\167\132\236\158\133U"then
if self.sdata.a=="left"then
self.front.y=self.front.y-R;
world.ground.pathFinder:SetWalkability(x*tileSize,(y-R)*tileSize,-Block_Object);
world.ground.pathFinder:SetBlock(x*tileSize,(y-R)*tileSize,1+2+4);
else
self.front.x=self.front.x-R;
world.ground.pathFinder:SetWalkability((x+R)*tileSize,y*tileSize,-Block_Object);
world.ground.pathFinder:SetBlock((x+R)*tileSize,y*tileSize,1+2+8);
end
end
end
end

self:applyOption(1);
return true;
end

end

function Object:setArrow(arrow)
self.arrow=arrow;
if self.arrow=="left"then
if self.skeleton then
self.skeleton:setFlipX(true);
elseif self.mc then
self.mc:SetScaleX(math.abs(self.mc:GetScaleX()));
end
else
if self.skeleton then
self.skeleton:setFlipX(false);
elseif self.mc then
self.mc:SetScaleX(-math.abs(self.mc:GetScaleX()));
end
end
end

function Object:getArrow()
return self.arrow;
end


function Object:look(to)
local cx=to.pos.x-self.pos.x;
local cy=to.pos.y-self.pos.y;
local d=world.ground:ScreenArrow(cx,cy);
if d>0.001 then
self:setArrow("right");
elseif d<-0.001 then
self:setArrow("left");
else
if to:getArrow()=="right"then
self:setArrow("left");
else
self:setArrow("right");
end

end
end


function Object:swap(nextId,cb)
local function f()
trace("swap",self.sdata,nextId);
local id=self.sdata.id;
local guid=self.guid;
self:destroy();
self.sdata.state=nil;
self.sdata.id=nextId;
local o=world:addObject(guid,self.sdata);
if cb then
cb(o);
end
end
world.timer.add(f,f);
end

function Object:update(dt)
if self.emitter then
self.emitter:update(dt);
end

self.timer.update(dt);
if self.skeleton then
if world.ground:inLOS(self.tile.x,self.tile.y)or not self.skeleton:getUpdateWhenRender()then
self.skeleton:update(dt);
end
end
local vision=world.ground:inNearSight(self.pos.x,self.pos.y,1);
if vision>=Vision_Old then
assert(self.canvas,self.sdata);
self.canvas:SetVisible(true);
self.canvas:SetAlphaColor(world.ground:getFloorColor(self.tile.x,self.tile.y));
self:updateMC();

if world.player.mc and vision>=Vision_Cur and self.tb["\237\136\172\235\170\133"]and not self.dying then
local px,py=world.ground:MapToTile(world.player.pos.x,world.player.pos.y)
if(self.tile.x+self.tile.y)>(px+py)then


self.mc:SetAlphaDepth(0.7);
else
self.mc:SetAlphaDepth(1);
end
end
else
self.canvas:SetVisible(false);
end
end

function Object:play(anim,loop,position,delay,eventCB)

assert(not self.eventTB);
self.eventCB=eventCB;
local f=function()
if not self.dying then
if type(anim)=="table"then
anim=table.choice(anim);
end
if anim then

assert(self.skeleton,self.sdata,self.guid);
self.skeleton:setAnimation(0,anim,loop,position);
self.skeleton:update(0);
end
end
end
if(delay or 0)>0 then
self.timer.add(f,f,delay);
else
f();
end

end

function Object:isNickVisible()
return
world.player.guid and
not world.isTraveling and
not self:isCompleted()and
not self.sdata["\236\157\128\235\176\128\235\143\132"]and
world.ground:inLOS(self.tile.x,self.tile.y)and
_Z.ShowObjectNick>=math.max(math.abs(world.player.tile.x-self.tile.x),math.abs(world.player.tile.y-self.tile.y));
end

function Object:showHP(prevHP,dur)
if self.sdata.HP and self.tb.HP and self.mcNick and self.ui then
if not self.ui.hp then
self.ui:AddSymbol("\236\152\164\235\184\140\236\160\157\237\138\184HP","hp");
end
local _,_,cx,cy=self.mcNick.nick:GetRendererRect();
self.ui.hp:SetY(self.mcNick:GetY()+cy);
local p=self.sdata.HP/self.tb.HP;
self.ui.hp.bar.p=prevHP/self.tb.HP;
SetPercentDiff(self.ui.hp.bar,p,self.timer);
local function f()
self.ui.hp:Remove();
end
self.timer.add(self.ui.hp,f,dur or _Z.ObjectHPT);
end
end
function Object:updateMC()
local x=self.pos.x;
local y=self.pos.y;
local z=self:getZOrder();
local h=(self.sdata.h or self.sdata.z or 0);
local showNick=self:isNickVisible();
if self.sdata.offset then
x=x+(self.sdata.offset.x or 0);
y=y+(self.sdata.offset.y or 0);
end

do
local px,py=world.ground:MapToScreenFloor(x-h/2,y-h/2);
if self.canvas then
self.canvas:SetPos(px,py);
self.canvas:SetZOrder(z);
end

if self.ui then
self.ui:SetPos(px,py);
self.ui:SetZOrder(z);
end
end

if self.skeleton then

self.skeleton:setSlotZ(0,z);
end

if self.mcNick then
self.mcNick:SetVisible((not _Z.HideObjectNick or showNick)and self:getName());
end

if self.ui.ready then
self.ui.ready:SetVisible(showNick);
end


end

function Object:getZOrder()
local h=(self.sdata.z or 0)/tileSize;
local R=math.max(0,((self.tb["\237\129\172\234\184\176"]or 0)-1)*tileSize);
return world.ground:MapToZOrder(self.pos.x+R,self.pos.y+R)+math.floor(h);
end

function Object:updateTileProp()
if self.skeleton then
local tile=world.ground:getTile(self.tile.x,self.tile.y);
if tile==TT.WATER then
local h=185+30+200+(self.tb["\235\172\188\235\134\146\236\157\180"]or 0);
local hdiff=3;
local t=0;
local function f(dt)
local t=world.timer.time;
local _h=math.floor(0.5+h+math.cos(t)*hdiff);
self.skeleton:setClipRect(0,{-300,-400+_h,600,400});
self.skeleton:setClipRect(1,{-300,-400,600,_h});
self.skeleton:setClipColor(0,0xFF8DBCDC);
self.skeleton:setClipColor(1,0xFFFFFFFF);
return true;
end
self.timer.add("tileprop",f,0.2);
else
self.skeleton:setClipRect(0,{0,0,0,0});
self.skeleton:setClipRect(1,{0,0,0,0});
self.timer.remove("tileprop");
end
end
end


function Object:menuTouch(from,menu,onOk,onCancel)

if menu=="\235\169\148\235\137\180_\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"then
local nextId=recipetable[self.sdata.id]["\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"];
if recipetable[nextId]then
local function ok(id,guids)
if ConsumeItemsFromGuid(guids)then
onOk(menu,nextId);
end
end
local function cancel()
onCancel(menu);
end
BuildItemPopup(world,ok,cancel,"\236\160\156\236\158\145\235\178\149",{nextId,recipetable[nextId]["\236\158\172\235\163\140"]});
end
else
onOk(menu);
end
end

function Object:menuEnabled(guid)
return true;
end

function Object:preTouch(from,onOk,onCancel)
local list=self:menuList();
if self.tb["\235\169\148\235\137\180"]and table.empty(list)then
onCancel();
return false;
end

if not table.empty(list)then
local function _ok(guid,materials)
if guid=="\235\169\148\235\137\180_\235\182\128\236\136\152\234\184\176"then

if not from:attackObject(self)then
world.player:addChat(_L("\236\152\164\235\184\140\236\160\157\237\138\184 \234\179\181\234\178\169 \236\139\164\237\140\168"));
onCancel();
end
elseif guid=="\235\169\148\235\137\180_\235\182\136\235\182\153\236\157\180\234\184\176"then
local function cb(evt)
if evt=="COMPLETE"then
self:burn();
DelTorch();
from:updateCostume();
onCancel();
end
end
from:play("ani_light_fire",nil,nil,cb);
elseif guid=="\235\169\148\235\137\180_\236\158\160\236\158\144\234\184\176"then
if from:canSleep()then
local function _ok2(...)
from:setArrow(OpponentArrow(self:getArrow()));
onCancel(...);
end
SelectItemPopup(world,_ok2,onCancel,{"\234\184\176\237\131\128"},"\235\178\132\237\138\188",{object=self,btns=const("\236\158\160\236\158\144\234\184\176\235\169\148\235\137\180"),detail=_L("\236\158\160\236\158\144\234\184\176\236\132\160\237\131\157\236\132\164\235\170\133")});
else
world.player:addChat(_L("\236\158\160\236\158\144\234\184\176 \236\139\164\237\140\168"));
onCancel();
end
elseif guid=="\235\169\148\235\137\180_\236\157\180\235\166\132\235\179\128\234\178\189"then
local function _ok(txt)
self.sdata.name=utf8.sub(txt,1,16);
if self.mcNick then
self.mcNick.nick:SetText(self:getName());
end
onCancel();
end
GetTextPopup(self:getName(),self:getName(),_ok,onCancel);
else
local function ok(...)
if onOk(...)then
if materials then
ConsumeItemsFromGuid(materials);
end
end
end
self:menuTouch(from,guid,ok,onCancel);
end
end
if from and from.nextTouchMenu then
_ok(from.nextTouchMenu);
else
ObjectMenuPopup(self,_ok,onCancel,list);
end
world.player:addChat(lang["\235\140\128\237\153\148_"..self.sdata.id]);
else
self:menuTouch(from,nil,onOk,onCancel);

end
end

function Object:playSndQueue(...)
return Player.playSndQueue(self,...);
end
function Object:stopSndQueue(...)
return Player.stopSndQueue(self,...);
end

function Object:playSnd(...)
local cx=math.abs(_S.x-self.tile.x);
local cy=math.abs(_S.y-self.tile.y);
if math.max(cx,cy)<=_Z.SoundRange then
return Player.playSnd(self,...);
else
return self:stopSnd(...);
end
end
function Object:stopSnd(...)
return Player.stopSnd(self,...);
end

function Object:delParticle(tb)
if tb then
for k,v in ipairs(tb)do
self.skeleton:delChild(v.slot);
end
end
end

function Object:addParticle(tb,dt)
if tb then
for k,v in ipairs(tb)do
self.skeleton:setChild(v.slot,{
key=v.particle,
particle=string.format("media/particle/%s.json",v.particle),
scale=v.scale,
dt=dt,
x=v.x,
y=v.y,
zOrder=v.zOrder,
rotation=math.rad(v.rotate or 0)});
end
end
end

function Object:checkSticky(x,y)
local _,t=self:queryObject({x=x,y=y},0);
if t then
for k,v in ipairs(t)do
if table.find(self.tb.stickyO,v.sdata.id)then
if v.sdata.sticky and table.find(v.tb.stickyO,self.sdata.id)then
v.sdata.sticky=nil;
v:sticky();
end
return true;
end
end
end
end

function Object:sticky()
if not self.sdata.sticky then
local s=0;
if self:checkSticky(self.tile.x+1,self.tile.y)then s=s|Sticky_right;end
if self:checkSticky(self.tile.x,self.tile.y+1)then s=s|Sticky_down;end
if self:checkSticky(self.tile.x-1,self.tile.y)then s=s|Sticky_left;end
if self:checkSticky(self.tile.x,self.tile.y-1)then s=s|Sticky_up;end
self.sdata.sticky=s;
end
if self.tb.sticky then
local att=self.tb.sticky[self.sdata.sticky+1];
if string.byte(att,1)==45 then
self.skeleton:setFlipX(true);
att=string.sub(att,2);
else
self.skeleton:setFlipX(false);
end
if self.tb.attachment then
self.skeleton:setAttachment(nil,att);
else
self.skeleton:setSkin(att);
end
end
end



function Object:action()
trace("action",self.sdata.id,self.tb);
self:playSndQueue(self.tb["\236\149\161\236\133\152 \236\130\172\236\154\180\235\147\156"]);
if self.tb["\236\149\161\236\133\152 \236\149\160\235\139\136"]then
local state=self.sdata.state;
self.sdata.state="\236\153\132\235\163\140";
self:updateFloatMenu();
local function cb(evt)
if evt=="COMPLETE"then
self.sdata.state=state;
self:complete();
self:needDie();

end
end

self:addParticle(self.tb.aparticle);
self:play(self.tb["\236\149\161\236\133\152 \236\149\160\235\139\136"],nil,nil,nil,cb);
else
self:complete();
end
end

function Object:rebirth(cb)
trace("rebirth",self:getType());
self.sdata.state=nil;
self.sdata.spawned=nil;
self.sdata.nspawned=nil;
self:playSndQueue(self.tb["\235\166\172\236\160\160 \236\130\172\236\154\180\235\147\156"]);

if self.tb["\235\166\172\236\160\160 \236\149\160\235\139\136"]then
local function _cb()
self:idle();
if cb then cb();end
end
self:play(self.tb["\235\166\172\236\160\160 \236\149\160\235\139\136"],nil,nil,nil,_cb);
else
self:idle();
end


if not self.tb["\236\152\129\234\181\172"]and(self.tb["\234\184\184\235\167\137"]or 0)>0 then
local _,players=self:queryEnemy(self.tile,self.tb["\234\184\184\235\167\137"]-1);
for k,v in safe_pairs(players)do
local x,y=world.ground:getNearTileWalkable(v.tile.x,v.tile.y,nil,1);
if x and y then
v:replace(x,y);
end
end
end
self:place();
end

function Object:menuCool(menu,...)
return menu and self.tb["\235\169\148\235\137\180\236\191\168"]and self.tb["\235\169\148\235\137\180\236\191\168"][menu];
end

function Object:needComplete(menu,...)
local cool=self:menuCool(menu,...);
if menu and cool then
if self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"]and self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"][menu]then
self:applyOption(1,self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"][menu]);
end
self.sdata.menuCool=self.sdata.menuCool or{};
self.sdata.menuCool[menu]={{0,cool},{...}};
self:idle();
else
self:complete(menu,...);
end
end

function Object:needDie()

if self.sdata.willDie then
if self.sdata["\236\163\189\236\157\140\236\160\132\236\157\180"]then
local param={T=0,state="\236\153\132\235\163\140"};
local o=world:createObject(self.sdata["\236\163\189\236\157\140\236\160\132\236\157\180"],self.tile.x,self.tile.y,param);
end
self:die();
else
if self.sdata.burnT then
self:burnDie();
self.sdata.burnT=nil;
self.skeleton:delChild(self.slotParticleBurn);
end
end
end


function Object:onActionEnd(from,...)
if self.sdata.touchC then
self.sdata.touchC=self.sdata.touchC-1;
if self.sdata.touchC<=0 then
self.sdata.touchC=nil;
if from then
from:cancelTarget();
end
else






end
end

if not self.sdata.touchC then
self:needComplete(...);
if self:isCompleted()then

Mission("\236\177\132\236\167\145",1,self.tb.guid);
if self.tb["\236\153\132\235\163\140 \236\149\160\235\139\136"]then
local function cb(evt)
if evt=="COMPLETE"then
self:needDie();
end
end
self:play(self.tb["\236\153\132\235\163\140 \236\149\160\235\139\136"],nil,nil,nil,cb);
self:playSndQueue(self.tb["\236\153\132\235\163\140 \236\130\172\236\154\180\235\147\156"]);
else
self:needDie();
end
end
end
end

function Object:touch(from,...)

self.touchFrom=from;
local args={...};
local snd=self.tb["\236\149\161\236\133\152 \236\130\172\236\154\180\235\147\156"];
local anim=self.tb["\236\149\161\236\133\152 \236\149\160\235\139\136"];
local menu=args[1];
if self:isCompleted()then
snd=self.tb["\235\166\172\236\160\160 \236\130\172\236\154\180\235\147\156"]or snd;
anim=self.tb["\235\166\172\236\160\160 \236\149\160\235\139\136"]or anim;
end
if menu~="\235\169\148\235\137\180_\236\178\160\234\177\176"then
self:playSndQueue(snd);
end
if anim then
local function cb(evt)
if evt=="COMPLETE"then
if self.tb["\236\149\160\235\139\136\235\140\128\234\184\176"]then
self:onActionEnd(from,table.unpack(args));
if from then
from:onTouchEnd();
end
end
end
end
self:addParticle(self.tb.aparticle);
self:play(anim,nil,nil,nil,cb);
if not self.tb["\236\149\160\235\139\136\235\140\128\234\184\176"]then
self:onActionEnd(from,...);
if from then
from:onTouchEnd(...);
end
end
else
self:onActionEnd(from,...);
if from then
from:onTouchEnd(...);
end
end
end

function Object:menuMaterials(menu)
return itemtable[menu]["\235\178\132\237\138\188\236\158\172\235\163\140"];
end










function Object:onTouchEnd(from)
end

function Object:collision(from)
if not self:isCompleted()and self.tb["\236\182\169\235\143\140 \236\149\160\235\139\136"]then
self:play(self.tb["\236\182\169\235\143\140 \236\149\160\235\139\136"]);
end
end

function Object:spawn(tkey,gkey)
tkey=tkey or"\236\134\140\237\153\152";
gkey=gkey or"spawned";
if self.tb[tkey]and not self.sdata[gkey]then
trace("Object:spawn",tkey,gkey);
self.sdata[gkey]={};
local p=self.tb[tkey.."P"]or 100;
local c=1;
if type(p)=="table"and(p.P or p.V or p.Chat)then
if p.Chat then
local function onOk()
end
world:addStory(_L(p.Chat),onOk,self);
end
p,c=countkcc(AreaTBNumber(p.P)or 100),countkcc(AreaTBNumber(p.V)or c);
end

if self.sdata.forceSpawn or math.randpercent(AreaTBNumber(p))then
for i=1,c,1 do
local R=self.tb["\237\129\172\234\184\176"]or 0;
local L=0;
local tx,ty=self.tile.x,self.tile.y;
if type(self.tb["\236\134\140\237\153\152\235\178\148\236\156\132"])=="table"then
if self.tb["\236\134\140\237\153\152\235\178\148\236\156\132"]["\237\148\140\235\160\136\236\157\180\236\150\180"]then
local tx,ty=_S.x,_S.y;
R,L=0,self.tb["\236\134\140\237\153\152\235\178\148\236\156\132"]["\237\148\140\235\160\136\236\157\180\236\150\180"];
else
R,L=table.unpack(self.tb["\236\134\140\237\153\152\235\178\148\236\156\132"]);
end
elseif type(self.tb["\236\134\140\237\153\152\235\178\148\236\156\132"])=="number"then
L=self.tb["\236\134\140\237\153\152\235\178\148\236\156\132"];
end
R=math.min(R,L);
L=math.max(R,L);

local list={};
for k,v in pairs(self.tb[tkey])do
if type(v)=="table"and v.P then
list[k]=v.P;
else
list[k]=v;
end
end

local key=math.randlist(list);
if key=="\236\182\169\235\143\140 \235\141\176\235\175\184\236\167\128"then
Trap.addTrapDamage(self,nil,nil,self.tb["\236\134\140\237\153\152"][key]);
elseif key=="\235\143\133\234\181\172\235\166\132"then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local objects=_S.maps[mapId].objects;
local mx,my=self.tile.x,self.tile.y;
local vv=self.tb["\236\134\140\237\153\152"][key].V;
for j=-vv["\235\178\148\236\156\132"],vv["\235\178\148\236\156\132"],1 do
for i=-vv["\235\178\148\236\156\132"],vv["\235\178\148\236\156\132"],1 do
if world.ground:canTileWalkable(mx+i,my+j,Filter_ItemPlace)then
local guid=MakeGuid("o");
objects[guid]={id=key,x=mx+i,y=my+j,LifeT=vv["\236\139\156\234\176\132"],spread={x=mx,y=my,r=vv["\235\178\148\236\156\132"],c=vv["\237\153\149\236\130\176"]}};
local o=world:addObject(guid,objects[guid]);
end
end
end
else
local guid,data,o=SpawnMonster(self.tile.x,self.tile.y,R,L,key,nil,self.tb["\236\134\140\237\153\152\236\157\184\236\158\144"]);
if guid then
table.insert(self.sdata[gkey],guid);
if table.find(const("\236\134\140\237\153\152\235\143\132\235\176\156"),o.data["\237\140\168\237\132\180"])then
o:aggro(world.player);
end

if self.tb["\236\134\140\237\153\152\236\178\180"]then
local from={x=self.pos.x,y=self.pos.y,z=0};
local to={x=o.pos.x,y=o.pos.y,z=0};
local cls=self.tb["\236\134\140\237\153\152\236\178\180"];
if type(cls)=="table"then
local p=world.player:addProjectile(_G[cls.cls],from,to,table.copy(cls));
p.onDestroy=function()
end
end
end
end
end
end
end
end
end

function Object:drop()
local items={};
local function make(list)
for k,v in pairs(list)do
v=SelectAreaTB(v);
if k=="\236\157\188\235\176\152\235\147\156\235\158\141"then
for i=1,countkcc(v)do
table.insert(items,{MakeItemFromDrop,{"\236\131\129\236\158\144",100,self.tile.x,self.tile.y,self.sdata.dropRare}});
end
elseif k=="\234\179\160\234\184\137\235\147\156\235\158\141"then
for i=1,countkcc(v)do
table.insert(items,{MakeItemFromDrop,{"\234\179\160\234\184\137\236\131\129\236\158\144",100,self.tile.x,self.tile.y,self.sdata.dropRare}});
end
elseif k=="\235\147\156\235\158\141"then
if not v[1]then v={v};end
for i,v in ipairs(v)do
for k,p in pairs(v)do
table.insert(items,{MakeItemFromDrop,{k,p,self.tile.x,self.tile.y,self.sdata.dropRare}});
end
end
else
local function place()
local P,V;
if type(v)=="table"then
P=v.P or 100;
V=v.V or 1;
else
P=v;
V=1;
end

local cnt=countkcc(V);
for i=1,cnt,1 do
if math.randpercent(P)then
table.insert(items,{MakeAndPlaceItem,{k,self.tile.x,self.tile.y,self.sdata.dropRare}});
end
end
end
place();
do
local P=0;
P=bf("\237\157\172\234\183\128\234\180\145\235\172\188 \236\182\148\234\176\128 \236\149\132\236\157\180\237\133\156 \237\154\141\235\147\157",P);
if table.find(const("\237\157\172\234\183\128\234\180\145\235\172\188"),k)then
P=bf("\237\157\172\234\183\128\234\180\145\235\172\188 \236\182\148\234\176\128 \236\149\132\236\157\180\237\133\156 \237\154\141\235\147\157",P);
end
if self.tb["\235\143\132\234\181\172"]=="\236\177\132\236\167\145"or self.tb["\235\143\132\234\181\172"]=="\235\178\140\235\170\169"or self.tb["\235\143\132\234\181\172"]=="\236\177\132\234\180\145"then
P=bf("\236\182\148\234\176\128 \236\149\132\236\157\180\237\133\156 \237\154\141\235\147\157",P);
end
if self.tb["\235\143\132\234\181\172"]then
P=bf(self.tb["\235\143\132\234\181\172"].." \236\182\148\234\176\128 \236\149\132\236\157\180\237\133\156 \237\154\141\235\147\157",P);
end
P=bf(k.." \236\182\148\234\176\128 \236\149\132\236\157\180\237\133\156 \237\154\141\235\147\157",P);
if math.randpercent(P*100)then
place();
end
end
end
end
end

if self.tb["\236\131\157\236\130\176"]then
make(self.tb["\236\131\157\236\130\176"]);
end

if self.sdata["\236\131\157\236\130\176"]then
make(self.sdata["\236\131\157\236\130\176"]);
end

if self.tb["\236\177\132\236\167\145"]then
world.player:spell(self.tb["\236\177\132\236\167\145"],nil,nil,nil,nil,nil,true);
end

if items[1]then
world:pauseTurn();

local function f()
if items[1]then
local func,param=items[1][1],items[1][2];
func(table.unpack(param));
table.remove(items,1);
return true;
else
world:resumeTurn();
end
end
world.timer.add(f,f,const("\235\147\156\235\161\173\236\149\132\236\157\180\237\133\156\237\139\177"));
end

self:spawn();

if self.sdata.triggers then
for k,v in pairs(self.sdata.triggers)do
local o=world:findObject(v);
if o and not o:isCompleted()then
o.sdata.forceSpawn=true;
o:touch();
end
end
end

if self.sdata.linkObj then
local o=world:findObject(self.sdata.linkObj);
assert(o and not o:isCompleted());
if o and not o:isCompleted()then
o:touch();
end
end

if self.sdata.item and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.item]then
local o=PlaceItem(self.sdata.item,self.tile.x,self.tile.y);
o.sdata.z=self.tb["\235\134\146\236\157\180"];
o.sdata["\237\129\172\234\184\176"]=self.tb["\237\129\172\234\184\176"];
end
end

function Object:isHide()
return self.sdata.state=="\236\153\132\235\163\140"and not self.tb["\236\178\160\234\177\176"];
end

function Object:isCompleted()
return self.sdata.state=="\236\153\132\235\163\140";
end

function Object:complete(menu,...)

if menu=="\235\169\148\235\137\180_\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"then
local nextId=table.unpack({...});
world:pauseTurn();
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(nextId,cb,self.guid);
self:swap(nextId);
elseif menu=="\235\169\148\235\137\180_\236\178\160\234\177\176"then
self:die();
for _,id in safe_pairs(self.tb["\236\132\164\236\185\152\236\157\180\235\166\132"]or self.sdata.id)do
local tb=objecttable[id];
local t=recipetable[id]or recipetable[tb["\237\140\140\235\157\188\235\175\184\237\132\176"]];
if t and t["\236\178\160\234\177\176\236\156\168"]then
for k,v in safe_pairs(t["\236\158\172\235\163\140"])do
for i=1,countkcc(v*(t["\236\178\160\234\177\176\236\156\168"][k]or t["\236\178\160\234\177\176\236\156\168"]["\234\184\176\237\131\128"]or 0))do
MakeAndPlaceItem(k,self.tile.x,self.tile.y);
end
end
end
end
elseif string.ends(menu,"\235\182\136\237\148\188\236\154\176\234\184\176")then
if self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]then
local nextId=self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"];
world:pauseTurn();
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(nextId,cb,self.guid);
self:swap(nextId);
end
else
local cond=self.tb["\236\153\132\235\163\140\236\161\176\234\177\180"];
local b=true;

if cond then
if cond["\236\132\160\237\150\137\235\148\148\235\178\132\237\148\132"]and not HasDebuff(cond["\236\132\160\237\150\137\235\148\148\235\178\132\237\148\132"])then

b=false;
elseif cond["\236\132\160\237\150\137\235\170\172\236\138\164\237\132\176"]then
for k,v in pairs(cond["\236\132\160\237\150\137\235\170\172\236\138\164\237\132\176"])do
if(_S["\236\178\152\236\185\152"][k]or 0)<v then
b=false;
end
end
elseif cond["\235\139\172"]and GetMoonZone()~=cond["\235\139\172"]then

b=false;
end
end

if b then
self:drop();
if self.tb["\236\153\132\235\163\140\236\160\156\237\149\156"]then
if self.tb["\236\153\132\235\163\140\236\160\156\237\149\156"]<0 then
else
self.sdata.cnt=(self.sdata.cnt or 0)+1;
if self.sdata.cnt>=self.tb["\236\153\132\235\163\140\236\160\156\237\149\156"]then
self.sdata.state="\236\153\132\235\163\140";
end
end
else
self.sdata.state="\236\153\132\235\163\140";
end
end

if self:isCompleted()then
if not self.tb["\236\152\129\234\181\172"]and not self.tb["\236\178\160\234\177\176"]then
self:unplace();
end
if self.tb["\235\166\172\236\160\160 \236\139\156\234\176\132"]then
trace("\235\166\172\236\160\160 \236\139\156\236\158\145");
self.sdata.T=0;
end
end

self:idle();
end
end

function Object:canTouch()
if self.tb["\236\167\147\234\184\176"]then
if self:queryObject(self.tile,0)then
return false;
end
end
return not self.tb["\235\141\176\236\189\148"]and not self:isHide();
end

function Object:isInTouch(dist,from)
local r=(self.sdata["\237\129\172\234\184\176"]or self.tb["\237\129\172\234\184\176"]or 0);
if r>0 and string.starts(self.tb["\236\160\149\235\169\180"],"\236\160\145\234\183\188")then
r=r-1;
end
return self:canTouch()and dist<=r;
end


function Object:floatMenuList()
return self:menuList(true);
end

function Object:menuList(float)
local list;
if self.tb["\236\178\160\234\177\176"]and self:isCompleted()then
list=list or{};
table.insert(list,"\235\169\148\235\137\180_\236\178\160\234\177\176");
elseif self.tb["\235\169\148\235\137\180"]then
for i,v in ipairs(self.tb["\235\169\148\235\137\180"])do
if v=="\235\169\148\235\137\180_\235\182\136\235\182\153\236\157\180\234\184\176"and(not HasTorch()or self.sdata.burnT)then
elseif v=="\235\169\148\235\137\180_\236\178\160\234\177\176"and float then
elseif(not self.sdata.menuCool or not self.sdata.menuCool[v])and self:menuEnabled(v)then
list=list or{};
table.insert(list,v);
end
end
local recipe=recipetable[self.sdata.id]or recipetable[self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]];
if not float and recipe and recipe["\236\178\160\234\177\176\236\156\168"]and self:menuEnabled("\235\169\148\235\137\180_\236\178\160\234\177\176")then
list=list or{};
table.insert(list,"\235\169\148\235\137\180_\236\178\160\234\177\176");
end

end
return list;
end

function Object:updateFloatMenu(refresh)

if self.tb["\235\169\148\235\137\180"]then
if refresh and self.ui.ready then
self.ui.ready:Remove();
end
if not self:isCompleted()then
if not self.ui.ready then
local list=self:floatMenuList();
if list then
self.ui:CreateEmptyMovieClip("ready");
self.ui.ready:SetZOrder(-1);
local w=self.mcFloatMenuSize[1];
local x=-w*(#list-1)/2;
for k,v in ipairs(list)do
local mc=self.ui.ready:AddSymbol(self.mcFloatMenu,"");
local _,_,_w,_h=mc:GetBound();
local item=itemtable[v];
mc.img:AddSymbol(item.img,"icon");
mc:SetPos(x,-self.mcFloatMenuSize[2]);
x=x+w;
end
end
end
else
if self.ui.ready then
self.ui.ready:Remove();
end
end
end
end

function Object:checkSpawnEnd()
for k,v in safe_pairs(self.sdata.spawned)do
if world:findCharac(v)then
return false;
end
end
for k,v in safe_pairs(self.sdata.nspawned)do
if world:findCharac(v)then
return false;
end
end
return true;
end

function Object:onResetTurn(AP)
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
if self.sdata.menuCool then
for k,v in pairs(self.sdata.menuCool)do
v[1][1]=v[1][1]+AP;
if v[1][1]>=v[1][2]then
if self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"]and self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"][k]then
self:applyOption(-1,self.tb["\235\169\148\235\137\180\236\152\181\236\133\152"][k]);
end
self:complete(k,table.unpack(v[2]));
self.sdata.menuCool[k]=nil;
end
end
if table.empty(self.sdata.menuCool)then
self.sdata.menuCool=nil;
end
end

if self.sdata.menuCool then
for k,v in pairs(self.sdata.menuCool)do
AddCoolBar(self.canvas,v[1][1],v[1][2],_Z.tileH/5);
end
elseif self.canvas.cool then
self.canvas.cool:Remove();
end

self:updateFloatMenu();


if self.tb["\235\169\148\235\137\180"]and table.find(self.tb["\235\169\148\235\137\180"],"\235\169\148\235\137\180_\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156")then
if recipetable[self.sdata.id]then
local nextId=recipetable[self.sdata.id]["\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"];
local v=recipetable[nextId];
if v then

local b=SetRequireBuildingText(nil,v);
if b then
if not self.canvas.upready then
self.canvas:AddSymbol("\236\152\164\235\184\140\236\160\157\237\138\184\236\151\133\235\160\136\235\148\148","upready");
end
else
if self.canvas.upready then
self.canvas.upready:Remove();
end
end
end
end
end

if self.tb["\236\152\134\236\149\132\236\157\180\236\189\152"]then
if not self:isCompleted()and world.player.getDistance and world.player:getDistance(self)<=1 then
if not self.canvas.ready2 then
self.canvas:AddSymbol(self.tb["\236\152\134\236\149\132\236\157\180\236\189\152"],"ready2");
self.canvas.ready2:SetZOrder(-100);
end
else
if self.canvas.ready2 then
self.canvas.ready2:Remove();
end
end
end

if self.sdata.LifeT then
self.sdata.T=(self.sdata.T or 0)+AP;
if self.sdata.LifeT<=self.sdata.T then
self:die();
end
elseif self.sdata.T then
if self:checkSpawnEnd()then
self.sdata.T=self.sdata.T+AP;
end
local regenT=self.tb["\235\166\172\236\160\160 \236\139\156\234\176\132"];
if regenT and self:isCompleted()and self.sdata.T>=regenT then
self.sdata.T=nil;
if self.tb["\235\166\172\236\160\160 \235\179\128\236\139\160"]then
local function f()
local list={};
local tile=TT._NAMES[world.ground:getTile(self.tile.x,self.tile.y)];
if tile=="\235\149\133"then
if IsInField()then
tile="\236\180\136\236\155\144";
else
tile="\237\134\160\236\150\145";
end
end
_G.TB,_G.gen=0,0;
for k,v in pairs(self.tb["\235\166\172\236\160\160 \235\179\128\236\139\160"])do
local t=objecttable[k];
local p=0;
_G.TB,_G.gen=GetObjectTBandGen(_S["\237\152\132\236\158\172\235\167\181"],t);
list[k]=self.tb["\235\166\172\236\160\160 \235\179\128\236\139\160"][k]*(t["p"..tile]or 0);
end
_G.TB,_G.gen=nil,nil;

local nextId=math.randlist(list);
if nextId and nextId~=self.sdata.id then
self:swap(nextId,function(o)
o:play(o.tb["\235\166\172\236\160\160 \236\149\160\235\139\136"]);
end);
else
self:rebirth();
end
end
world:addTurnDispatcher(f);
else
self:rebirth();
end
end
end

do
if m["\235\130\160\236\148\168"]=="\235\185\132"then
self.sdata.rainT=(self.sdata.rainT or 0)+AP;
if self.sdata.burnT and self.sdata.rainT>=const("\236\152\164\235\184\140\236\160\157\237\138\184\235\185\132\236\151\144\235\182\136\234\186\188\236\167\144\236\139\156\234\176\132")then
self:burnOut();
self.skeleton:delChild(self.slotParticleBurn);
self.sdata.burnT=nil;
end
else
self.sdata.rainT=nil;
end
end

if self.sdata.burnT then
local burnAP;
if self.sdata.burnT>0 then
burnAP=math.min(AP,self.sdata.burnT);
else
burnAP=AP;
end
if self.sdata.HP then
self.sdata.HP=math.max(0,self.sdata.HP-const("\236\152\164\235\184\140\236\160\157\237\138\184\235\182\136\237\131\144HP\236\134\140\235\170\168")*burnAP/10);
if self.sdata.HP<=0 then
self:burnDie();
self.sdata.burnT=nil;
self.skeleton:delChild(self.slotParticleBurn);
if self.tb["\235\182\136\237\131\128\235\138\148 \236\149\160\235\139\136"]then
self:play(self.tb["\235\182\136\237\131\128\235\138\148 \236\149\160\235\139\136"]);
else
self:die();
end
end
end
if self.sdata.burnT then
if burnAP>0 then
local _,t=self:queryObject(self.tile,1);
for k,v in safe_pairs(t)do
if math.randpercent(const("\236\152\164\235\184\140\236\160\157\237\138\184\235\182\136\236\160\132\236\157\180\237\153\149\235\165\160"))then
v:burn();
end
end
Trap.addTrapDamage(self,nil,nil,const("\236\152\164\235\184\140\236\160\157\237\138\184\235\182\136\235\141\176\235\175\184\236\167\128"));
end
if self.sdata.burnT>0 then
self.sdata.burnT=self.sdata.burnT-burnAP;
if self.sdata.burnT<=0 then
self:burnOut();
self.skeleton:delChild(self.slotParticleBurn);
self.sdata.burnT=nil;
end
end
end
end

if AP>0 and self.sdata.item and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.item]then
UpdateItem(self.sdata.item,self.tb["\236\160\128\236\158\165\236\152\168\235\143\132"]or ev("\234\184\176\236\152\168"),AP*(self.sdata["\236\160\128\236\158\165\236\139\156\234\176\132"]or self.tb["\236\160\128\236\158\165\236\139\156\234\176\132"]or 1),nil,self);
end

if self.sdata.items then
for k,v in pairs(self.sdata.items)do
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v]then
UpdateItem(v,self.tb["\236\160\128\236\158\165\236\152\168\235\143\132"]or ev("\234\184\176\236\152\168"),AP*(self.sdata["\236\160\128\236\158\165\236\139\156\234\176\132"]or self.tb["\236\160\128\236\158\165\236\139\156\234\176\132"]or 1),nil,self);
end
end
end

if self.tb["\234\184\176\235\179\184 \236\130\172\236\154\180\235\147\156"]then
if self:isCompleted()then
self:stopSnd(self.tb["\234\184\176\235\179\184 \236\130\172\236\154\180\235\147\156"]);
else
self:playSnd(self.tb["\234\184\176\235\179\184 \236\130\172\236\154\180\235\147\156"],true);
end
end

if self.sdata.burnT then
self:playSnd("\235\182\136 \235\182\153\236\157\140",true);
else
self:stopSnd("\235\182\136 \235\182\153\236\157\140");
end

if AP>0 and self.tb["\234\183\188\236\160\145\236\134\140\237\153\152"]then
if world.player:getDistance(self)<=self.tb["\234\183\188\236\160\145\236\134\140\237\153\152P"].R then
self:spawn("\234\183\188\236\160\145\236\134\140\237\153\152","nspawned");
end
end

if AP>0 and self.tb["\236\152\181\236\133\152"]and self.tb["\236\152\181\236\133\152"]["\235\143\132\235\176\156"]then
local _,players=self:queryEnemy(self.tile,self.tb["\236\152\181\236\133\152"]["\235\143\132\235\176\156"]);
for i,p in safe_pairs(players)do
if world.ground.pathFinder:Raycast(self.tile.x,self.tile.y,p.tile.x,p.tile.y)then
p:aggro(self,99);
end
end
end
end


function Object:removeStorageItem(guid)
if guid==self.sdata.item then
self.sdata.item=nil;
self:die();
end
if self.sdata.items then
for k,v in pairs(self.sdata.items)do
if v==guid then
self.sdata.items[k]=0;
end
end
end
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]=nil;
self:updateFloatMenu(true);
end


function Object:die(now)
if not self.dying then
if world.ground.objMenu then
world.ground.objMenu:closeIfMe(self);
end
self:unplace();
self.skeleton:delChild();
world:delObject(self.guid);
self.dying=true;
if self.mcNick then
self.mcNick:Remove();
self.mcNick=nil;
end
if now then
self.died=true;
else
local easing=outQuad;
local function f(o,v)
self.mc:SetAlphaDepth(v);
end
local tweener=Tweener(self,f,1,0,self.dieT,0.1,easing);
tweener.onCompleted=function()
self.died=true;
end
self.timer.add(tweener,tweener.update);
end

if self.sdata.items then
for k,v in pairs(self.sdata.items)do
if v~=0 then
local o=world:createObject("\236\149\132\236\157\180\237\133\156",self.sdata.x,self.sdata.y,{item=v},true);
end
end
self.sdata.items=nil;
end
end
end


function Object:hasBuff()
end


function Object:delBuff()
end

function Object:getBuff(type)
return NPC.ev(self,type)or 0;
end

function Object:ev(k,child)
return NPC.ev(self,k,child);
end

function Object:bf(...)
return NPC.bf(self,...);
end

function Object:getType()
return self.sdata.id;
end

function Object:getTeam()
if self.data then
return self.data["\236\167\132\236\152\129"];
end
end



function Object:targetTurn(...)

end
function Object:isTurnBusy(...)

end

function Object:showFloating(...)
if self.canvas then
Character.showFloating(self,...);
end
end

function Object:showDebug(...)
Character.showDebug(self,...);
end
function Object:heal(v)
end

function Object:healEnergy(v)
end

function Object:setDisease()
end

function Object:onBuild(ids)
end


function Object:onDestroyed(dmg)
self:die();
end

function Object:addDamage(from,dmg)
if self.sdata.HP then
self:showFloating(tostringf(dmg),const("HP\234\176\144\236\134\140\236\131\137"));
local prevhp=self.sdata.HP;
self.sdata.HP=math.max(0,self.sdata.HP-dmg);
self:showHP(prevhp);
if self.sdata.HP<=0 then
self:onDestroyed(from,dmg);
end
end
end

function Object:onDamage(from)
local _vars=self.vars;
self.vars=from.vars;
local vars=self.vars;
if self.tb["\236\152\181\236\133\152"]then
local list={"\236\138\164\237\132\180","\236\136\152\235\169\180","\234\179\181\237\143\172"};
for k,v in pairs(list)do
if self.tb["\236\152\181\236\133\152"][v]then
if math.randpercent(self.tb["\236\152\181\236\133\152"][v])then
from:addDebuf(v,self);
end
end
end
end

if self.sdata.HP then
trace("onDamage",self.vars);
local guid=vars["\234\179\181\234\178\169 \235\172\180\234\184\176G"];
local w1=vars["\234\179\181\234\178\169 \235\172\180\234\184\176"];
local dmg;
if w1 then
local d=const("\236\152\164\235\184\140\236\160\157\237\138\184 \234\179\181\234\178\169 \236\136\152\236\185\152",itemtable[w1]["\236\162\133\235\165\152"]);
local dmgA=itemtable[w1]["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]*d;
local dmgB=itemtable[w1]["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]*d;
dmg=math.randrange(dmgA,dmgB);
else
if from~=world.player then
local d;
if from.sdata.boss then
d=const("\236\152\164\235\184\140\236\160\157\237\138\184 \234\179\181\234\178\169 \236\136\152\236\185\152","\235\179\180\236\138\164");
else
d=const("\236\152\164\235\184\140\236\160\157\237\138\184 \234\179\181\234\178\169 \236\136\152\236\185\152","\235\170\172\236\138\164\237\132\176");
end
local dmgA=(from:ev("\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\179\180\236\160\149")or 1)*d;
local dmgB=(from:ev("\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\179\180\236\160\149")or 1)*d;
dmg=math.randrange(dmgA,dmgB);
end
end
if guid then
DecreaseAttackObjectDurability(guid);
end
self:addDamage(from,dmg or 0);
elseif self.tb["\235\182\128\236\136\160\237\153\149\235\165\160"]then
local key=math.randlist(self.tb["\235\182\128\236\136\160\237\153\149\235\165\160"]);
if key=="\236\132\177\234\179\181"then
self:die();
elseif key=="\235\139\164\236\185\168"then
from:addDamage(nil,from:ev("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*const("\235\182\128\236\136\152\234\184\176\235\139\164\236\185\168\235\141\176\235\175\184\236\167\128"),nil,self.sdata.id);
end
end
self.vars=_vars;
end

function Object:getDistance(dest)
return math.floor(math.max(math.abs(dest.tile.x-self.tile.x),math.abs(dest.tile.y-self.tile.y)));
end