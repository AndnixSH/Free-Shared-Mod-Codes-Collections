
function RepairPopup(owner,guid,onOk,onCancel)
local prevScroll;
local selected={slot=guid};
local mode;
local materials={};
local repair=0;
local object;
owner.slot.dura:Duplicate("dura2");
owner.slot.dura:SetZOrder(1);

local function canSelect(guid)
if selected.slot then
if not table.find(selected,guid)then
return CanRepairMaterial(selected.slot,guid);
end
end
end

for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
mode=v;
break;
end
end

if object then
owner.name:SetText(object.tb.name);
if owner.icon then
local obj=UIObject(owner.icon);
obj:init(object.sdata.id);
obj.mc:SetScale(0.5,0.5);
obj.mc:SetPos(70,95);
end
end


local function initSlots()
local images=const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128");
for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
owner.myinven[v]:Clear();
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(owner.myinven[v],guid);
else
assert(images[v],v);
SetItemIconFromGuid(owner.myinven[v]);
owner.myinven[v].img:AddSymbol(images[v],"icon");
end
end
end
end

local function canMake()
if not selected.slot or not selected.slot2 then
return false;
end
for id,c in pairs(materials)do
if not HasItemType(id,c)then
return false;
end
end
return true;
end

local function updateMaterials()
if selected.slot then
materials=GetRepairMaterials(selected.slot);
else
materials={};
end
local o1=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][selected.slot];
repair=GetRepairAmount(selected.slot,selected.slot2);
owner.repair:SetText(string.format(_L("\236\152\136\236\131\129\235\130\180\234\181\172\235\143\132\237\154\140\235\179\181\235\159\137"),repair));

owner.sub:Clear();
MakeSubMaterialSlot(owner.sub,table.length(materials),materials);
do
SetItemIconFromGuid(owner.slot,selected.slot);
SetItemIconFromGuid(owner.slot2,selected.slot2);

local p1=math.min(1,o1["\235\130\180\234\181\172\235\143\132"]/const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132"));
local p2=math.min(1,(o1["\235\130\180\234\181\172\235\143\132"]+repair)/const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132"));
local x=owner.slot.dura:GetX();
local _,_,cx,cy=owner.slot.dura2:GetBound();
owner.slot.dura2:SetVisible(true);
owner.slot.dura2:SetAlphaColor(0xc0ffffff);
owner.slot.dura2:SetClipRect(cx*p1,0,cx*(p2-p1),cy);
owner.slot.dura2:SetX(x+cx*p1);

SetButton(owner.slot).onClick=function()
ShowItemInfo(selected.slot);
end
end

if canMake()then
owner.btnOk:enable(true);
owner.btnOk:GotoAndStop(1,true);
else
owner.btnOk:enable(false);
owner.btnOk:GotoAndStop(2,true);
end



end

local function initBag()
trace("initbag");
do
for k,v in ipairs(GetAvailStorageSlots())do
if mode==v then
owner.myinven[v].img:SetAlphaDepth(1);
elseif _S["\236\138\172\235\161\175"][v]~=0 then
owner.myinven[v].img:SetAlphaDepth(0.3);
else
owner.myinven[v].img:SetAlphaDepth(1);
end
end
end

owner.myinven.list:Clear();

local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local d=o and o["\234\176\128\235\176\169"];
SetMyInventoryWnd(owner.myinven.list,d);
if prevScroll then
owner.myinven.list.list.setScroll(prevScroll);
end
function owner.myinven.list.list:onScroll(s)
prevScroll=s;
end

local function setInfo(this,mc,guid)
if(guid or 0)~=0 then
assert(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid],guid);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local c=(o.c or 1);
if c>0 then
SetItemIconFromGuid(mc,guid);
SetItemIconCnt(mc.cnt,c);
else
SetItemIconFromGuid(mc);
end
else
SetItemIconFromGuid(mc);
end

if mc.enabled then
mc.img:SetAlphaDepth(1);
else
mc.img:SetAlphaDepth(0.3);
end
end

owner.myinven.list.list.onSelected=function(this,mc,guid)
if guid and guid~=0 and mc.enabled then
selected.slot2=guid;
updateMaterials();
owner.myinven.list.list:refresh();










return true;
end
end
owner.myinven.list.list.setInfo=function(this,mc,guid)
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemType=itemtable[data.id]["\236\162\133\235\165\152"];
local group=itemtable[data.id]["\234\183\184\235\163\185"];
mc.enabled=canSelect(guid);
setInfo(this,mc,guid);
end
end

updateMaterials();
owner.myinven.list:init();
end


local function changeMode(slot)
mode=slot;
prevScroll=nil;
selected={slot=guid};
initBag();
end

for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
SetButton(owner.myinven[v],nil,nil,nil,0,0).onClick=function()
if IsStorageSlot(v)then
if _S["\236\138\172\235\161\175"][v]~=0 then
changeMode(v);
end
end
end
end
end

function owner:onEvent(msg)
local f=function()
if owner then owner:init();end
end
if string.find(msg,"Item")then
mainTimer.addmc(owner,f);
end
end

function owner:onUnload()
eventDispatcher:del(self,self.onEvent);
end

function owner:init()
initSlots();
initBag();
end

SetTextButton(owner.btnOk,_L("\236\136\152\235\166\172")).onClick=function()
owner:onUnload();
if ConsumeItems(materials)then
owner:Remove();
onOk(selected.slot,selected.slot2,repair);
end
end

for k,v in pairs({"slot2"})do
SetButton(owner[v]).onClick=function()
selected[v]=nil;
updateMaterials();
owner.myinven.list.list:refresh();
end
end

SetButton(owner.myinven.btnClose).onClick=function()
owner:Remove();
onCancel();
end

eventDispatcher:add(owner,owner.onEvent);
owner:init();

end

