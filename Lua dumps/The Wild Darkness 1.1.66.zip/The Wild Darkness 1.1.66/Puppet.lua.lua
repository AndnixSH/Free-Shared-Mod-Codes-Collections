
Puppet=Object:new({
})

function Puppet:complete(menu,guid,...)
if menu=="\235\169\148\235\137\180_\237\155\136\235\160\168"then
if _S["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]>=const("\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184\236\134\140\235\170\168")then
local k=addSkillLevel(guid);
if k then
_S["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]=_S["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]-const("\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184\236\134\140\235\170\168");
local function cb()
world:resumeTurn();
end
world:pauseTurn();
TrainPopup(cb,guid,_L("\236\136\153\235\160\168\235\143\132\237\131\128\236\157\180\237\139\128"),k);
end
end
Object.complete(self,menu,guid,...);
elseif menu=="\235\169\148\235\137\180_\236\136\153\235\160\168\235\143\132\236\180\136\234\184\176\237\153\148"then
for k,v in pairs(_S["\236\136\153\235\160\168\235\143\132"])do
local d=getSkillGroupLevel(k,_S["\236\136\153\235\160\168\235\143\132"])-getSkillGroupLevel(k,_S["\236\139\156\236\158\145\236\136\153\235\160\168\235\143\132"]);
_S["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]=_S["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]+const("\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184\236\134\140\235\170\168")*d;
for kk,vv in pairs(v)do
_S["\236\136\153\235\160\168\235\143\132"][k][kk]=_S["\236\139\156\236\158\145\236\136\153\235\160\168\235\143\132"][k][kk];
end
end
updateSkill();
Object.complete(self,menu,guid,...);
else
Object.complete(self,menu,guid,...);
end
end

function Puppet:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\237\155\136\235\160\168"then
local btns={};
for i,k in ipairs(const("\236\136\153\235\160\168\235\143\132\235\170\169\235\161\157"))do
if addSkillLevel(k,0)then
table.insert(btns,k);
end
end
local function _ok(guid)
if _S["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]>=const("\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184\236\134\140\235\170\168")then
onOk(menu,guid);
else
world.player:addChat(_L("\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184\235\182\128\236\161\177"));
onCancel(menu);
end
end
SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\236\136\153\235\160\168\235\143\132",{object=self,keys=btns,detail2=string.format(_L("\237\152\132\236\158\172\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"),_S["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"])});
elseif menu=="\235\169\148\235\137\180_\236\136\153\235\160\168\235\143\132\236\180\136\234\184\176\237\153\148"then
local mc2=showPopupYN(world,{msg=_L("\236\136\153\235\160\168\235\143\132\236\180\136\234\184\176\237\153\148YN"),mcName="\236\160\128\236\163\188\237\149\180\236\160\156\237\140\157\236\151\133"},function()
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
onOk(menu);
elseif t.status=="nodia"then
onCancel(menu);
showPopupYN(world,{msg=lang.nodiaQ},function()
TryConnect(function()
local wnd=showPopup(world,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end);
end
end
local onF=function(t)
onCancel(menu);
end
HttpWaitAsync(world,
sendResetTrain(onS,onF),
lang.waitLoginInfo);
end);
end,onCancel);
mc2.btnOk:GotoAndStop(1);
mc2.btnOk.txt:SetText(servertable.ResetTrainPrice);
else
onOk(menu);
end
end

