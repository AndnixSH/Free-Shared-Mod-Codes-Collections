Cliff=Object:new({
})









function Cliff:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
world.ground:fillCliff(self.tile.x,self.tile.y);
end

function Cliff:complete(menu,ret)
Object.complete(self,menu);
end
function Cliff:onResetTurn(AP)
Object.onResetTurn(self,AP);
if not world.player:isFloatMode()and self.tile.x==world.player.tile.x and self.tile.y==world.player.tile.y then
local function cb()
_S["\236\131\157\235\170\133\235\160\165"]=math.max(0,_S["\236\131\157\235\170\133\235\160\165"]*(1-math.randrange(const("\235\130\173\235\150\160\235\159\172\236\167\128\235\141\176\235\175\184\236\167\128")[1],const("\235\130\173\235\150\160\235\159\172\236\167\128\235\141\176\235\175\184\236\167\128")[2])));
end
if not world:travelFromCliff(world.player,self.pos,cb)then
world.player:addChat(_L("\235\176\145\236\157\180 \235\179\180\236\157\180\236\167\128 \236\149\138\235\138\148\235\139\164"));
end
end
end

function Cliff:menuTouch(from,menu,onOk,onCancel)
trace("cliff::menuTouch"..menu);
if menu=="\235\169\148\235\137\180_\235\150\168\236\150\180\236\167\128\234\184\176"then
local function cb()
_S["\236\131\157\235\170\133\235\160\165"]=math.max(0,_S["\236\131\157\235\170\133\235\160\165"]*(1-math.randrange(const("\235\130\173\235\150\160\235\159\172\236\167\128\235\141\176\235\175\184\236\167\128")[1],const("\235\130\173\235\150\160\235\159\172\236\167\128\235\141\176\235\175\184\236\167\128")[2])));
end
if not world:travelFromCliff(from,self.pos,cb)then
world.player:addChat(_L("\235\176\145\236\157\180 \235\179\180\236\157\180\236\167\128 \236\149\138\235\138\148\235\139\164"));
onCancel(menu);
end
elseif menu=="\235\169\148\235\137\180_\235\176\167\236\164\132\235\161\156\235\130\180\235\160\164\234\176\128\234\184\176"then
local function cb()
if math.randpercent(ev("\235\176\167\236\164\132\235\161\156\235\130\180\235\160\164\234\176\128\234\184\176\235\176\167\236\164\132\237\154\141\235\147\157"))then
local guid=MakeItem("\235\176\167\236\164\132");
AddItemToStorage(guid);
end
end
if not world:travelFromCliff(from,self.pos,cb)then
world.player:addChat("\235\176\145\236\157\180 \235\179\180\236\157\180\236\167\128 \236\149\138\235\138\148\235\139\164");
onCancel(menu);
end
end
end

