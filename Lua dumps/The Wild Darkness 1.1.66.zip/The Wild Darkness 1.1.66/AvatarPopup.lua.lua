function AvatarPopup(owner,onOk,onCancel)
local maxPage=#avatartable;
local page=1;

local function updateAvatar()
local mc=owner;
mc.wnd:Clear();

local p=TestPlayer(mc.wnd:CreateEmptyMovieClip(""),page);
p:init();
for i=1,maxPage do
owner["page"..i]:SetAlphaColor(i==page and 0xFFFFFFFF or 0xFF444444);
end

end

function owner:init(first)
player:SetNextDeltaTimeZero();
local open=_D["\236\152\164\237\148\136\236\149\132\235\176\148\237\131\128"][page];
local free=_D["\237\154\141\235\147\157\236\149\132\235\176\148\237\131\128"][page];
local name=_L("\236\153\184\237\152\149").." "..page;
local tb=avatartable[page];
updateAvatar();
if not open and not free then
owner.btnOk:GotoAndStop(2,true);
local _1=_L("\236\153\184\237\152\149").." "..tb["\237\154\141\235\147\157\236\153\184\237\152\149"];
local _2=jobtable[tb["\237\154\141\235\147\157\236\167\129\236\151\133"]].name;
local _3=monstertable[tb["\237\154\141\235\147\157\235\179\180\236\138\164"]].name;
local dict={};
dict["{1}"]=_1;
dict["{2}"]=_2;
dict["{3}"]=_3;
dict["{\235\161\156}"]=(hasJongsung(_2)and not hasLiul(_2))and"\236\156\188\235\161\156"or"\235\161\156";
owner.txt:SetText(ReplaceString(_L("\236\149\132\235\176\148\237\131\128\237\154\141\235\147\157"),dict));
owner.wnd:SetAlphaColor(0xFF000000);
owner.cond:SetVisible(true);
else
owner.btnOk:GotoAndStop(1,true);
owner.txt:SetText(_L("\236\186\144\235\166\173\237\132\176 \236\153\184\237\152\149\236\157\132 \236\132\160\237\131\157\237\149\152\236\132\184\236\154\148."));
owner.wnd:SetAlphaColor(0xFFFFFFFF);
owner.cond:SetVisible(false);
end
owner.name:SetText(_L("\236\153\184\237\152\149").." "..page);


if open then
owner.btnOk.txt:SetText(_L("\237\153\149\236\157\184"));
elseif free then
owner.btnOk.txt:SetText(_L("\235\176\148\235\161\156 \236\152\164\237\148\136"));
else
owner.btnOk.txt:SetText(_L("\235\176\148\235\161\156 \236\152\164\237\148\136"));
local price=servertable.AvatarOpenPrice[page];
owner.btnOk.dia:SetText(price);
end
end

SetButton(owner.btnLeft).onClick=function(self)
page=math.max(1,page-1);
owner:init();
end

SetButton(owner.btnRight).onClick=function(self)
page=math.min(maxPage,page+1);
owner:init();
end

SetButton(owner.btnOk).onClick=function(self)
local open=_D["\236\152\164\237\148\136\236\149\132\235\176\148\237\131\128"][page];
local free=_D["\237\154\141\235\147\157\236\149\132\235\176\148\237\131\128"][page];
if open then
owner:Remove();
if onOk then
onOk(page);
end
else
if not free then
local mc2=showPopup(owner,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\236\149\132\235\176\148\237\131\128\236\152\164\237\148\136YN"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
_D["\236\152\164\237\148\136\236\149\132\235\176\148\237\131\128"][page]=_D["\236\152\164\237\148\136\236\149\132\235\176\148\237\131\128"][page]or 0;
owner:init();
else
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[t.status]or _L("\236\149\132\235\176\148\237\131\128\236\151\180\234\184\176\236\139\164\237\140\168"));
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendAvatarOpen(onS,onF,page),
lang.waitLoginInfo);
end);
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
else
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
_D["\236\152\164\237\148\136\236\149\132\235\176\148\237\131\128"][page]=_D["\236\152\164\237\148\136\236\149\132\235\176\148\237\131\128"][page]or 0;
owner:init();
else
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[t.status]or _L("\236\149\132\235\176\148\237\131\128\236\151\180\234\184\176\236\139\164\237\140\168"));
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendAvatarOpen(onS,onF,page,md5.sumhexa(myInfo.ukey..page)),
lang.waitLoginInfo);
end);
end
end
end

SetButton(owner.btnClose).onClick=function(self)
owner:Remove();
if onCancel then
onCancel();
end
end
owner:init(true);
end