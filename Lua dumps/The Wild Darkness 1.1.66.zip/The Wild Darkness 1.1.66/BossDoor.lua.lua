
require"actor.Door"

BossDoor=Door:new({
})

function BossDoor:init(guid,sdata,...)
Door.init(self,guid,sdata,...);
if world.ground:getTile(sdata.x+1,sdata.y)~=TT.WALL then
self:setArrow("left");
end

end


function BossDoor:checkPlayerInside(x,y)
if self.sdata.openPos then
x=x or _S.x;
y=y or _S.y;
local cx,cy=self.sdata.openPos.x-self.sdata.x,self.sdata.openPos.y-self.sdata.y;
local cx2,cy2=x-self.sdata.x,y-self.sdata.y;
return cx*cx2+cy*cy2<0;
end
end

function BossDoor:onResetTurn(AP)
if not self.sdata.closed and self:isCompleted()and self:checkPlayerInside()then
self.sdata.closed=true;
self:rebirth();
end
Door.onResetTurn(self,AP);
end

function BossDoor:open()
self.sdata.closed=true;
Door.open(self);
end

function BossDoor:useKey()
if self.sdata.closed then
if self.sdata.openPos and self.sdata.openPos.x==_S.x and self.sdata.openPos.y==_S.y then
return true;
elseif self:checkPlayerInside()then
world.player:addChat(_L("\236\157\180 \235\176\169\236\151\144 \234\176\135\237\158\140 \234\178\131 \234\176\153\235\139\164."));
end
else
return true;
end
end

function BossDoor:onTouchEnd(from)
if self:isCompleted()and not self.sdata.closed and self:checkPlayerInside(from.tile.x,from.tile.y)then
self.sdata.closed=true;
self:rebirth();

for i=1,#world.characs,1 do
local v=world.characs[i];
if not v.dying and v.trigger then
v:trigger(self.guid);
end
end
end
end

function BossDoor:touch(from,...)
if not self.sdata.closed or
self.sdata.openPos and self.sdata.openPos.x==_S.x and self.sdata.openPos.y==_S.y then
local cx,cy=_S.x-self.sdata.x,_S.y-self.sdata.y;
if math.abs(cx)<=1 and math.abs(cy)<=1 then
self.sdata.openPos={x=_S.x,y=_S.y};
do
local mx,my;
local minD;
for i=-1,1 do
for j=-1,1 do
if world.ground:canTileWalkable(self.sdata.x+i,self.sdata.y+j,from.movableBlock)and self:checkPlayerInside(self.sdata.x+i,self.sdata.y+j)then
local D=math.abs(i)+math.abs(j);
if not minD or minD>D then
minD=D;
mx,my=self.sdata.x+i,self.sdata.y+j;
end
end
end
end
if mx and my then
from:unplace();
local x,y=world.ground:TileToMap(mx,my);
from.center.x,from.center.y=x,y;
from.tile.x,from.tile.y=mx,my;
from:place();
end
end
end
end
self.sdata.closed=nil;
Door.touch(self,from,...);
end

