function fade(this,s,e,dur,c1,c2,lock,parent,onCompleted,autoClose,delay,timer)
local owner=this:CreateEmptyMovieClip("fade");

c1=c1 or{0,0,0,0}
c2=c2 or{0,0,0,255}
W=W or APP_W;
H=H or APP_H;
timer=timer or mainTimer;







local mcBack=owner:CreateEmptyMovieClip("_back");
do
mcBack:AddSymbol("white.png","img");
local _,_,w,h=mcBack.img:GetBound();
mcBack.img:SetPos(-2,-2);
mcBack.img:SetScale((APP_W+4)/w,(APP_H+4)/h);
end

if lock then
owner:SetMouseCapture(true);
owner.onMouseMove=function()return true;end
owner.onMouseUp=function()return true;end
owner.onMouseDown=function()return true;end
owner.onKeyDown=function(self,key)return true;end
owner.onKeyUp=function(self,key)return true;end
end

local f=function(self,s)
local r=math.floor(c1[1]+(c2[1]-c1[1])*s+0.5);
local g=math.floor(c1[2]+(c2[2]-c1[2])*s+0.5);
local b=math.floor(c1[3]+(c2[3]-c1[3])*s+0.5);
local a=math.floor(c1[4]+(c2[4]-c1[4])*s+0.5);
mcBack:SetAlphaColorRGBA(r,g,b,a);
end

tweener=Tweener(nil,f,s or 0,e or 1,dur or 0.5,delay or 0,outQuad);
tweener.onCompleted=function(self)
local f=function()
if autoClose then
trace("remove fade");
owner:Remove();
end
if onCompleted then
onCompleted();
end
end
timer.addmc(owner,f,0.02);
end
timer.addmc(owner,tweener.update,0);
owner.onUnload=function()
timer.removemc(owner);
end
f(nil,s or 0);
player:SetNextDeltaTimeZero();
return owner;
end

