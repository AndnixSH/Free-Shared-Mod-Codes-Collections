Pet=NPC:new({

findPathBlock=Block_Sight|Filter_MyPath,
})

function Pet:setDefaultTarget()
local x,y=world.ground:getNearestGotoTile(world.player.tile.x,world.player.tile.y,0,MAP_W,self.tile.x,self.tile.y,self.findPathBlock);
if x and y then
self.target={x=x,y=y};
else
self.target={x=world.player.tile.x,y=world.player.tile.y};
end
end
