function Maker(owner,tab)
local tabY=-5;
local tabs=const("\236\160\156\236\158\145\237\131\173\235\170\169\235\161\157");
local builder=nil;
local oldClick=world.onClick;
local mouseDown=world.mouseDown;
local mouseUp=world.mouseUp;
local mouseMove=world.mouseMove;
local reqBuildings=const("\236\160\156\236\158\145\237\131\173\237\149\132\236\154\148\234\177\180\235\172\188");
local mcTabs={};
local x=owner["\237\131\173_1"]:GetX();
local ShowDur=0.3;
local FootH=APP_H-owner.w:GetY()-100;
owner:SetY(APP_H);
for i,v in ipairs(reqBuildings)do
local mc=owner["\237\131\173_"..i];
if world.ui.menu["\236\167\147\234\184\176"..i]:GetVisible()then
mc:SetX(x);
mc:SetVisible(true);
x=x+105;






if world.ui.menu["\236\167\147\234\184\176"..i].count:GetVisible()then
mc:AddSymbol("\236\160\156\236\158\145\234\176\128\235\138\165\236\136\152","count");
mc.count.txt:SetText(world.ui.menu["\236\167\147\234\184\176"..i].count.txt:GetText());
end

if world.ui.menu["\236\167\147\234\184\176"..i].ready:GetVisible()then
mc:AddSymbol("\236\160\156\236\158\145\236\164\128\235\185\132","ready");
mc.ready:SetPos(world.ui.menu["\236\167\147\234\184\176"..i].ready:GetPos());
end
if world.ui.menu["\236\167\147\234\184\176"..i].new:GetVisible()then
mc:AddSymbol("\236\160\156\236\158\145\235\137\180\235\160\136\236\132\156\237\148\188","new");
end
else
mc:SetVisible(false);
end
table.insert(mcTabs,mc);
end

function owner:onEnterFrame(dt)
if builder then
builder:update(dt);
end
end
local function hide()
local yfrom=owner:GetY();
local yto=APP_H+100;
local dur=ShowDur;
local easing=outQuad;
local tweener=Tweener(owner,owner.SetY,yfrom,yto,dur,0,easing);
world.timer.add(tweener,tweener.update);
tweener.update(0);
end

local function setTab(idx)
for k,v in pairs(mcTabs)do
if k==idx then
v:GotoAndStop(1);
else
v:GotoAndStop(2);
end
end

if builder then
builder:close();
builder=nil;
end
if owner.w.w then
owner.w.w:close();
owner.w.w:Remove();
end
owner.w:CreateEmptyMovieClip("w");
owner.w:SetClipRect(0,-30,APP_W,APP_H);
SetVScrollView(owner.w.w);
owner.tab:Clear();
ItemBuilderList(owner.w.w,owner.tab,idx);
owner.w.w.setScrollBarPos(APP_W-10);
owner.w.w.setViewLimit(FootH);


function owner.w.w:onTabChanged()
for i,v in ipairs(reqBuildings)do
local mc=owner["\237\131\173_"..i];
if world.ui.menu["\236\167\147\234\184\176"..i]:GetVisible()then
if mc.new and not world.ui.menu["\236\167\147\234\184\176"..i].new:GetVisible()then
mc.new:Remove();
end
end
end













end

owner.w.w:make();

function owner.w.w:select(id)
if builder then
builder:close();
builder=nil;
end
end
function owner.w.w:put(rid,...)
id=recipetable[rid]["\236\158\165\235\185\132"];
builder={};
function builder:onCancel()
owner.btnClose:onClick();
end
if itemtable[id]then
builder=ItemBuilder(builder);
if builder then
builder:put(rid,...);
end
elseif objecttable[id]then
builder=ObjectBuilder(builder);
if builder then
hide();
builder:put(rid,...);
end
end

end















end

local function init()
world:hideMenu(true);
world:hideStat(true);
for k,v in pairs(mcTabs)do
SetButton(v).onClick=function()
setTab(k);
end
end
setTab(tab or 1);
do
do
local x,y,w,h=owner:GetAABB();
local yto=APP_H-owner.w:GetY()-FootH;
local dur=ShowDur;
local easing=outQuad;
local tweener=Tweener(owner,owner.SetY,owner:GetY(),yto,dur,0,easing);
tweener.onCompleted=function()
if owner.w.w.onShow then
owner.w.w:onShow();
end
end
world.timer.add(owner,tweener.update);
tweener.update(0);
end

function world:mouseDown(x,y)
if builder then
return builder:mouseDown(x,y);
end
end;
function world:mouseMove(x,y)
if builder then
return builder:mouseMove(x,y);
end
end;
function world:mouseUp(x,y)
if builder then
return builder:mouseUp(x,y);
else
owner.btnClose:onClick();
end
end;






end


end

function owner:onMouseDown(x,y,id)
return y>=0;
end

function owner:onMouseUp(x,y,id)
return y>=0;
end

function owner:onMouseMove(x,y,id)
return y>=0;
end

SetButton(owner.btnClose).onClick=function()
world.mouseMove=mouseMove;
world.mouseDown=mouseDown;
world.mouseUp=mouseUp;
if builder then
builder:close();
end

if owner.w.w then
owner.w.w:close();
end
world.onClick=oldClick;
world:hideMenu(false);
world:hideStat(false);
owner:Remove();
end

init();
end