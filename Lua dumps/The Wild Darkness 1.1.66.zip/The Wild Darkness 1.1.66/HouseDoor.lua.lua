HouseDoor=Object:new({
})

function HouseDoor:menuTouch()

_S.x,_S.y=self.tile.x,self.tile.y-1;
world.gameEnded=true;
world.isTraveling=true;
local function f()
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local data=_S.maps[mapId];
_G.nextMap=data["\236\131\129\236\156\132"];
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

