
MerchantEx=Object:new({
spineScale=0.5,
})

function MerchantEx:init(guid,sdata,...)
Object.init(self,guid,sdata,...);

if not self.sdata.allitems then
self.sdata.cnt=0;
self.sdata.allitems={};
local tb=dropwelltable[self.sdata.id];
for k,v in pairs(tb["\234\181\144\236\178\1801"])do
self.sdata.allitems[k]=countkcc(v[2]);
end
end
self.sdata.items=self.sdata.items or{};
self:makeGroup();
end


function MerchantEx:makeGroup()
local tb=dropwelltable[self.sdata.id];
while true do
local c=countkcc(tb["\234\176\156\236\136\1521"]);
local empty;
for i=1,c,1 do
if(self.sdata.items[i]or 0)==0 then
empty=i;
break;
end
end
if not empty then
break;
end
local list={};
for k,v in pairs(self.sdata.allitems)do
if v>0 then
local p=tb["\234\181\144\236\178\1801"][k][1];
list[k]=p;
if tb["\234\181\144\236\178\1801"][k][3]and tb["\234\181\144\236\178\1801"][k][3]<=self.sdata.cnt then
list={[k]=1};
break;
end
end
end
if table.empty(list)then
break;
end
local group=math.randlist(list);
self.sdata.cnt=self.sdata.cnt+1;
self.sdata.allitems[group]=self.sdata.allitems[group]-1;
local id=table.choice(string.split(group,","));
local itemGuid=MakeItem(id,"\236\131\129\236\157\184");
assert(itemGuid,id);
self.sdata.items[empty]=itemGuid;
end
end

function MerchantEx:menuTouch(from,menu,onOk,onCancel)
do
self:makeGroup();
local mc=showPopup(world.ui,"\235\179\180\234\180\128\237\149\168\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
MerchantPopup(mc,self);
SetButton(mc.myinven.btnClose).onClick=function()
mc:Remove();
onCancel();
end
end
end