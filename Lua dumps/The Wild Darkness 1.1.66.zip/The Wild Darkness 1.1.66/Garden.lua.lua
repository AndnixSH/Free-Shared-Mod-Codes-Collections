Garden=Object:new({
})

function Garden:complete(menu,...)
Object.complete(self,menu,...);
if menu=="\235\169\148\235\137\180_\236\148\168\236\149\151\236\139\172\234\184\176"then
local function place()
local id=math.randlist(const("\237\133\131\235\176\173 \236\149\132\236\157\180\237\133\156 \237\153\149\235\165\160"));
local itemGuid=MakeItem(id);
local o=world:createObject("\236\149\132\236\157\180\237\133\156",self.tile.x,self.tile.y,{z=self.tb["\235\134\146\236\157\180"]or 1,item=itemGuid,["\236\160\128\236\158\165\236\139\156\234\176\132"]=self.tb["\236\160\128\236\158\165\236\139\156\234\176\132"]})
o.item=itemGuid;
end
place();
if math.randpercent(bf("\237\133\131\235\176\173 \236\182\148\234\176\128 \236\149\132\236\157\180\237\133\156 \237\154\141\235\147\157")*100)then
place();
end
end
end

