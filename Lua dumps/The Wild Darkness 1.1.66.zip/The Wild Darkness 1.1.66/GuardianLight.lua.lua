GuardianLight=Object:new({
})

function GuardianLight:init(...)
Object.init(self,...);
end

function GuardianLight:rebirth(...)
Object.rebirth(self,...);
self.sdata.activeT=countkcc(self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"].T);
end


function GuardianLight:trigger()
self:rebirth();
end

function GuardianLight:canTouch()
end


function GuardianLight:complete(...)
Object.complete(self,...);
local ids={};
for k,v in pairs(_S.maps[_S["\237\152\132\236\158\172\235\167\181"]].objects)do
if v.id==self.sdata.id then
local o=world:findObject(k);
if o and(o==self or o:isCompleted())then
table.insert(ids,o);
end
end
end


for k,v in ipairs(ids)do
if v==self then
(ids[k+1]or ids[1]):rebirth();
break;
end
end
end

function GuardianLight:onResetTurn(AP)
Object.onResetTurn(self,AP);
if AP>0 and not self:isCompleted()and self.sdata.activeT then
self.sdata.activeT=self.sdata.activeT-AP;
if self.sdata.activeT<=0 then
self:action();
end
end
end
