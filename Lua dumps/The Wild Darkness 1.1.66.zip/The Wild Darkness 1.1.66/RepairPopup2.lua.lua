function RepairPopup2(owner,guid,onOk,onCancel)
local reserved=reserved or{};
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[o.id];
local itemList={};
local myItems=GetMyItems();

local function close()
owner:Remove();
end

local function makeMaterial()
trace("\236\158\172\235\163\140",recipetable[o.id]["\236\158\172\235\163\140"]);
if not o["\236\136\152\235\166\172\236\158\172\235\163\140"]then
local list={};
local m=recipetable[o.id]["\236\158\172\235\163\140"];
trace("\236\158\172\235\163\140",m);
local idx=((ItemTier(guid)or 0)*2)-1;
if item["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
m=m[idx]or{};
end
for k,v in pairs(m)do
for i=1,v do
table.insert(list,k);
end
end
table.choicen(list,math.ceil(#list*0.7));
o["\236\136\152\235\166\172\236\158\172\235\163\140"]={};
for k,v in pairs(list)do
o["\236\136\152\235\166\172\236\158\172\235\163\140"][v]=(o["\236\136\152\235\166\172\236\158\172\235\163\140"][v]or 0)+1;
end
end
return o["\236\136\152\235\166\172\236\158\172\235\163\140"];
end
local materials=makeMaterial();

local function reserveItem(id)
id=UnidentityItemId(id);
for k,v in pairs(myItems)do
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][k];
if o.id==id or table.find(const(id),o.id)then
if(o.c or 1)>(reserved[k]or 0)then
reserved[k]=(reserved[k]or 0)+1;
return k;
end
end
end
end

SetItemIconFromGuid(owner.icon,guid);
owner.icon.name:SetText(ItemName(guid));

local function updateMaterials()
reserved={};
itemList={};
for _,k in ipairs(table.sortedkeys(materials,CmpItemPriority))do
local v=materials[k];
local guids={};
for i=1,v,1 do
local guid=reserveItem(k);
if guid then
table.insert(guids,guid);
end
end
table.insert(itemList,{guids,k,v});
end
end

local function canMake()
for k,v in ipairs(itemList)do
local guids,id,cnt=table.unpack(v);
if#guids<cnt then
return false;
end
end
return true;
end

local function updateBtn()
if canMake()then
owner.btnOk:enable(true);
owner.btnOk:GotoAndStop(1,true);
else
owner.btnOk:enable(false);
owner.btnOk:GotoAndStop(2,true);
end
end

local function updateItem(mc,v)
local guids,id,cnt=table.unpack(v);
if#guids==0 then
if not itemtable[id]and const(id)then
id=const(id)[1];
end
AddItemIcon(mc.img,id,nil,itemtable[id].name);
else
AddItemIconFolder(mc.img,guids,cnt);
end
mc.cnt:SetVisible(true);
mc.cnt:SetText(#guids.."/"..cnt);
if#guids<cnt then
if HasItemTypeInBox(id,cnt)then
mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\131\129\236\158\144\234\176\128\235\138\165\236\131\137"));
else
mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\151\134\236\157\140\236\131\137"));
end
else
mc.cnt:SetFillColor(0xFFFFFFFF);
end
end

function owner:make()
updateMaterials();
owner.sub:Clear();
MakeSubMaterialSlot(owner.sub,#itemList);
for k,v in ipairs(itemList)do
local mc=owner.sub["w"..k];
if mc then
updateItem(mc,v);
local guids,reqId=table.unpack(v);
if not itemtable[reqId]and const(reqId)then
SetButton(mc).onClick=function()
local function _ok()
for k,v in pairs(guids)do
reserved[v]=(reserved[v]or 0)+1;
end
self:make();
end
local function _refresh()
updateItem(mc,v);
end
for k,v in pairs(guids)do
reserved[v]=reserved[v]-1;
end
SelectMaterialPopup(world,_refresh,_ok,nil,v,reserved);
end
end
end
end
updateBtn();
end

SetTextButton(owner.btnOk,_L("\236\136\152\235\166\172")).onClick=function()
close();
onOk(guid,reserved);
end

SetButton(owner.btnClose).onClick=function()
close();
onCancel();
end

owner:make();

end