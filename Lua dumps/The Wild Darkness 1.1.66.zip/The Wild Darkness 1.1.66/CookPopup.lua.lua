function CookPopup(owner,object,onOk,onCancel,menu,maxMaterials)
local prevScroll;
local selected={};
local empty=0;
local mode;
local recipes={};
local materials={};
maxMaterials=maxMaterials or 1;
owner.time:SetText(string.format(_L("\236\160\156\236\158\145\236\139\156\234\176\132\237\145\156\236\139\156"),safe_getfield(object.tb["\235\169\148\235\137\180\236\191\168"],"menu")or 10));
do
local mcs={};
for i=1,9,1 do
local mc=owner["s"..i];
table.insert(mcs,mc);
mc:SetVisible(i<=maxMaterials);
end
Align(mcs,"left,hcenter,vcenter",{10,10});
end





for k,v in pairs(cooktable)do
if table.find(v["\236\160\156\236\158\145 \236\139\156\236\132\164"],object.sdata.id)then
recipes[k]=v;
for i,v in pairs(table.append({},v["\236\158\172\235\163\140"],v["\237\130\164\236\158\172\235\163\140"]))do
for k,c in pairs(v)do
for i,id in safe_pairs(const(k)or k)do
materials[id]=true;
end
end
end
end
end


local function countItem(reserved,id,maxCnt)
local list={};
local c=0;
for i,guid in ipairs(selected)do
if not reserved[i]and not list[i]then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o and table.find(const(id)or id,o.id)then
list[i]=true;
c=c+1;
if c>=maxCnt then
break;
end
end
end
end
trace("countItem",selected,reserved,id,c);
return c,list;
end

local function reserveItem(reserved,list)
for id,c in pairs(list)do
local n,t=countItem(reserved,id,c);
if n>=c then
table.copy(t,reserved);
return true;
end
end
end

local function reserveItems(list)
local reserved={};
trace("reserveItems",selected,list);
for i,v in ipairs(list)do
if not reserveItem(reserved,v)then
trace("not reserveItems",reserved,v);
return false;
end
end
local same=true;
local c=0;
for i,guid in ipairs(selected)do
if not reserved[i]then
same=false;
else
c=c+1;
end
end
return true,same,c,reserved;
end

local function findFood()
local skeys=table.sortedkeys(recipes,function(a,b)
local p1=recipes[a].priority or 0;
local p2=recipes[b].priority or 0;
return p1<p2;
end);

for _,k in ipairs(skeys)do
local v=recipes[k];
if v["\237\131\128\236\158\133"]=="\237\138\185\236\136\152\236\154\148\235\166\172"then
local b,same,c,reserved=reserveItems(v["\236\158\172\235\163\140"]);
if b then
return k,reserved;
end
end
end

do
local matched;
for _,k in ipairs(skeys)do
local v=recipes[k];
if v["\237\130\164\236\158\172\235\163\140"]then
local b=reserveItems(v["\237\130\164\236\158\172\235\163\140"]);
if b then
if matched and not table.equal(matched["\237\130\164\236\158\172\235\163\140"],v["\237\130\164\236\158\172\235\163\140"])then
return"\234\191\128\234\191\128\236\157\180 \236\163\189";
else
matched=v;
end
end
end
end
end


do
local maxC=0;
local maxK,maxR;

for _,k in ipairs(skeys)do
local v=recipes[k];
if v["\237\131\128\236\158\133"]=="\236\154\148\235\166\172"and(v["\236\158\172\235\163\140"]or v["\237\130\164\236\158\172\235\163\140"])then
local b,same,cnt,reserved=reserveItems(table.append({},v["\237\130\164\236\158\172\235\163\140"],v["\236\158\172\235\163\140"]));
trace("\236\154\148\235\166\172\234\178\128\236\130\172",k,b);
if b then
if cnt>maxC then
maxC=cnt;
maxK=k;
maxR=reserved;
end
end
end
end
if maxK then
return maxK,maxR;
end
end
do

local list;
for i,guid in ipairs(selected)do
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
for _,id in ipairs(skeys)do
local v=recipes[id];
if v["\237\131\128\236\158\133"]=="\234\181\172\236\157\180"then
for k,v in pairs(v["\236\158\172\235\163\140"][1])do
if k==o.id then
list=list or{};
list[i]=id;
end
end
end
end





end
end
return list;
end
end


local function canBuy(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local c=(o.c or 1)-table.count(selected,guid);
return materials[o.id]and c>0;
end
end
local function canMake()
return findFood()~=nil;
end

for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
mode=v;
break;
end
end

owner.name:SetText(object.tb.name);
if owner.icon then
local obj=UIObject(owner.icon);
obj:init(object.sdata.id);
obj.mc:SetScale(0.5,0.5);
obj.mc:SetPos(70,95);
end

local function initSlots()
local images=const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128");
for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
owner.myinven[v]:Clear();
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(owner.myinven[v],guid);
else
assert(images[v],v);
SetItemIconFromGuid(owner.myinven[v]);
owner.myinven[v].img:AddSymbol(images[v],"icon");
end
end
end
end
local function updateMaterials()
for i=1,maxMaterials,1 do
local mc=owner["s"..i];
if selected[i]and selected[i]~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][selected[i]];
AddItemIcon(mc.img,o.id,nil,ItemName(selected[i]));
else
AddItemIcon(mc.img);
end
end
local k=findFood();
if type(k)=="table"then
AddCookIconFolder(owner.slot.img,k,#k);
else
AddCookIcon(owner.slot.img,k);
end
SetButton(owner.slot).onClick=function()
if type(k)~="table"and k and itemtable[k]then
ShowItemInfo(k);
end
end
if canMake()then
owner.btnOk:enable(true);
owner.btnOk:GotoAndStop(1,true);
else
owner.btnOk:enable(false);
owner.btnOk:GotoAndStop(2,true);
end
end

for i=1,maxMaterials,1 do
local mc=owner["s"..i];
SetButton(mc).onClick=function()
if selected[i]and selected[i]~=0 then
table.remove(selected,i);
owner.myinven.list.list:refresh();
updateMaterials();
end
end
end

local function initBag()
trace("initbag");
do
for k,v in ipairs(GetAvailStorageSlots())do
if mode==v then
owner.myinven[v].img:SetAlphaDepth(1);
elseif _S["\236\138\172\235\161\175"][v]~=0 then
owner.myinven[v].img:SetAlphaDepth(0.3);
else
owner.myinven[v].img:SetAlphaDepth(1);
end
end
end

owner.myinven.list:Clear();

local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local d=o and o["\234\176\128\235\176\169"];
SetMyInventoryWnd(owner.myinven.list,d);
empty=0;
for k,v in safe_pairs(d)do
if v==0 then
empty=empty+1;
end
end
if prevScroll then
owner.myinven.list.list.setScroll(prevScroll);
end
function owner.myinven.list.list:onScroll(s)
prevScroll=s;
end

local function setInfo(this,mc,guid)
if(guid or 0)~=0 then
assert(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid],guid);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local c=(o.c or 1)-table.count(selected,guid);
if c>0 then
SetItemIconFromGuid(mc,guid);
SetItemIconCnt(mc.cnt,c);
else
SetItemIconFromGuid(mc);
end
else
SetItemIconFromGuid(mc);
end

if mc.enabled then
mc.img:SetAlphaDepth(1);
else
mc.img:SetAlphaDepth(0.3);
end
end

owner.myinven.list.list.onSelected=function(this,mc,guid)
if guid and guid~=0 and mc.enabled then
if#selected<maxMaterials then
table.insert(selected,guid);
owner.myinven.list.list:refresh();
updateMaterials();
return true;
end
end
end
owner.myinven.list.list.setInfo=function(this,mc,guid)
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemType=itemtable[data.id]["\236\162\133\235\165\152"];
local group=itemtable[data.id]["\234\183\184\235\163\185"];
mc.enabled=canBuy(guid);
setInfo(this,mc,guid);
end
end


updateMaterials();
owner.myinven.list:init();
end


local function changeMode(slot)
mode=slot;
prevScroll=nil;

initBag();
end


for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
SetButton(owner.myinven[v],nil,nil,nil,0,0).onClick=function()
if IsStorageSlot(v)then
if _S["\236\138\172\235\161\175"][v]~=0 then
changeMode(v);
end
end
end
end
end

function owner:onEvent(msg)
local f=function()
if owner then owner:init();end
end
if string.find(msg,"Item")then
mainTimer.addmc(owner,f);
end
end

function owner:onUnload()
eventDispatcher:del(self,self.onEvent);
end

function owner:init()
initSlots();
initBag();
end

SetButton(owner.myinven.btnClose).onClick=function()
owner:Remove();
onCancel();
end

SetTextButton(owner.btnOk,_L("\236\160\156\236\158\145")).onClick=function()
owner:onUnload();
owner:Remove();
local ids={};
while true do
local k,reserved=findFood();
if not k then
break;
end
if type(k)=="table"then
for k,id in pairs(k)do
local guid=selected[k];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if recipes[id]and recipes[id]["\234\184\176\237\131\128\237\154\141\235\147\157"]then
id=math.randlist(recipes[id]["\234\184\176\237\131\128\237\154\141\235\147\157"],100)or id;
end

ConsumeItem(guid,1,itemtable[id]["\235\185\132\236\154\176\234\184\176"]or true);
table.insert(ids,{id,{o}});
selected[k]=nil;
end
else
local id=k;
if recipes[id]and recipes[id]["\234\184\176\237\131\128\237\154\141\235\147\157"]then
id=math.randlist(recipes[id]["\234\184\176\237\131\128\237\154\141\235\147\157"],100)or id;
end
local t={};
for i,guid in pairs(selected)do
if not reserved or reserved[i]then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
table.insert(t,o);
ConsumeItem(guid,1,itemtable[id]["\235\185\132\236\154\176\234\184\176"]or true);
selected[i]=nil;
end
end
table.insert(ids,{id,t});
end
local remains={};
for i,v in pairs(selected)do
table.insert(remains,v);
end
selected=remains;
end
onOk(ids);





end

eventDispatcher:add(owner,owner.onEvent);
owner:init();

end

