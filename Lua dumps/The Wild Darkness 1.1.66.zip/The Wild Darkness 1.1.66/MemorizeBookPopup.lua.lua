

local function selectSlot(onSelect)
local popup=showPopup(world,"\235\167\136\235\178\149\236\138\172\235\161\175\236\132\160\237\131\157\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H},fnTweener=function()end});
popup.txt:SetText(_L("\235\176\176\236\154\184 \236\138\172\235\161\175\236\157\132 \236\132\160\237\131\157\237\149\180 \236\163\188\236\132\184\236\154\148"));
SetButton(popup.btnClose).onClick=function()
popup:Remove();
end

for i=1,const("\236\181\156\235\140\128\236\149\148\234\184\176\235\167\136\235\178\149"),1 do
local v="\235\167\136\235\178\149"..i;
local mc=world.ui.menu[v];
local sname=mc:GetSymbolName();
local btn=popup:AddSymbol(sname,v);
AddSpellIcon(btn,_S["\236\149\148\234\184\176\235\167\136\235\178\149"][i]);
btn:SetScale(mc:GetScale());
btn:SetOrigin(mc:GetOrigin());
btn:SetPos(mc:GetPos());
btn:AddSymbol("\237\153\148\236\130\180\237\145\156\236\156\132\236\149\132\235\158\152\236\149\160\235\139\136","ani");
btn.ani:SetPos(50,0);
SetButton(btn,nil,nil,nil,0,0).onClick=function()
popup:Remove();
onSelect(i);
end
end
end

function showSpellPopup(owner,onOk,id,txtBtn)
local mc=showPopup(owner,"\235\167\136\235\178\149\236\160\149\235\179\180\237\140\157\236\151\133");
local spell=spelltable[id];

AddSpellIcon(mc.icon,id);
mc.name:SetText(spell.name);
mc.canvas:SetText(spell["\236\132\164\235\170\133"]);

local mglv=_G["mglv"];
_G["mglv"]=math.min(ev("\236\139\164\236\160\156\236\181\156\235\140\128\235\167\136\235\178\149\235\160\136\235\178\168"),(_S["\235\167\136\235\178\149"][id]or 0));
local reqEnergy=spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"]or 0;
_G["mglv"]=mglv;

mc.lv:SetText(string.format(_L("\235\160\136\235\178\168fmt"),_S["\235\167\136\235\178\149"][id]or 0));
mc.lv:SetVisible((_S["\235\167\136\235\178\149"][id]or 0)>0);
mc.energy:SetText(string.format(_L("\236\151\144\235\132\136\236\167\128fmt"),tostringf(reqEnergy)))
mc.equip:SetVisible(table.find(_S["\236\149\148\234\184\176\235\167\136\235\178\149"],id));

SetButton(mc.btnClose).onClick=function()
mc:Remove();
end
SetTextButton(mc.btnOk,txtBtn or _L("\235\176\176\236\154\176\234\184\176")).onClick=function()
mc:Remove();
if onOk then
local slot=table.find(_S["\236\149\148\234\184\176\235\167\136\235\178\149"],id);
if slot then
owner:Remove();
onOk(slot,id);
elseif#_S["\236\149\148\234\184\176\235\167\136\235\178\149"]>=const("\236\181\156\235\140\128\236\149\148\234\184\176\235\167\136\235\178\149")then
local function onSelect(idx)
owner:Remove();
onOk(idx,id);
end
selectSlot(onSelect);
else
owner:Remove();
onOk(#_S["\236\149\148\234\184\176\235\167\136\235\178\149"]+1,id);
end
end
end
return mc;
end

function MemorizeBookPopup(owner,object,onOk,onCancel)
owner.name:SetText(object.tb.name);
local names={"a","b","c"};







for k,v in pairs(spelltable)do
if v["\235\139\168\234\179\132"]then
local lv=v["\235\139\168\234\179\132"];
local mc=owner[names[lv]..v["\236\138\172\235\161\175"]];
AddSpellIcon(mc,k);
if table.find(_S["\236\149\148\234\184\176\235\167\136\235\178\149"],k)then
mc.img:SetAlphaColor(0xFF404040);
mc.back:SetAlphaDepth(0.3);
elseif(_S["\235\167\136\235\178\149"][k]or 0)>0 then
SetButton(mc).onClick=function()
showSpellPopup(owner,onOk,k);
end
else
mc.img:SetVisible(false);

mc.back:SetAlphaDepth(0.3);
end
end
end
SetButton(owner.btnClose).onClick=function()
owner:Remove();
onCancel();
end
end

function ReadBookPopup(owner,name,keys,onOk,onCancel)
owner.name:SetText(name);
owner.title:SetText(_L("\236\149\148\234\184\176\237\149\160 \235\167\136\235\178\149\236\157\132 \236\132\160\237\131\157\237\149\180 \236\163\188\236\132\184\236\154\148"));
local names={"a","b","c"};






for k,v in pairs(spelltable)do
if v["\235\139\168\234\179\132"]then
local lv=v["\235\139\168\234\179\132"];
local mc=owner[names[lv]..v["\236\138\172\235\161\175"]];
AddSpellIcon(mc,k);
AddMagicLevelIcon(mc.img,_S["\235\167\136\235\178\149"][k]or 0);
if table.find(keys,k)then
SetButton(mc).onClick=function()
showSpellPopup(owner,onOk,k);
end
elseif table.find(_S["\236\149\148\234\184\176\235\167\136\235\178\149"],k)then
mc.img:SetAlphaColor(0xFF404040);
mc.back:SetAlphaDepth(0.3);
else
mc.img:SetVisible(false);

mc.back:SetAlphaDepth(0.3);
end
end
end

SetButton(owner.btnClose).onClick=function()
owner:Remove();
onCancel();
end
end