

Overload=Object:new({
})

function Overload:init(...)
Object.init(self,...);
self.sdata.LifeT=self.sdata.LifeT or countkcc(self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"].T);
end

function Overload:onResetTurn(AP)
Object.onResetTurn(self,AP);
if self.sdata["\235\182\128\235\170\168"]then
local parent=world:findCharac(self.sdata["\235\182\128\235\170\168"]);
if parent then
if parent.tile.x==self.tile.x and parent.tile.y==self.tile.y then
local t=table.choice(self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]["\235\182\128\235\170\168\235\178\132\237\148\132"]);
for k,v in pairs(t)do
parent:addBuff(k,self.guid,v);
end
else
parent:delBuff(nil,self.guid);
end
end
end
end

