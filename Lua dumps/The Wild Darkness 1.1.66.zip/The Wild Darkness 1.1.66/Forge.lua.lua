
Forge=Object:new({
})

function Forge:complete(menu,id)
local lv=_S["\235\160\136\236\132\156\237\148\188"][id]or 0;
local maxLv=GetRecipeMaxLv(id);
local recipe=recipetable[id];

local grade="\236\158\165\235\185\132";
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]then
grade=recipe["\235\147\177\234\184\137"];
end
local nextLv=math.min(maxLv,lv+countkcc(const("\236\158\165\235\185\132\236\160\156\236\158\145\235\178\149\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156",grade)));

_S["\235\160\136\236\132\156\237\148\188"][id]=nextLv;
Object.complete(self);

local function cb()
world:resumeTurn();
end
world:pauseTurn();
ItemMessagePopup(cb,id,_L("\236\160\156\236\158\145\235\178\149\234\176\149\237\153\148\237\131\128\236\157\180\237\139\128"),{{_L("\235\160\136\235\178\168"),lv,nextLv}});
end

function Forge:menuTouch(from,menu,onOk,onCancel)






if not self.sdata.recipes then
self.sdata.recipes={};
for i=1,self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]or 3,1 do
local recipe=recipetable[id];
local tier=ChoiceItemTier(ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \237\139\176\236\150\180 \234\178\176\236\160\149_\234\179\160\234\184\137"));
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local areaN=_S.maps[mapId]["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local list={};
for k,v in pairs(drop1table)do
if v["\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149 \236\151\172\235\182\128"]then
list[k]=v[mapType]or v["\234\184\176\237\131\128 \235\141\152\236\160\132"];
end
end
trace("\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149 \235\170\169\235\161\157",list);
local group=math.randlist(list);
table.insert(self.sdata.recipes,ChoiceMapTierItem({"\236\160\156\236\158\145","\237\138\185\236\136\152"},group,tier,areaN));
end
end

local btns={};
for k,v in ipairs(self.sdata.recipes)do
table.insert(btns,v);
end
local function _ok(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\236\160\156\236\158\145\235\178\149\236\132\160\237\131\157",{object=self,keys=btns});
end


