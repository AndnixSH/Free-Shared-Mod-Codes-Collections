function GenerateMap(seed,oldMap)
















local mapId=_S["\237\152\132\236\158\172\235\167\181"];
trace("GenerateMap('"..mapId.."',"..seed..")");
brogue.init(seed,MAP_W,MAP_H);


local gates={};
local startx,starty,starta=nil,nil,"right";
local endx,endy,enda=nil,nil,"right";
local objects=nil;
local npcs=nil;
local rooms=nil;
local reservedTiles=nil;
local wsamples=nil;
local posReserved=nil;
local mData=_S.maps[mapId];
local bpName=mData["\236\132\164\234\179\132\235\143\132"];
local mapLv=mData["\235\167\181 \235\160\136\235\178\168"];
local bp=mapbptable[bpName];
local mapType=mData["\237\131\128\236\158\133"];
local mapTile=mData["\234\181\172\236\132\177"];
local area=mData["\236\167\128\236\151\173"];
local areaN=mData["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local field=mData["\237\149\132\235\147\156"];
local dgtype=mData["\235\141\152\236\160\132\237\131\128\236\158\133"];
local maptb=maptable[area];

local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",mapType);
local typeB=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152B",mapType);
local typeC=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);
trace("mapType",mapType,"typeA",typeA,"typeB",typeB,"typeC",typeC);
assert(typeA,"\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",mapType);
assert(typeB,"\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152B",mapType);
assert(typeC,"\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);
local mapIdx=mData["\235\178\136\237\152\184"];
local depth=mData["\236\184\181"];
local isBossDepth=mData["\235\179\180\236\138\164\236\184\181"];
local houseObjId=mData["\236\176\189\234\179\160"];
local nextFloorMap;
local nextFloorMapId;
local nextFloorBossDepth;
local prevFloorBossDepth;
local prevFloorMapId;
local customDig=TT.GRID_DIG_WALL;
local criticalErr;
local canCliff=CanCliffMap(mapId);
local makeItems={};
local function critical(b,...)
if not b then
criticalErr=true;
assert(b,...);
end
end


local function MakeItem(...)
local guid,data=_G.MakeItem(...);
makeItems[guid]=data;
return guid,data;
end

if depth then
nextFloorMapId=MapId(mapType,area,field,mapIdx,depth+1);
nextFloorMap=_S.maps[nextFloorMapId];
nextFloorBossDepth=nextFloorMap and nextFloorMap["\235\179\180\236\138\164\236\184\181"];
if not nextFloorMap then
nextFloorMapId=nil;
end
if depth>1 then
prevFloorMapId=MapId(mapType,area,field,mapIdx,depth-1);
prevFloorBossDepth=_S.maps[prevFloorMapId]and _S.maps[prevFloorMapId]["\235\179\180\236\138\164\236\184\181"];
else
prevFloorMapId=mData["\236\157\180\236\160\132\235\167\181"];

end
end
local tm=socket.gettime();
local roomTypes={["\236\139\173\236\158\144\235\176\169"]=0,["\236\139\173\236\158\144\235\140\128\236\185\173\235\176\169"]=1,["\236\130\172\234\176\129\235\176\169"]=2,["\236\155\144\237\152\149\235\176\169"]=3,["\236\176\140\234\183\184\235\159\172\236\167\132\235\176\169"]=4,["\235\143\153\234\181\180\235\176\169"]=5,["\235\143\153\234\181\180"]=6,["\235\161\156\235\185\132\235\176\169"]=7};
local roomDefs={};
local roomPresets=const("\235\176\169 \235\147\177\236\158\165 \237\153\149\235\165\160_"..mapType);
local function randarrow()
return table.choice({"right","left"});
end
local function addPresetRoom(handle,num1,num2,def)






















local idx=math.randlist(roomDefs[def.preset].pcts);
def=def or{};
table.copyifnot(roomDefs[def.preset].options[idx],def);
table.copyifnot(roomDefs[def.preset].option,def);
brogue.setOption(def);
return brogue.addRoom(handle,num1,num2,def);
end
local function addPresetFirstRoom(handle,def)

local idx=math.randlist(roomDefs[def.preset].pcts);
def=def or{};
table.copyifnot(roomDefs[def.preset].options[idx],def);
table.copyifnot(roomDefs[def.preset].option,def);
brogue.setOption(def);
return brogue.addFirstRoom(handle,def);
end

local defs={};
for k,v in pairs(roompresettable)do
if not v["\235\167\181"]then
defs[v["\236\157\180\235\166\132"]]=v;
end
end
for k,v in pairs(roompresettable)do
if table.find(v["\235\167\181"],mapType)then
defs[v["\236\157\180\235\166\132"]]=v;
end
end

for k,v in safe_pairs(defs)do
roomDefs[k]={};
roomDefs[k].pcts={};
roomDefs[k].options={};
for i=1,99 do
local sz=v["\237\129\172\234\184\176"..i];
if not sz then
break;
end
local type=v["\237\131\128\236\158\133"..i];
local pct=v["\235\185\132\236\156\168"..i]or 1;
local t;
if type=="\235\143\153\234\181\180\235\176\169"then
t={
CAVE1_MIN_WIDTH=sz[1],
CAVE1_MAX_WIDTH=sz[2],
CAVE1_MIN_HEIGHT=sz[3],
CAVE1_MAX_HEIGHT=sz[4],
CAVE1_MIN_AREA=sz[5],
CAVE1_MAX_AREA=sz[6],
};
elseif type=="\236\139\173\236\158\144\235\176\169"then
t={
CROSS_ROOM_MIN_WIDTH=sz[1],
CROSS_ROOM_MAX_WIDTH=sz[2],
CROSS_ROOM_MIN_HEIGHT=sz[3],
CROSS_ROOM_MAX_HEIGHT=sz[4],
CROSS_ROOM_MIN_WIDTH2=sz[5],
CROSS_ROOM_MAX_WIDTH2=sz[6],
CROSS_ROOM_MIN_HEIGHT2=sz[7],
CROSS_ROOM_MAX_HEIGHT2=sz[8],
};
elseif type=="\236\139\173\236\158\144\235\140\128\236\185\173\235\176\169"then
t={
SYMCROSS_ROOM_MIN_WIDTH=sz[1],
SYMCROSS_ROOM_MAX_WIDTH=sz[2],
SYMCROSS_ROOM_MIN_HEIGHT=sz[3],
SYMCROSS_ROOM_MAX_HEIGHT=sz[4],
SYMCROSS_ROOM_MIN_WIDTH2=sz[5],
SYMCROSS_ROOM_MAX_WIDTH2=sz[6],
SYMCROSS_ROOM_MIN_HEIGHT2=sz[7],
SYMCROSS_ROOM_MAX_HEIGHT2=sz[8],
};
elseif type=="\236\130\172\234\176\129\235\176\169"then
t={
SMALL_ROOM_MIN_WIDTH=sz[1],
SMALL_ROOM_MAX_WIDTH=sz[2],
SMALL_ROOM_MIN_HEIGHT=sz[3],
SMALL_ROOM_MAX_HEIGHT=sz[4],
SMALL_ROOM_ORIGINX=sz[5]or 0,
SMALL_ROOM_ORIGINY=sz[6]or 0,
};
elseif type=="\236\155\144\237\152\149\235\176\169"then
t={
CIRCULAR_ROOM_MIN_RADIUS=sz[1],
CIRCULAR_ROOM_MAX_RADIUS=sz[2],
};
elseif type=="\236\176\140\234\183\184\235\159\172\236\167\132\235\176\169"then
t={
CHUNKY_ROOM_WIDTH=sz[1],
CHUNKY_ROOM_HEIGHT=sz[2],
CHUNKY_ROOM_RADIUS=sz[3],
CHUNKY_ROOM_MIN_COUNT=sz[4];
CHUNKY_ROOM_MAX_COUNT=sz[5],
};
elseif type=="\235\161\156\235\185\132\235\176\169"then
t={
ENTRANCE_ROOM_WIDTH=sz[1],
ENTRANCE_ROOM_HEIGHT=sz[2],
ENTRANCE_ROOM_WIDTH2=sz[3],
ENTRANCE_ROOM_HEIGHT2=sz[4],
};
end
assert(t);
t.roomType=roomTypes[type];
roomDefs[k].pcts[i]=pct;
roomDefs[k].options[i]=t;
end
local cor=v["\235\179\181\235\143\132 \234\184\184\236\157\180"]or const("\235\179\181\235\143\132 \234\184\184\236\157\180");
local corP=const("\235\179\181\235\143\132\234\186\189\236\158\132\234\184\184\236\157\180");
roomDefs[k].option={
DOOR_PERCENT=0,
CORRIDOR_MIN_LENGTH=cor[1],
CORRIDOR_MAX_LENGTH=cor[2],
OBLIQUE_CORRIDOR_MIN_LENGTH=corP[1],
OBLIQUE_CORRIDOR_MAX_LENGTH=corP[2],
corridorChance=v["\235\179\181\235\143\132 \237\153\149\235\165\160"]or const("\235\179\181\235\143\132 \237\153\149\235\165\160"),
obliqueHallway=v["\235\179\181\235\143\132\234\186\189\236\158\132"]or const("\235\179\181\235\143\132\234\186\189\236\158\132"),
outCorridor=v["\235\176\150\235\179\181\235\143\132"],
};
end

local function _bp(key,idx)
if bp[key]then
if idx~=nil then
return bp[key][idx];
else
return bp[key];
end
end
end

local _={};
local function reservePos(x,y)
posReserved[x+y*MAP_W]=true;
end
local function isReservedPos(x,y)
return posReserved[x+y*MAP_W];
end
local function isValidPos(x,y)
return x>=0 and x<MAP_W and y>=0 and y<=MAP_H;
end

brogue.setOption({
DOOR_PERCENT=0,
});

function initFieldTileset()
local key=mapTile;
_["\234\181\172\236\132\177"]=key;
_["\237\131\128\236\157\188\236\133\139"]=const(key.." \234\181\172\236\132\177");
do

local total=100;
local c=0;
for k,v in pairs(_["\237\131\128\236\157\188\236\133\139"])do
if k=="\235\172\188"then
elseif type(v)=="table"then

_[k]=countkcc(v);
total=total-_[k];
else
total=total-v;
c=c+1;
end
end

for k,v in pairs(_["\237\131\128\236\157\188\236\133\139"])do
if k=="\235\172\188"then
_[k]=countkcc(v);
elseif type(v)~="table"then

_[k]=v+total/c;
end
end
end
if maptb["\237\149\132\235\147\156 \237\129\172\234\184\176"]then
local size=countkcc(maptb["\237\149\132\235\147\156 \237\129\172\234\184\176"][key]);
local prefix=typeC;
local spread=maptb["\237\149\132\235\147\156 \237\141\188\236\167\144"]or const(prefix.." \237\141\188\236\167\144");
local spreadp=maptb["\237\149\132\235\147\156 \235\169\180\236\160\129"]or const(prefix.." \235\169\180\236\160\129");
_["\237\129\172\234\184\176"]=size;
brogue.setOption({

CAVE_PERCENT_SEED=countkcc(spread[1]),
CAVE_ROUND=countkcc(spread[2]),
CAVE_BIRTH=spread[3],
CAVE_SURVIVAR=spread[4],
CAVE_MIN_WIDTH=0,
CAVE_MIN_HEIGHT=0,
CAVE_MAX_WIDTH=size,
CAVE_MAX_HEIGHT=size,
CAVE_MIN_AREA=math.floor(spreadp[1]*size*size),
CAVE_MAX_AREA=math.floor(spreadp[2]*size*size),
});
end

brogue.setTileCatalog({
[TT.WOOD]={
drawPriority=60,
flags=0,
mechFlags=0,
},
[TT.DESERT]={
drawPriority=60,
flags=0,
mechFlags=0,
},
[TT.MARSHES]={
drawPriority=60,
flags=0,
mechFlags=0,
},
[TT.WATER]={
drawPriority=60,
flags=0,
mechFlags=0,
},
[TT.ICE]={
drawPriority=60,
flags=0,
mechFlags=0,
}
});

brogue.setAutoGenerator({

{
countDungeonFoundationType=TT.FLOOR,
countLiquidFoundationType=-1,
minPercent=math.floor(_["\236\136\178"]or 0),

requiredDungeonFoundationType=TT.FLOOR,
requiredLiquidFoundationType=0,
layer=1,
tile=TT.WOOD,
startProbability=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\236\136\178"][1],
probabilityDecrement=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\236\136\178"][2],

},

{
countDungeonFoundationType=TT.FLOOR,
countLiquidFoundationType=-1,
minPercent=math.floor(_["\236\138\181\236\167\128"]or 0),
requiredDungeonFoundationType=TT.FLOOR,
requiredLiquidFoundationType=0,
layer=1,
tile=TT.MARSHES,
startProbability=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\236\138\181\236\167\128"][1],
probabilityDecrement=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\236\138\181\236\167\128"][2],

},

{
countDungeonFoundationType=TT.FLOOR,
countLiquidFoundationType=TT.MARSHES,
minPercent=math.floor(_["\235\172\188"]or 0),
requiredDungeonFoundationType=TT.FLOOR,
requiredLiquidFoundationType=TT.MARSHES,
layer=1,
tile=TT.WATER,
startProbability=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\235\172\188"][1],
probabilityDecrement=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\235\172\188"][2],

},

{
countDungeonFoundationType=TT.FLOOR,
countLiquidFoundationType=TT.WATER,
minPercent=math.floor(countkcc(maptb["\236\150\188\236\157\140"]or 0)),
requiredDungeonFoundationType=TT.FLOOR,
requiredLiquidFoundationType=TT.WATER,
layer=1,
tile=TT.ICE,
startProbability=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\236\150\188\236\157\140"][1],
probabilityDecrement=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\236\150\188\236\157\140"][2],
},
});
end


function initHouseTileset()
brogue.setAutoGenerator({});
end

function initDungeonTileset()
local key=mapTile;
_["\234\181\172\236\132\177"]=key;
_["\237\131\128\236\157\188\236\133\139"]=const(key.." \234\181\172\236\132\177");

do

local total=100;
local c=0;
for k,v in pairs(_["\237\131\128\236\157\188\236\133\139"])do
if type(v)=="table"then

_[k]=math.randrange(v[1],v[2]);
total=total-_[k];
else
total=total-v;
c=c+1;
end
end

for k,v in pairs(_["\237\131\128\236\157\188\236\133\139"])do
if type(v)~="table"then

_[k]=v+total/c;
end
end
end



brogue.setOption({
});

brogue.setTileCatalog({
[TT.GROUND_BLOCK]={
drawPriority=60,
flags=0,
mechFlags=0,
},
[TT.WATER]={
drawPriority=60,
flags=0,
mechFlags=0,
}
});

brogue.setAutoGenerator({
{
countDungeonFoundationType=TT.FLOOR,
countLiquidFoundationType=-1,
minPercent=math.floor(_["\235\184\148\235\161\157"]or 0),

requiredDungeonFoundationType=TT.FLOOR,
requiredLiquidFoundationType=0,
layer=1,
tile=TT.GROUND_BLOCK,
startProbability=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\235\184\148\235\161\157"][1],
probabilityDecrement=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\235\184\148\235\161\157"][2],

},

{
countDungeonFoundationType=TT.FLOOR,
countLiquidFoundationType=-1,
minPercent=math.floor(_["\235\172\188"]or 0),
requiredDungeonFoundationType=TT.FLOOR,
requiredLiquidFoundationType=0,
layer=1,
tile=TT.WATER,
startProbability=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\235\172\188"][1],
probabilityDecrement=const("\234\181\172\236\132\177 \236\160\132\236\157\180")["\235\172\188"][2],

},
});
end




local function makeSpecialRoomList()
local list={};

for k,v in pairs(_S["\234\179\160\236\160\149\235\176\169"])do
if table.find(v,mapId)then
if not table.find(list,k)then
if const("\235\130\173\235\150\160\235\159\172\236\167\128\235\176\169\235\170\169\235\161\157",k)and not canCliff then
else
local t=roomtable[k];
if t["\235\167\129\237\129\172\235\176\169"]then
_S["\235\167\129\237\129\172\235\176\169"][k]=_S["\235\167\129\237\129\172\235\176\169"][k]or{};
local clist={};
for kk,p in pairs(t["\235\167\129\237\129\172\235\176\169"])do
if not t["\235\167\129\237\129\172\235\176\169\237\146\128"]or not table.find(_S["\235\167\129\237\129\172\235\176\169"][k],kk)then
clist[kk]=p;
end
end
local k2=math.randlist(clist);
if t["\235\167\129\237\129\172\235\176\169\237\146\128"]then
table.insert(_S["\235\167\129\237\129\172\235\176\169"][k],k2);
if#_S["\235\167\129\237\129\172\235\176\169"][k]>t["\235\167\129\237\129\172\235\176\169\237\146\128"]then
table.remove(_S["\235\167\129\237\129\172\235\176\169"][k],1);
end
end
k=k2;
end
table.insert(list,k);
end
end
end
end
if nextFloorBossDepth and bp["\235\179\180\236\138\164\236\184\181\236\158\133\234\181\172\235\176\169"]then
table.insert(list,bp["\235\179\180\236\138\164\236\184\181\236\158\133\234\181\172\235\176\169"]);
end













































for k,v in safe_pairs(DefaultRooms)do
if not table.find(list,v)then
table.insert(list,v);
end
end

list=table.shuffle(list);

local all={};
for i,k in ipairs(list)do
local t=roomtable[k];
assert(t,k);
local doors={["\235\172\184"]=t["\235\172\184"],["\236\158\144\235\172\188\236\135\160 \235\172\184"]=t["\236\158\144\235\172\188\236\135\160 \235\172\184"],["\236\178\160\235\172\184"]=t["\236\178\160\235\172\184"],["\235\172\180\234\177\176\236\154\180 \235\172\184"]=t["\235\172\180\234\177\176\236\154\180 \235\172\184"],["\235\185\132\235\176\128 \235\172\184"]=t["\235\185\132\235\176\128 \235\172\184"],["\235\179\180\236\138\164\235\176\169 \235\172\184"]=t["\235\179\180\236\138\164\235\176\169 \235\172\184"]};
do
local door=math.randlist(doors);
trace("doors",k,doors,door);
local o={};
table.insert(all,o);
o.id=k;
o.door=door;
if door then

local keyId=const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160")[door];

if keyId then
if itemtable[keyId]then
o.item=MakeItem(keyId);
o.doorKey=o.item;
elseif objecttable[keyId]then
o.keyObj=keyId;
end
if door=="\236\178\160\235\172\184"or door=="\235\172\180\234\177\176\236\154\180 \235\172\184"then
local id;
do

local list={};
for k,v in pairs(ev("\236\158\160\234\184\180\235\172\184 \236\151\180\236\135\160 \236\152\164\235\184\140\236\160\157\237\138\184"))do
if const("\235\130\173\235\150\160\235\159\172\236\167\128\235\176\169\235\170\169\235\161\157",k)and not canCliff then
else
if(v["\236\167\128\236\151\173"]or areaN)<=areaN then
list[k]=v[door];
end
end
end
id=math.randlist(list);
end
trace("\236\151\180\236\135\160\236\152\164\235\184\140\236\160\157\237\138\184",id);
if roomtable[id]then
local okey={};
local t=roomtable[id];
okey.id=id;
okey.linkItem=o.item;
okey.linkObj=o.keyObj;
okey.linkRoom=o;
okey.door=math.randlist({["\235\172\184"]=t["\235\172\184"],["\235\185\132\235\176\128 \235\172\184"]=t["\235\185\132\235\176\128 \235\172\184"]});
o.item=nil;
o.keyObj=nil;

table.insert(all,okey);
elseif id==keyId then
else
o.keyObj=id;
end
end
end
end
end
end

local i=1;
while all[i]do
local v=all[i];
if v.id then
local tb=roomtable[v.id];
if tb["\236\151\176\234\178\176\235\176\169"]then
customDig=customDig+1;
v.fillDig=customDig;
for _,k in safe_pairs(tb["\236\151\176\234\178\176\235\176\169"])do
local o={id=k};
local t=roomtable[k];
o.needDig=v.fillDig;
o.door=t["\236\151\176\234\178\176 \235\172\184"];
v.linkRooms=v.linkRooms or{};
table.insert(v.linkRooms,o);
table.insert(all,i+1,o);
i=i+1;
end
elseif tb["\236\158\133\234\181\172\235\176\169"]then
customDig=customDig+1;
v.needDig=customDig;
for _,k in safe_pairs(tb["\236\158\133\234\181\172\235\176\169"])do
local o={id=k};
local t=roomtable[k];
o.fillDig=v.needDig;
table.insert(all,i,o);
i=i+1;
end
end
end
i=i+1;
end
return all;
end

local function calcRoomTiles(handle)
local function isDoor(x,y)
local grid=brogue.getGrid(handle,x,y);
return grid==TT.GRID_DOOR or grid==TT.GRID_NEW_DOOR;
end

local function isWall(x,y)
return x<0 or y<0 or x>=MAP_W or y>=MAP_H or brogue.getGrid(handle,x,y)<=0;
end

local function movableTo(i,j,x,y)
if i==x or j==y then
return not isWall(x,y);
else
return not isWall(x,y)and(not isWall(i,y)or not isWall(x,j));
end
end




local function isBlock(i,j)
local pts={{i-1,j-1},{i-1,j},{i-1,j+1},{i,j+1},{i+1,j+1},{i+1,j},{i+1,j-1},{i,j-1},{i-1,j-1}};
local c=0;
for k=1,8 do
if movableTo(i,j,pts[k][1],pts[k][2])~=movableTo(i,j,pts[k+1][1],pts[k+1][2])then
c=c+1;
end
end
return c>2;
end

local function isChoke(x,y)
local c1,c2,c3,c4=0,0,0,0;
if(x>0 and brogue.getGrid(handle,x-1,y)<=0)then
c1=c1+1;
end
if(x<MAP_W-1 and brogue.getGrid(handle,x+1,y)<=0)then
c2=c2+1;
end
if(y>0 and brogue.getGrid(handle,x,y-1)<=0)then
c3=c3+1;
end
if(y<MAP_H-1 and brogue.getGrid(handle,x,y+1)<=0)then
c4=c4+1;
end
if c1+c2+c3+c4==2 then

if((c1+c2)==0 and(c3+c4)==2)or((c1+c2)==2 and(c3+c4)==0)then
return true;
end

if(c1>0 and c3>0 and brogue.getGrid(handle,x+1,y+1)<=0)then
return true;
elseif(c2>0 and c3>0 and brogue.getGrid(handle,x-1,y+1)<=0)then
return true;
elseif(c1>0 and c4>0 and brogue.getGrid(handle,x+1,y-1)<=0)then
return true;
elseif(c2>0 and c4>0 and brogue.getGrid(handle,x-1,y-1)<=0)then
return true;
end
end
end

local function isNearCenter(x,y)
local r=const("\235\176\169\236\164\145\236\149\153\236\161\176\234\177\180");
for i=x-r,x+r,1 do
for j=y-r,y+r,1 do
local grid=brogue.getGrid(handle,i,j);
if grid<=0 then
return false;
end
end
end
return true;
end
local function isHallway(x,y)
return isChoke(x,y)and
(isChoke(x-1,y)or isChoke(x+1,y)or isChoke(x,y-1)or isChoke(x,y+1));
end

local function isNearWall(x,y)
if not(isChoke(x-1,y)or isChoke(x+1,y)or isChoke(x,y-1)or isChoke(x,y+1))then
local b1=(x>0 and brogue.getGrid(handle,x-1,y)<=0)or(x<MAP_W-1 and brogue.getGrid(handle,x+1,y)<=0)or(y>0 and brogue.getGrid(handle,x,y-1)<=0)or(y<MAP_H-1 and brogue.getGrid(handle,x,y+1)<=0);
if b1 then
local b2=(x>0 and brogue.getGrid(handle,x-1,y)<=0)or(y>0 and brogue.getGrid(handle,x,y-1)<=0);
return{b2};
end
end
end

local function canStairPos(x,y)
if isBlock(x,y)then
return{false,false};
end

local b1=(x<MAP_W-1 and brogue.getGrid(handle,x+1,y)>0)and(y<MAP_H-1 and brogue.getGrid(handle,x,y+1)>0);

local b2=(x>0 and brogue.getGrid(handle,x-1,y)>0)and(y>0 and brogue.getGrid(handle,x,y-1)>0);
return{b1,b2};
end

local function check(v,x,y)
if x>=0 and x<MAP_W and y>=0 and y<=MAP_H then
local idx=x+y*MAP_W;
local grid=brogue.getGrid(handle,x,y);
v.roomTiles=v.roomTiles or{};
if grid>0 and not v.roomTiles[idx]then
if isDoor(x,y)then










elseif not v.roomTiles[idx]then
v.roomTiles[idx]={room=v,nearWall=isNearWall(x,y),nearCenter=isNearCenter(x,y),hallway=isHallway(x,y),canStairPos=canStairPos(x,y)}
check(v,x-1,y);
check(v,x+1,y);
check(v,x,y-1);
check(v,x,y+1);
end
end
end
end

for k,v in pairs(rooms)do
check(v,v.x,v.y);
end
end



local function makeRoomObjects(handle,list)



































local function findRoom(guid)
for k,v in pairs(rooms)do
if v.guid==guid then
return v;
end
end
assert(false,"findRoom fail");
end
local function getRandomPosInRoom(room,type,x,y,R)




















local t={};
if type=="\235\178\189"then
























for k,v in pairs(room.roomTiles)do
if not posReserved[k]and v.nearWall and not v.hallway then
table.insert(t,k);
end
end
if not t[1]then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]then
table.insert(t,k);
end
end
end
elseif type=="\235\178\189\236\151\134\236\157\140"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and not v.nearWall then
table.insert(t,k);
end
end
elseif type=="\236\164\145\236\149\153\234\179\132\235\139\168"then
for r=0,5,1 do
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and v.canStairPos[1]and v.canStairPos[2]then
local x2,y2=k%MAP_W,k//MAP_W;
local dist=math.max(math.abs(x2-room.x),math.abs(y2-room.y));
if dist<=r then
table.insert(t,k);
end
end
end
if t[1]then
break;
end
end
elseif type=="\234\179\132\235\139\168"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and v.canStairPos[1]then
table.insert(t,k);
end
end
elseif type=="\234\179\132\235\139\168U"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and v.canStairPos[2]then
table.insert(t,k);
end
end
elseif string.starts(type,"\235\185\136\234\179\181\234\176\132")then
local L=tonumber(string.sub(type,string.len("\235\185\136\234\179\181\234\176\132")+1));
local maxC;
for R=L,0,-1 do
local list={};
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and not v.hallway then
local x2,y2=k%MAP_W,k//MAP_W;
local c=0;
for i=x2-R,x2+R do
for j=y2-R,y2+R do
local idx=i+j*MAP_W;
if not posReserved[idx]and room.roomTiles[idx]then
c=c+1;
end
end
end
if not maxC or maxC<c then
t={};
table.insert(t,k);
maxC=c;
elseif maxC==c then
table.insert(t,k);
end
end
end
end
elseif type=="\235\176\169\236\164\145\236\149\153"then
local L=7;
local maxC;
for R=L,1,-1 do

for k,v in pairs(room.roomTiles)do
if not posReserved[k]and not v.hallway and not v.nearWall then
local x2,y2=k%MAP_W,k//MAP_W;
local c=0;
for i=x2-R,x2+R do
for j=y2-R,y2+R do
local idx=i+j*MAP_W;

if room.roomTiles[idx]then

local w=math.max(math.abs(i-x2),math.abs(j-y2));
if w>0 then
c=c+1/w;
end
end
end
end
if c>=8 then


if not maxC or maxC<c then

t={};
table.insert(t,k);
maxC=c;
elseif maxC==c then

table.insert(t,k);
end
end
end
end
end
elseif type=="\236\164\145\236\149\153"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and v.nearCenter then
table.insert(t,k);
end
end
elseif type=="\235\176\169"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and not v.hallway then
table.insert(t,k);
end
end
elseif type=="\235\179\181\235\143\132"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and v.hallway then
table.insert(t,k);
end
end
if not t[1]then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and v.nearWall then
table.insert(t,k);
end
end
end
elseif type=="\236\163\188\235\179\128"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]then
local x2,y2=k%MAP_W,k//MAP_W;
local dist=math.max(math.abs(x2-x),math.abs(y2-y));
if dist<=R then
table.insert(t,k);
end
end
end
elseif _G.type(type)=="table"and type[1]then
for i=0,MAP_W do
for k,v in ipairs(type)do
local x2,y2=room.x+v[1]+i,room.y+v[2]+i;
local k=x2+y2*MAP_W;
if not posReserved[k]then
table.insert(t,k);
end
end
if t[1]then
break;
end
end
else
for k,v in pairs(room.roomTiles)do
if not posReserved[k]then
table.insert(t,k);
end
end
end
if t[1]then
local v=t[math.random(#t)];
return v%MAP_W,v//MAP_W;
else
assert(false,"no pos",type,x,y,R,room and room.guid);
end
end


local function getRandomPos(x,y,min)
local distMap,maxDist=brogue.distance(handle,startx,starty);
min=(min or 0)*maxDist;
local list={};
for k,v in pairs(distMap)do
local x2,y2=v%MAP_W,v//MAP_W;
if math.abs(x2-x)>=min or math.abs(y2-y)>=min then
if not posReserved[k]then
table.insert(list,k);
end
end
end
local v=table.choice(list);
if v then
return v%MAP_W,v//MAP_W;
end
assert(false,"getRandomPos",x,y,min);
end



for i,v in ipairs(list)do
if v.door then
local room=findRoom(v);
reservePos(room.doorx,room.doory);
if const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160",v.door)or v.door=="\235\179\180\236\138\164\235\176\169 \235\172\184"then
brogue.setGrid(handle,room.doorx,room.doory,TT.GRID_WALL);
end
end
end


local function _makeSpecialRoomObject(room,t,cnt,trap,posType,fromX,fromY,fromR,isChild)
local tb=roomtable[room.guid.id];
local from=tb["\235\147\156\235\158\141 \235\160\136\236\150\180\235\143\132"];
local itemcls=tb.itemcls or"\236\149\132\236\157\180\237\133\156";
local keyGuid;
local trigger;

if not isChild then
if tb["\236\152\164\235\184\140\236\160\157\237\138\184 \236\151\180\236\135\160"]then
local t=tb["\236\152\164\235\184\140\236\160\157\237\138\184 \236\151\180\236\135\160"];
local itemGuid=MakeItem(t.id);
keyGuid=itemGuid;
local x,y;
if t["\236\156\132\236\185\152"]=="\235\176\169\236\164\145\236\149\153"then
x,y=getRandomPosInRoom(room,"\235\176\169\236\164\145\236\149\153");
else
x,y=getRandomPos(room.x,room.y,t["\236\181\156\236\134\140\234\177\176\235\166\172"]);
end
if t["\236\152\164\235\184\140\236\160\157\237\138\184"]then
objects[MakeGuid("o")]={id=t["\236\152\164\235\184\140\236\160\157\237\138\184"],x=x,y=y,item=itemGuid};
elseif t["\235\170\172\236\138\164\237\132\176"]then
npcs[MakeGuid("c")]={id=t["\235\170\172\236\138\164\237\132\176"],x=x,y=y,item=itemGuid};
end
reservePos(x,y);
end

if tb["\236\152\164\235\184\140\236\160\157\237\138\184 \237\158\140\237\138\184"]then
local t=tb["\236\152\164\235\184\140\236\160\157\237\138\184 \237\158\140\237\138\184"];
local x,y;
if t["\236\156\132\236\185\152"]=="\235\176\169\236\164\145\236\149\153"then
x,y=getRandomPosInRoom(room,"\235\176\169\236\164\145\236\149\153");
else
x,y=getRandomPos(room.x,room.y,t["\236\181\156\236\134\140\234\177\176\235\166\172"]);
end
if t["\236\152\164\235\184\140\236\160\157\237\138\184"]then
objects[MakeGuid("o")]={id=t["\236\152\164\235\184\140\236\160\157\237\138\184"],x=x,y=y,rockId=table.choice(t.rockId)};
end
reservePos(x,y);
end

if tb["\237\138\184\235\166\172\234\177\176"]then
local x,y=getRandomPosInRoom(room,"\235\176\169\236\164\145\236\149\153");
local guid=MakeGuid("o");
objects[guid]={id=tb["\237\138\184\235\166\172\234\177\176"],x=x,y=y};
trigger=objects[guid];
reservePos(x,y);
end
end

if type(t)~="table"or not t[1]then
t={t};
end
for _,t in ipairs(t)do
if type(t)=="table"then
t=t[bpName]or t[area]or t["\236\167\128\236\151\173"..areaN]or t;
end
if type(t)~="table"then
t={[t]=1};
end

local list={};
for k,v in pairs(t)do
if const("\235\130\173\235\150\160\235\159\172\236\167\128\235\176\169\235\170\169\235\161\157",k)and not canCliff then
else
if _G.type(v)=="table"then
list[k]=v.p or 1;
else
list[k]=v;
end
end
end


trace("_makeSpecialRoomObject",t,list,cnt);

for i=1,cnt,1 do
local guid=math.randlist(list);
if guid then
local vv=t[guid];
local c=1;
local sdata;
if _G.type(vv)=="table"then
posType=vv["\236\156\132\236\185\152"]or posType;
c=countkcc(vv.c or 1);
sdata=vv.sdata;
if vv.h then
local t=vv.h;
local x,y;
if t["\236\156\132\236\185\152"]=="\235\176\169\236\164\145\236\149\153"then
x,y=getRandomPosInRoom(room,"\235\176\169\236\164\145\236\149\153");
else
x,y=getRandomPos(room.x,room.y,t["\236\181\156\236\134\140\234\177\176\235\166\172"]);
end
if t["\236\152\164\235\184\140\236\160\157\237\138\184"]then
objects[MakeGuid("o")]={id=t["\236\152\164\235\184\140\236\160\157\237\138\184"],x=x,y=y,rockId=table.choice(t.rockId)};
end
reservePos(x,y);
end
end
posType=posType or"\235\158\156\235\141\164";
for i=1,c,1 do
local x,y=getRandomPosInRoom(room,posType,fromX,fromY,fromR);
local t={id=guid,x=x,y=y};
for k,v in safe_pairs(sdata)do
t[k]=v;
end
reservePos(x,y);

if not isBossDepth and ev(guid.." \236\151\180\236\135\160 \236\152\164\235\184\140\236\160\157\237\138\184")then
local itemGuid=MakeItem(const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160")[guid]);
assert(itemGuid);
keyGuid=itemGuid;
local keyx,keyy=getRandomPos(x,y,const("\236\151\180\236\135\160 \236\181\156\236\134\140 \234\176\132\234\178\169"));
reservePos(keyx,keyy);
local key=math.randlist(ev(guid.." \236\151\180\236\135\160 \236\152\164\235\184\140\236\160\157\237\138\184"));
if itemtable[key]then
objects[MakeGuid("o")]={id="\236\149\132\236\157\180\237\133\156",x=keyx,y=keyy,item=itemGuid};
elseif objecttable[key]then
objects[MakeGuid("o")]={id=key,x=keyx,y=keyy,item=itemGuid};
elseif monstertable[key]then
npcs[MakeGuid("c")]={id=key,x=keyx,y=keyy,item=itemGuid};
else
assert(false,key);
end
end
if tb["\236\160\156\235\139\168"]then
local guid=MakeGuid("o");
objects[guid]={id=tb["\236\160\156\235\139\168"],x=t.x,y=t.y,z=-1};
end
if objecttable[t.id]then
t.param=room.param;
t.linkObj=room.spawner;
t.dropRare=from;
t.key=keyGuid;
t["\236\157\128\235\176\128\235\143\132"]=tb["\236\157\128\235\176\128\235\143\132"];
local guid=MakeGuid("o");
objects[guid]=t;
if trigger then
trigger.triggers=trigger.triggers or{};
table.insert(trigger.triggers,guid);
end
elseif monstertable[t.id]then
npcs[MakeGuid("c")]=t;
elseif itemtable[t.id]or drop1table[t.id]then
local itemGuid=MakeItem(t.id,from);
assert(itemGuid,t.id);
objects[MakeGuid("o")]={id=itemcls,x=t.x,y=t.y,item=itemGuid,linkObj=room.spawner,key=keyGuid};
end


if trap then
if trap["\234\176\156\236\136\152P"]then
c=math.floor(countkcc(trap["\234\176\156\236\136\152P"])*table.length(room.roomTiles)/100);
else
c=countkcc(trap["\234\176\156\236\136\152"]);
end
for i=1,c,1 do
_makeSpecialRoomObject(room,trap["\236\162\133\235\165\152"],1,nil,trap["\236\156\132\236\185\152"]or"\236\163\188\235\179\128",x,y,math.ceil(c/8),true);
end
end
end
end
end
end
end


for i,v in ipairs(list)do
local room=findRoom(v);
if v.obj then
local x,y=getRandomPosInRoom(room,v.objPosType);
local t={id=v.obj,x=x,y=y};
if v.objParam then
for k,v in pairs(v.objParam)do
t[k]=v;
end
end
if objecttable[t.id]then
objects[MakeGuid("o")]=t;
reservePos(x,y);
end
if v.prevStair then
if t.a=="right"then
startx,starty,starta=x,y,"left";
else
startx,starty,starta=x,y,"right";
end
reservePos(startx,starty);
if prevFloorMapId then
gates[prevFloorMapId]={x=startx,y=starty,a=starta};
end

do
local distMap,maxDist=brogue.distance(handle,startx,starty);
wsamples={};
for k,v in pairs(distMap)do
table.insert(wsamples,k);
end
end
elseif v.nextStair then
if t.a=="right"then
endx,endy,enda=x,y,"left";
else
endx,endy,enda=x,y,"right";
end
reservePos(endx,endy);
gates[nextFloorMapId]={x=endx,y=endy,a=enda};
end
end

local function makeObj(x,y,keyObj,item,door)
if not keyObj then
assert(item);
objects[MakeGuid("o")]={id="\236\149\132\236\157\180\237\133\156",x=x,y=y,item=item};
reservePos(x,y);
elseif monstertable[keyObj]then
npcs[MakeGuid("c")]={id=keyObj,x=x,y=y,item=item};
reservePos(x,y);
elseif objecttable[keyObj]then
if item then
objects[MakeGuid("o")]={id=keyObj,x=x,y=y,item=item};
else
assert(door,keyObj);
objects[MakeGuid("o")]={id=keyObj,x=x,y=y,door=door};
end
end
reservePos(x,y);
end

if v.door then
local guid=MakeGuid("o");
room.doorGuid=guid;
objects[guid]={id=v.door,x=room.doorx,y=room.doory,key=v.doorKey};
if v.keyObj or v.item then
local x,y=getRandomPos(room.doorx,room.doory,const("\236\151\180\236\135\160 \236\181\156\236\134\140 \234\176\132\234\178\169"));
makeObj(x,y,v.keyObj,v.item,guid);
end
brogue.setGrid(handle,room.doorx,room.doory,TT.GRID_NEW_FLOOR);
end


if v.linkRoom then
local linkRoom=findRoom(v.linkRoom);
critical(linkRoom,"\235\167\129\237\129\172\235\163\184 \236\151\134\236\157\140");
critical(linkRoom.doorGuid);
local x,y=getRandomPosInRoom(room,"\235\176\169\236\164\145\236\149\153");
room.linkObjPos={x=x,y=y};
makeObj(x,y,v.linkObj,v.linkItem,linkRoom.doorGuid);
end
end


for i,v in ipairs(list)do
if v.id then
local room=findRoom(v);
local tb=roomtable[v.id];
assert(tb,v.id);
trace("\237\138\185\236\136\152\235\176\169","tb");
local function findWave()
if tb["\236\155\168\236\157\180\235\184\140"]then
if not tb["\236\155\168\236\157\180\235\184\140"][1]then
return tb["\236\155\168\236\157\180\235\184\140"];
else
for k,v in ipairs(tb["\236\155\168\236\157\180\235\184\140"])do
if v["\236\167\128\236\151\173"]and not table.find(v["\236\167\128\236\151\173"],areaN)then
else
return v;
end
end
end
end
end
local w=findWave();
if w then
local pts={};
local x,y=getRandomPosInRoom(room);
if w["\236\156\132\236\185\152"]=="\235\176\169\236\160\132\236\178\180"then
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and not v.hallway then
table.insert(pts,{x=k%MAP_W,y=k//MAP_W});
end
end
trace("\235\176\169\236\160\132\236\178\180",pts);
else
local c=countkccmax(w["\235\176\152\235\179\181"]or 1)
for i=1,c,1 do
if w["\236\156\132\236\185\152"]=="\235\168\188\234\179\179"then
local x2,y2=getRandomPos(x,y,0.5);
table.insert(pts,{x=x2,y=y2});
else
local x2,y2=getRandomPosInRoom(room,w["\236\156\132\236\185\152"]);
table.insert(pts,{x=x2,y=y2});
trace("\236\155\168\236\157\180\235\184\140\236\156\132\236\185\152",w["\236\156\132\236\185\152"],room.x,room.y,x2,y2,pts);
end
end
end
room.spawner=MakeGuid("o");
objects[room.spawner]={id=w.cls or"\236\155\168\236\157\180\235\184\140\237\143\172\236\157\184\237\138\184",wave=w,x=x,y=y,room=v.id,door=room.doorGuid,pts=pts};
table.copy(w.param,objects[room.spawner]);

end

if tb["\235\179\180\236\138\164"]then
local doors={room.doorGuid};

for _,vv in safe_pairs(v.linkRooms)do
local room=findRoom(vv);
if room.doorGuid then
table.insert(doors,room.doorGuid);
end
end


local function findBoss()
for k,v in ipairs(tb["\235\179\180\236\138\164"])do
if v["\236\132\160\237\150\137\235\148\148\235\178\132\237\148\132"]and not HasDebuff(v["\236\132\160\237\150\137\235\148\148\235\178\132\237\148\132"])then
elseif v["\236\132\160\237\150\137\235\179\180\236\138\164"]and not _S["\236\178\152\236\185\152\235\179\180\236\138\164"][v["\236\132\160\237\150\137\235\179\180\236\138\164"]]then
elseif v["\236\132\160\237\150\137\237\148\140\235\158\152\234\183\184"]and not _S["\237\148\140\235\158\152\234\183\184"][v["\236\132\160\237\150\137\237\148\140\235\158\152\234\183\184"]]then
elseif v["\236\167\128\236\151\173"]and not table.find(v["\236\167\128\236\151\173"],areaN)then
else
return v;
end
end
end
local boss=findBoss();
if boss then
local x,y=getRandomPosInRoom(room,"\235\176\169\236\164\145\236\149\153");

local pts={};
for k,v in pairs(room.roomTiles)do
if not posReserved[k]and not v.hallway then
table.insert(pts,{x=k%MAP_W,y=k//MAP_W});
end
end
npcs[MakeGuid("c")]={id=boss["\235\179\180\236\138\164"],x=x,y=y,room=v.id,roomPts=pts,roomPos={x=room.x,y=room.y},doors=doors,boss=boss};
reservePos(x,y);
end
end

if tb["\236\152\164\235\184\140\236\160\157\237\138\184 \237\140\140\235\157\188\235\175\184\237\132\176"]then
local param=tb["\236\152\164\235\184\140\236\160\157\237\138\184 \237\140\140\235\157\188\235\175\184\237\132\176"];
if param.type=="choicen"then
local t=table.choicen(param.list,math.random(table.unpack(param.n)));
room.param=t;
else
room.param=param[bpName]or param[area]or param;
end
end

if tb["\236\167\128\237\152\149"]then
for _,_v in ipairs(tb["\236\167\128\237\152\149"])do
local t={};
for k,v in pairs(room.roomTiles)do
table.insert(t,k);
end
local cnt=#t;
for k,v in pairs(_v)do
local c=math.floor(cnt*math.randrange(v[1],v[2]));
local k2=k;

while c>0 do
if#t>0 then
local v=table.choiceRemove(t);
if k=="\235\185\136\235\149\133"then
k2="\235\149\133";
posReserved[v]=true;
end
local tile=table.find(TT._NAMES,k2);
if tile then
reservedTiles[v]=tile;
end
end
c=c-1;
end
end
end
end

if tb["\235\141\152\236\160\132\237\131\136\236\182\156"]then
if nextFloorMapId then
local x,y;
if v.id==bp["\235\179\180\236\138\164\236\184\181\236\158\133\234\181\172\235\176\169"]then
x,y=getRandomPosInRoom(room,"\236\164\145\236\149\153\234\179\132\235\139\168");
else
x,y=getRandomPosInRoom(room,"\234\179\132\235\139\168");
end
local a=randarrow();
objects[MakeGuid("o")]={id="\235\139\164\236\157\140\234\179\132\235\139\168".."_"..typeB,x=x,y=y,a=a,nextMap=nextFloorMapId};
if a=="right"then
endx,endy,enda=x,y,"left";
else
endx,endy,enda=x,y,"right";
end

for i=x-1,x+1 do
for j=y-1,y+1 do
reservePos(i,j);
end
end
reservePos(endx,endy);
gates[nextFloorMapId]={x=endx,y=endy,a=enda};
else
local x,y=getRandomPosInRoom(room,"\235\178\189");

objects[MakeGuid("o")]={id="\235\141\152\236\160\132\237\131\136\236\182\156",x=x,y=y,nextMap=mData["\236\157\180\236\160\132\235\167\181"]};

for i=x-1,x+1 do
for j=y-1,y+1 do
reservePos(i,j);
end
end
end
end

if tb["\236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177"]then
local cnt=countkcc(tb["\236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177 \234\176\156\236\136\152"]or 1);
local list=tb["\236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177"];
_makeSpecialRoomObject(room,list,cnt,tb["\237\138\184\235\158\169"],tb["\236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177 \236\156\132\236\185\152"]);
else
if tb["\237\138\184\235\158\169"]then
local c;
if tb["\237\138\184\235\158\169"]["\234\176\156\236\136\152P"]then
c=math.floor(countkcc(tb["\237\138\184\235\158\169"]["\234\176\156\236\136\152P"])*table.length(room.roomTiles)/100);
else
c=countkcc(tb["\237\138\184\235\158\169"]["\234\176\156\236\136\152"]);
end
for i=1,c,1 do
local x,y=room.x,room.y;
if room.linkObjPos then
x,y=room.linkObjPos.x,room.linkObjPos.y;
end
_makeSpecialRoomObject(room,tb["\237\138\184\235\158\169"]["\236\162\133\235\165\152"],1,nil,tb["\237\138\184\235\158\169"]["\236\156\132\236\185\152"]or"\236\163\188\235\179\128",x,y,math.ceil(c/8));
end
end
end

if tb["\235\185\136\235\149\133"]then
for k,v in pairs(room.roomTiles)do
posReserved[k]=true;
end
end
end
end
end

local function traceDig(handle)













































end

local function digField(handle)
trace("dig");

local r;
if maptb["\237\148\132\235\166\172\236\133\139"]then
r=addPresetFirstRoom(handle,{preset=maptb["\237\148\132\235\166\172\236\133\139"]});
else
r=brogue.addFirstRoom(handle,{roomType=6});
end
table.insert(rooms,{guid={type="\236\157\188\235\176\152\235\176\169"},x=r[1].x,y=r[1].y});





do

local function choiceStair(dir,distMaps,minD)
trace("choiceStair",dir,minD);
local abc={{MAP_W-1,0,-1},{0,MAP_W-1,1},{MAP_H-1,0,-1},{0,MAP_H-1,1}};
local function checkDist(i,j)
if minD then
for _,distMap in pairs(distMaps)do
local pos=j*MAP_W+i;
if not distMap[pos]or distMap[pos]<minD then
return false;
end
end
end
return true;
end
if dir<=2 then
for i=abc[dir][1],abc[dir][2],abc[dir][3]do
local list;
for j=0,MAP_H-1,1 do
local grid=brogue.getGrid(handle,i,j);
if grid>0 and brogue.getGrid(handle,i-abc[dir][3],j)==TT.GRID_WALL then
if checkDist(i,j)then
list=list or{};
table.insert(list,{i-abc[dir][3],j,-abc[dir][3],0,i,j});
end
break;
end
end
if list then
local idx=math.random(#list);
trace("choiceStair list",list,idx);
return list[idx];
end
end
else
for j=abc[dir][1],abc[dir][2],abc[dir][3]do
local list;
for i=1,MAP_W-1,1 do
local grid=brogue.getGrid(handle,i,j);
if grid>0 and brogue.getGrid(handle,i,j-abc[dir][3])==TT.GRID_WALL then
if checkDist(i,j)then
list=list or{};
table.insert(list,{i,j-abc[dir][3],0,-abc[dir][3],i,j});
end
break;
end
end
if list then
local idx=math.random(#list);
trace("choiceStair list",list,idx);
return list[idx];
end
end
end
assert(false,"choiceStair fail");
end
do


local function isExit(x,y)
local c=0;
if(x<=0 or brogue.getGrid(handle,x-1,y)<=0)then
c=c+1;
end
if(x>=MAP_W-1 or brogue.getGrid(handle,x+1,y)<=0)then
c=c+1;
end
if(y<=0 or brogue.getGrid(handle,x,y-1)<=0)then
c=c+1;
end
if(y>=MAP_H-1 or brogue.getGrid(handle,x,y+1)<=0)then
c=c+1;
end
return c>=3;
end


local distMaps={};
for dir,v in pairs(mData["\236\182\156\234\181\172"])do
if v~=0 then
local r=choiceStair(dir,distMaps,_["\237\129\172\234\184\176"]*const("\237\149\132\235\147\156\236\158\133\236\182\156\234\181\172\234\177\176\235\166\172"));
local distMap=brogue.distance(handle,r[5],r[6]);
table.insert(distMaps,distMap);


do
local x,y=r[1],r[2];
brogue.setGrid(handle,x,y,TT.GRID_NEW_FLOOR+1);
while not isExit(x,y)do
x,y=x+r[3],y+r[4];
brogue.setGrid(handle,x,y,TT.GRID_NEW_FLOOR+1);
end
if isValidPos(x+r[3],y+r[4])then
brogue.setGrid(handle,x+r[3],y+r[4],TT.GRID_TORCH_WALL);
end
objects[MakeGuid("o")]={id="\235\139\164\236\157\140\237\149\132\235\147\156",x=x,y=y,nextMap=v};
local R=const("\236\182\156\236\158\133\234\181\172\234\183\188\236\178\152\235\185\136\235\149\133");
for i=-R,R,1 do
for j=-R,R,1 do
reservePos(x+i,y+j);
end
end

if maptb["\236\182\156\234\181\172\235\167\137\234\184\176"]then
local m=_S.maps[v];
local id=maptb["\236\182\156\234\181\172\235\167\137\234\184\176"][m["\236\132\164\234\179\132\235\143\132"]]or maptb["\236\182\156\234\181\172\235\167\137\234\184\176"][v];
local chat=maptb["\236\182\156\234\181\172\235\140\128\237\153\148"]and maptb["\236\182\156\234\181\172\235\140\128\237\153\148"][m["\236\132\164\234\179\132\235\143\132"]];
if m["\236\167\128\236\151\173"]==area and m["\237\149\132\235\147\156"]<=field then
id=nil;
end

if id then
local x,y=x-r[3],y-r[4];
reservePos(x,y);
objects[MakeGuid("o")]={id=id,x=x,y=y,toolChat=chat};
local R=const("\236\182\156\236\158\133\234\181\172\234\183\188\236\178\152\235\185\136\235\149\133");
for i=-R,R,1 do
for j=-R,R,1 do
if isValidPos(x+i,y+j)and brogue.getGrid(handle,x+i,y+j)==TT.GRID_NEW_FLOOR then
brogue.setGrid(handle,x+i,y+j,TT.GRID_NEW_FLOOR+1);
end
end
end
end
end
local a="right";
if dir==1 or dir==4 then
a="left";
end
gates[v]={x=x,y=y,a=a};
end
end
end
do
local minMapLv=mapLv;
local minMapId;
for k,v in pairs(gates)do
if not minMapLv or _S.maps[k]["\235\167\181 \235\160\136\235\178\168"]<minMapLv then
minMapLv=_S.maps[k]["\235\167\181 \235\160\136\235\178\168"];
minMapId=k;
end
if k==oldMap then
startx,starty,starta=v.x,v.y,v.a;
end
end

if minMapId and not startx then
local v=gates[minMapId];
startx,starty,starta=v.x,v.y,v.a;
trace("set start1",startx,starty,gates,minMapId);
end
if not startx then

startx,starty=r[1].x,r[1].y;
starta="right";
trace("\236\139\156\236\158\145\236\167\128\236\160\144 \236\164\145\236\149\153\236\151\144\236\132\156 \236\131\157\236\132\177",startx,starty);
brogue.setGrid(handle,startx,starty,TT.GRID_NEW_FLOOR+1);
reservePos(startx,starty);
end




























end
end
do
local list={"\236\158\145\236\157\128 \235\141\152\236\160\132","\235\160\136\236\150\180 \235\141\152\236\160\132","\236\151\144\237\148\189 \235\141\152\236\160\132"};
local minD={0,0,0};
for k,v in ipairs(list)do
local cnt=0;
for i=1,99,1 do
if _S.maps[MapId(v,area,field,i,1)]then
cnt=cnt+1;
else
break;
end
end

for i=1,cnt,1 do
local tpos=maptb["\235\141\152\236\160\132\236\158\133\234\181\172\236\156\132\236\185\152"];
local tposV={1,0};
if tpos and tpos[v]and tpos[v]["\236\156\132\236\185\152"]=="\234\181\172\236\132\157"then
tposV={0,1}
end
r=addPresetRoom(handle,tposV[1],tposV[2],{preset=v.."\235\176\169",fillDig=TT.GRID_NEW_WALL,fromX=startx,fromY=starty,fromX2=endx,fromY2=endy,minDistance=minD[k]});
if#r~=1 then
assert(false,"\236\131\157\236\132\177 \236\139\164\237\140\168",v);
end
local nextMap=MapId(v,area,field,i,1);
local nextbp=_S.maps[nextMap]["\236\132\164\234\179\132\235\143\132"];
local portal=v.." \236\158\133\234\181\172";
if objecttable[nextbp.." \236\158\133\234\181\172"]then
portal=nextbp.." \236\158\133\234\181\172";
end
local a=randarrow();
reservePos(r[1].x,r[1].y);
table.insert(rooms,{guid={type="\236\157\188\235\176\152\235\176\169"},x=r[1].x,y=r[1].y});
objects[MakeGuid("o")]={id=portal,x=r[1].x,y=r[1].y,a=a,nextMap=nextMap};
gates[nextMap]={x=r[1].x,y=r[1].y,a=a};








end
end
end
end


local all=makeSpecialRoomList();
trace("\235\170\168\235\147\160\235\176\169",#all,all);
for i,v in ipairs(all)do
local tb=roomtable[v.id];
if tb["\237\148\132\235\166\172\236\133\139"]then
local tposV={1,0};
if tb["\237\149\132\235\147\156\234\181\172\236\132\157"]then
tposV={0,1}
end
r=addPresetRoom(handle,tposV[1],tposV[2],{preset=math.randlist(tb["\237\148\132\235\166\172\236\133\139"]),fillDig=v.fillDig or TT.GRID_NEW_WALL,needDig=v.needDig});
end
if#r~=1 then
assert(false,tb.guid,"\236\131\157\236\132\177 \236\139\164\237\140\168");
end
table.insert(rooms,{guid=v,x=r[1].x,y=r[1].y,doorx=r[1].doorx,doory=r[1].doory});
end


brogue.addPath(handle,const("\235\143\140\236\149\132\234\176\128\235\138\148\236\167\128\237\152\149 \235\178\189 \235\154\171\236\157\140"));
calcRoomTiles(handle);
makeRoomObjects(handle,all);
end


local function digLobby(handle)
trace("dig lobby");
local r;

trace("add first room s");
local r=addPresetFirstRoom(handle,{preset="\235\161\156\235\185\132"});
table.insert(rooms,{guid={type="\236\157\188\235\176\152\235\176\169"},x=r[1].x,y=r[1].y});

do
local r1={MAP_W/2,MAP_H/2};
startx,starty=r1[1],r1[2];
starta="right";
end
end

local function digHouse(handle)
trace("dig");
local tb=objecttable[houseObjId];

local r=addPresetFirstRoom(handle,{preset=tb["\235\130\180\235\182\128"]});
table.insert(rooms,{guid={type="\236\157\188\235\176\152\235\176\169"},x=r[1].x,y=r[1].y});
startx=r[1].x;
starty=r[1].y;
starta="right";
for i=1,MAP_W-1,1 do
local grid=brogue.getGrid(handle,r[1].x,r[1].y+i);
if grid<=0 then
startx,starty=r[1].x,r[1].y+i-1;
brogue.setGrid(handle,startx,starty+1,TT.GRID_NEW_DOOR);
brogue.setGrid(handle,startx,starty+2,TT.GRID_TORCH_WALL);
break;
end
end
objects[MakeGuid("o")]={id="\236\176\189\234\179\160\235\172\184",x=startx,y=starty+1,a="left"};
end

local function digDungeon(handle)
trace("dig");
local all={};
local r;

local roomMax=countkcc(bp["\236\157\188\235\176\152 \235\176\169\236\157\152 \234\176\156\236\136\152"]);
trace("\236\157\188\235\176\152 \235\176\169\236\157\152 \234\176\156\236\136\152:"..roomMax);
if isBossDepth then
roomMax=0;
end

do
local prevStairId=bp["\236\157\180\236\160\132\234\179\132\235\139\168"]or("\236\157\180\236\160\132\234\179\132\235\139\168".."_"..typeB);
local preset=math.randlist(roomPresets);
local posType="\234\179\132\235\139\168";
r=addPresetFirstRoom(handle,{preset=preset});
if prevFloorBossDepth and bp["\235\179\180\236\138\164\236\184\181\235\139\164\236\157\140\236\158\133\234\181\172\235\176\169"]then
local t=roomtable[bp["\235\179\180\236\138\164\236\184\181\235\139\164\236\157\140\236\158\133\234\181\172\235\176\169"]];
prevStairId=t["\236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177"];
posType=t["\236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177 \236\156\132\236\185\152"];


else
end
if depth==1 and maptb["\236\154\176\237\154\140\237\131\136\236\182\156"]then
prevStairId=maptb["\236\154\176\237\154\140\237\131\136\236\182\156"].cls or"\235\141\152\236\160\132\237\131\136\236\182\156";
end
t={type="\236\157\188\235\176\152\235\176\169",roomType="\236\158\133\234\181\172\235\176\169",prevStair=true,obj=prevStairId,objPosType=posType,objParam={a=randarrow(),nextMap=prevFloorMapId}};
table.insert(rooms,{guid=t,x=r[1].x,y=r[1].y});
table.insert(all,t);

end






if not nextFloorBossDepth or not bp["\235\179\180\236\138\164\236\184\181\236\158\133\234\181\172\235\176\169"]then

if nextFloorMap and not isBossDepth then
local id="\235\139\164\236\157\140\234\179\132\235\139\168".."_"..typeB;
local posType="\234\179\132\235\139\168";
if objecttable[id]["\236\160\149\235\169\180"]=="\236\167\132\236\158\133U"or objecttable[id]["\236\160\149\235\169\180"]=="\236\160\145\234\183\188U"then posType="\234\179\132\235\139\168U";end
table.insert(all,{type="\236\157\188\235\176\152\235\176\169",roomType=math.randlist(roomPresets),nextStair=true,obj=id,objPosType=posType,objParam={a=randarrow(),nextMap=nextFloorMapId}});
end
end
do

for _,ty in pairs({"\236\158\145\236\157\128 \235\141\152\236\160\132","\235\160\136\236\150\180 \235\141\152\236\160\132","\236\151\144\237\148\189 \235\141\152\236\160\132"})do
local nextMap=MapId(ty,area,field,"["..mapType.."_"..mapIdx.."_"..depth.."]",1);
if _S.maps[nextMap]then
local nextbp=_S.maps[nextMap]["\236\132\164\234\179\132\235\143\132"];
local portal=ty.." \236\158\133\234\181\172";
if objecttable[nextbp.." \236\158\133\234\181\172"]then
portal=nextbp.." \236\158\133\234\181\172";
end
local posType="\234\179\132\235\139\168";
table.insert(all,{type="\236\157\188\235\176\152\235\176\169",roomType=math.randlist(roomPresets),obj=portal,objPosType=posType,objParam={a=randarrow(),nextMap=nextMap}});
end
end
end

while#all<roomMax do
local roomType=math.randlist(roomPresets);
table.insert(all,{
type="\236\157\188\235\176\152\235\176\169",
roomType=roomType,
});
end
trace("\236\157\188\235\176\152\235\176\169",#all,all);

if#all>1 then

local roomIdx={};
for i=2,#all,1 do
table.insert(roomIdx,i);
end
local p=const("\236\157\188\235\176\152 \235\172\184 \234\181\172\236\132\177_\237\153\149\235\165\160",area)or const("\236\157\188\235\176\152 \235\172\184 \234\181\172\236\132\177_\237\153\149\235\165\160",mapType)or const("\236\157\188\235\176\152 \235\172\184 \234\181\172\236\132\177_\237\153\149\235\165\160",(bp["\237\131\128\236\157\188\236\133\139 \234\181\172\236\132\177"]or""))or 0;
local cnts={};
local t=const("\236\157\188\235\176\152 \235\172\184 \234\181\172\236\132\177_"..area)or const("\236\157\188\235\176\152 \235\172\184 \234\181\172\236\132\177_"..mapType)or const("\236\157\188\235\176\152 \235\172\184 \234\181\172\236\132\177_"..(bp["\237\131\128\236\157\188\236\133\139 \234\181\172\236\132\177"]or""));
for i,idx in ipairs(roomIdx)do
if math.randpercent(p)then
local list={};
for k,v in safe_pairs(t)do
if(v[2]<0 or v[2]>(cnts[k]or 0))and(not v[3]or v[3]<=areaN)then
list[k]=v[1];
end
end
local k=math.randlist(list);
if k then
local o=all[idx];
cnts[k]=(cnts[k]or 0)+1;
o.door=k;
local keyId=const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160")[k];
if keyId then
o.item=MakeItem(keyId);
o.doorKey=o.item;
if const(k.." \236\151\180\236\135\160 \236\152\164\235\184\140\236\160\157\237\138\184")then
local key=math.randlist(const(k.." \236\151\180\236\135\160 \236\152\164\235\184\140\236\160\157\237\138\184"));
if key~=keyId then
all[idx].keyObj=key;
end
end
end
end
end
end























end


do
local list=makeSpecialRoomList();
trace("\234\179\160\236\160\149\235\176\169",#list,list);
for i,v in ipairs(list)do
v.type="\237\138\185\236\136\152\235\176\169";
table.insert(all,v);
end
end

trace("\235\170\168\235\147\160\235\176\169",#all,all);

for i,v in ipairs(all)do
if v.roomType~="\236\158\133\234\181\172\235\176\169"then
if v.type=="\236\157\188\235\176\152\235\176\169"then
r=addPresetRoom(handle,0,1,{preset=v.roomType});
if#r~=1 then
assert(false,"\236\157\188\235\176\152\235\176\169 \236\131\157\236\132\177 \236\139\164\237\140\168",v);
end
else

local tb=roomtable[v.id];
assert(tb,v.id);
if tb["\237\148\132\235\166\172\236\133\139"]then
r=addPresetRoom(handle,0,1,{preset=math.randlist(tb["\237\148\132\235\166\172\236\133\139"]),fillDig=v.fillDig or TT.GRID_NEW_WALL,needDig=v.needDig});
end
if#r~=1 then
assert(false,tb.guid,"\236\131\157\236\132\177 \236\139\164\237\140\168");
end
end
assert(r[1].doorx and r[1].doory,v);
table.insert(rooms,{guid=v,x=r[1].x,y=r[1].y,doorx=r[1].doorx,doory=r[1].doory});
end
end
calcRoomTiles(handle);
makeRoomObjects(handle,all);
end
local i=0;
while true do
collectgarbage();
i=i+1;
local handle=brogue.beginDig();
local s,r;
wsamples=nil;
objects={};
npcs={};
posReserved={};
rooms={};
reservedTiles={};
gates={};
makeItems={};
startx,starty,starta=nil,nil,"right";
endx,endy,enda=nil,nil,"right";
criticalErr=nil;
local uid=_S["\234\179\160\236\156\160\235\178\136\237\152\184"];
local kid=_S["\236\151\180\236\135\160\235\178\136\237\152\184"];

customDig=TT.GRID_DIG_WALL;
if houseObjId then
initHouseTileset();
s,r=xpcall(digHouse,errcb,handle);
elseif isBossDepth then
initDungeonTileset();
s,r=xpcall(digDungeon,errcb,handle);
elseif typeC=="\235\141\152\236\160\132"then
initDungeonTileset();
s,r=xpcall(digDungeon,errcb,handle);
elseif typeC=="\237\149\132\235\147\156"then
initFieldTileset();
s,r=xpcall(digField,errcb,handle);
elseif typeC=="\235\161\156\235\185\132"then
initFieldTileset();
s,r=xpcall(digLobby,errcb,handle);
end
if not s then
trace("dig\236\139\164\237\140\168",r);
traceDig(handle);
brogue.cancelDig(handle);
if criticalErr or i>_Z.GenerateDigCount then
assert(false,"dig\236\139\164\237\140\168",r);
end
for k,v in pairs(makeItems)do
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][k]=nil;
end
_S["\234\179\160\236\156\160\235\178\136\237\152\184"]=uid;
_S["\236\151\180\236\135\160\235\178\136\237\152\184"]=kid;
else

brogue.endDig(handle);
break;
end
end
brogue.finishDig();



local function makeResourceObjects(tiles)
local counts={};
local numTile=0;
local positions={};
for y=0,MAP_H-1,1 do
for x=0,MAP_W-1,1 do
local tile=tiles[x+MAP_W*y];
local k=TT._NAMES[tile];
if k and not isReservedPos(x,y)then
if mapType=="\235\161\156\235\185\132"then
local cx=(x-startx);
local cy=(y-starty);
local d=math.sqrt(cx*cx+cy*cy);
local max=_["\237\129\172\234\184\176"];
if d<4 then k=mapType.."0";
elseif d<8 then k=mapType.."1";
else k=mapType.."2";
end
else
if k=="\235\149\133"then
if mapType=="\237\149\132\235\147\156"then k="\236\180\136\236\155\144";
else
k="\237\134\160\236\150\145";
end
end
end
if tile~=TT.WATER then
numTile=numTile+1;
end
counts[k]=(counts[k]or 0)+1;
positions[k]=positions[k]or{};
table.insert(positions[k],{x,y});
end
end
end


local mul=const("\236\158\144\236\155\144 \236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177 \234\176\156\236\136\152 \236\161\176\236\160\149")[bpName]or const("\236\158\144\236\155\144 \236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177 \234\176\156\236\136\152 \236\161\176\236\160\149")[typeA]or 1;
local defTileN=const("\236\158\144\236\155\144 \236\152\164\235\184\140\236\160\157\237\138\184 \234\184\176\235\179\184\237\131\128\236\157\188\236\136\152")[bpName]or const("\236\158\144\236\155\144 \236\152\164\235\184\140\236\160\157\237\138\184 \234\184\176\235\179\184\237\131\128\236\157\188\236\136\152")[typeA];
if defTileN then
mul=numTile/defTileN;
trace("\236\158\144\236\155\144 \236\152\164\235\184\140\236\160\157\237\138\184 \234\184\176\235\179\184\237\131\128\236\157\188\236\136\152",numTile,mul);
end
local needs={};
for guid,v in pairs(objecttable)do
_G.TB,_G.gen=GetObjectTBandGen(mapId,v);
if v["\234\184\176\235\179\184 \236\131\157\236\132\177"]then
if _G.gen>0 then
local m=mul;
local p={(v["\234\184\176\235\179\184 \236\131\157\236\132\177"]or 0)*m,v["\236\182\148\234\176\128 \236\131\157\236\132\177"],math.max(2,(v["\236\181\156\235\140\128 \236\131\157\236\132\177"]or 0)*m)};
local c=countkcc(p);
if typeC=="\235\141\152\236\160\132"then
local limit=math.ceil(mapLv/10)*10;
c=countkcc(c*(v["\235\141\152\236\160\132\235\160\136\235\178\168"..limit]or 1));
end
trace("\236\152\164\235\184\140\236\160\157\237\138\184\236\131\157\236\132\177",guid,c,p,m);

for i=1,c,1 do
table.insert(needs,guid);
end
end
end
_G.TB,_G.gen=nil,nil;
end

trace("needs",needs);

while true do
local guid=table.choiceRemove(needs);
local v=objecttable[guid];
if not v then
break;
end

local list={};
for k,c in pairs(counts)do
if c>0 and v["p"..k]then
list[k]=c*(v["p"..k]or 0);
end
end
local k=math.randlist(list);
if k and#positions[k]>0 then
local idx=math.random(#positions[k]);
local pos=positions[k][idx];
if not isReservedPos(pos[1],pos[2])then
reservePos(pos[1],pos[2]);
table.remove(positions[k],idx);
objects[MakeGuid("o")]={id=guid,x=pos[1],y=pos[2]};
counts[k]=counts[k]-1;
else
assert(false,"reserved pos",guid,list,k);
end
else
assert(false,"reserved pos",guid,list,k);
end
end
end

local function makeExploreObjects(tiles)
local chokePoint=brogue.analyzeMap();
local distMap,maxDist=brogue.distanceMap(startx,starty);
local function isWall(x,y)
return x<0 or x>=MAP_W or y<0 or y>=MAP_H or not distMap[x+y*MAP_W];
end

local function movableTo(i,j,x,y)
if i==x or j==y then
return not isWall(x,y);
else
return not isWall(x,y)and(not isWall(i,y)or not isWall(x,j));
end
end




local function isBlock(i,j)
local pts={{i-1,j-1},{i-1,j},{i-1,j+1},{i,j+1},{i+1,j+1},{i+1,j},{i+1,j-1},{i,j-1},{i-1,j-1}};
local c=0;
for k=1,8 do
if movableTo(i,j,pts[k][1],pts[k][2])~=movableTo(i,j,pts[k+1][1],pts[k+1][2])then
c=c+1;
end
end
return c>2;
end
local blockMap={};
for k,v in pairs(distMap)do
blockMap[k]=isBlock(k%MAP_W,k//MAP_W);
end

local function isWater(k)
return tiles[k]==TT.WATER;
end
local function isHallway(k)
return chokePoint[k]and
(chokePoint[k-1]or chokePoint[k+1]or chokePoint[k-MAP_W]or chokePoint[k+MAP_W]);
end

local function isNearCenter(x,y)
local r=const("\235\176\169\236\164\145\236\149\153\236\161\176\234\177\180");
for i=x-r,x+r,1 do
for j=y-r,y+r,1 do
if isWall(i,j)then
return false;
end
end
end
return true;
end
local function isNearWall(x,y)
local k=x+y*MAP_W;

if not blockMap[k]then
local b1=((x>0 and not distMap[x-1+y*MAP_W])or(x<MAP_W-1 and not distMap[x+1+y*MAP_W])or(y>0 and not distMap[x+(y-1)*MAP_W])or(y<MAP_H-1 and not distMap[x+(y+1)*MAP_W]))
if b1 then
local b2=(x>0 and not distMap[x-1+y*MAP_W])or(y>0 and not distMap[x+(y-1)*MAP_W]);
return{b2};
end
end
end

local function getNearPos(x,y,min,max,param)
param=param or{};
local distMap,maxDist=brogue.distanceMap(x,y);
local list={};
max=max or maxDist;
min=min or 0;

if min and min>0 and min<1 then
min=maxDist*min;
end
for k,v in pairs(distMap)do
if v<=max and v>=min then
if not posReserved[k]and(param.water or not isWater(k))then
table.insert(list,k);
end
end
end
local v=table.choice(list);
if v then
return v%MAP_W,v//MAP_W;
end
end

local function getRandomPos(x,y,min,posType)
min=(min or 0)*maxDist;
local list={};
local allowWater=string.starts(posType,"(\235\172\188)");
for k,v in pairs(distMap)do
local x2,y2=k%MAP_W,k//MAP_W;
if math.abs(x2-x)>=min or math.abs(y2-y)>=min then
if not posReserved[k]and(allowWater or not isWater(k))then
table.insert(list,k);
end
end
end
local v=table.choice(list);
assert(v,"min",min,"maxDist",maxDist);
return v%MAP_W,v//MAP_W;
end

local function check(v,roomTiles)
for idx,vv in pairs(v.roomTiles)do
roomTiles[idx]=vv;
end
end
local roomTiles={};
if typeC=="\235\141\152\236\160\132"then
for k,v in pairs(rooms)do
if v.guid.type=="\236\157\188\235\176\152\235\176\169"then
check(v,roomTiles);
end
end






else
local sroomTiles={};
for k,v in pairs(rooms)do

if v.guid.id then
check(v,sroomTiles);
end
end
for k,v in pairs(distMap)do
if not sroomTiles[k]then
local x,y=k%MAP_W,k//MAP_W;
roomTiles[k]={nearWall=isNearWall(x,y),nearCenter=isNearCenter(x,y),hallway=isHallway(k)};
end
end









end




























































local function getPlacePos(type,...)
local t={};
local allowWater;
local canWalk;
if string.starts(type,"(\235\172\188)")then
allowWater=true;
type=string.sub(type,string.len("(\235\172\188)")+1);
end
if string.starts(type,"(\236\139\156\236\158\145)")then
canWalk=true;
type=string.sub(type,string.len("(\236\139\156\236\158\145)")+1);
end

local function allow(k)
return not posReserved[k]and(not canWalk or distMap[k])and(allowWater or not isWater(k));
end

if type=="\235\179\181\235\143\132"then
for k,v in pairs(roomTiles)do
if allow(k)and v.hallway then
table.insert(t,k);
end
end
if not t[1]then
for k,v in pairs(roomTiles)do
if allow(k)and v.nearWall then
table.insert(t,k);
end
end
end
elseif type=="\235\172\188\237\131\128\236\157\188"then
for k,v in pairs(roomTiles)do
if not posReserved[k]and isWater(k)then
table.insert(t,k);
end
end
if not t[1]then
for k,v in pairs(roomTiles)do
if not posReserved[k]then
table.insert(t,k);
end
end
end
elseif type=="\235\178\189"then
for k,v in pairs(roomTiles)do
if allow(k)and v.nearWall then
table.insert(t,k);
end
end
elseif type=="\235\178\1892"then
for k,v in pairs(roomTiles)do
if allow(k)and v.nearWall and v.nearWall[1]then
table.insert(t,k);
end
end
elseif type=="\235\176\169 \236\164\145\236\149\153 \234\176\128\234\185\140\236\157\180"then
for k,v in pairs(roomTiles)do
if allow(k)and v.nearCenter then
table.insert(t,k);
end
end
elseif type=="\234\184\184\236\149\136\235\167\137\236\157\140"then
for k,v in pairs(roomTiles)do
if allow(k)and not blockMap[k]then
table.insert(t,k);
end
end
elseif string.starts(type,"\235\185\136\234\179\181\234\176\132")then
local L=tonumber(string.sub(type,string.len("\235\185\136\234\179\181\234\176\132")+1));
local maxC;
for R=L,0,-1 do
local list={};
for k,v in pairs(roomTiles)do
local x2,y2=k%MAP_W,k//MAP_W;
if allow(k)and not blockMap[k]then
local c=0;
for i=x2-R,x2+R do
for j=y2-R,y2+R do
local idx=i+j*MAP_W;
if roomTiles[idx]and allow(idx)then


c=c+1;
end
end
end
if not maxC or maxC<c then
t={};
table.insert(t,k);
maxC=c;
elseif maxC==c then
table.insert(t,k);
end
end
end
end
elseif string.starts(type,"\236\164\145\236\149\153")then
for L=0,MAP_W do
for k,v in pairs(roomTiles)do
if allow(k)and distMap[k]and distMap[k]<=L then
table.insert(t,k);
end
end
if t[1]then
break;
end
end
if not t[1]then
for k,v in pairs(roomTiles)do
if allow(k)then
table.insert(t,k);
end
end
end
elseif string.starts(type,"\236\139\156\236\158\145\234\177\176\235\166\172")then
local L=tonumber(string.sub(type,string.len("\236\139\156\236\158\145\234\177\176\235\166\172")+1));
for k,v in pairs(roomTiles)do
if allow(k)and distMap[k]and distMap[k]<=L then
table.insert(t,k);
end
end
if not t[1]then
for k,v in pairs(roomTiles)do
if allow(k)then
table.insert(t,k);
end
end
end
else
for k,v in pairs(roomTiles)do
if allow(k)then
table.insert(t,k);
end
end
end
if t[1]then
local pos=t[math.random(#t)];
return pos%MAP_W,pos//MAP_W;
end
assert(false,"getPlacePos fail",type,...);
end

for k,v in pairs(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"])do
for i,tb in ipairs(v)do
if type(tb)~="table"then
tb={mapId=tb};
end
if tb.mapId==mapId then
for i=1,tb.cnt or 1,1 do
do
trace("\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184",k,tb);
local x,y;
if objecttable[k]then
x,y=getPlacePos((objecttable[k]["\235\176\176\236\185\152 \236\156\132\236\185\152"]or"")..(tb.pos or""));
else
x,y=getPlacePos(tb.pos);
end

if x and y and x>=0 and y>=0 then
reservePos(x,y);
local t;
if objecttable[k]then
t={id=k,x=x,y=y};
table.copy(tb.data,t);
objects[MakeGuid("o")]=t;
elseif itemtable[k]or drop1table[k]then
t={id="\236\149\132\236\157\180\237\133\156",x=x,y=y,item=MakeItem(k)};
table.copy(tb.data,t);
objects[MakeGuid("o")]=t;
elseif monstertable[k]then
t={id=k,x=x,y=y};
table.copy(tb.data,t);
npcs[MakeGuid("c")]=t;
end

for k,v in safe_pairs(tb.param)do
if k=="\237\131\128\236\157\188\235\179\128\237\153\152"then
for name,r in safe_pairs(v)do
local tt=table.find(TT._NAMES,name);
for a=x-r,x+r,1 do
for b=y-r,y+r,1 do
local idx=a+b*MAP_W;
reservePos(a,b);
if TT._NAMES[tiles[idx]]and tt then
tiles[idx]=tt;
end
end
end
end
end
end
end
end
end
end
end
end


do
local list={};
for guid,v in pairs(objecttable)do
if v["\237\131\128\236\158\133"]=="\237\131\144\237\151\152"then
list[guid]=v[typeC.." \236\131\157\236\132\177"];
end
end

local count=countkcc(ev(typeA.." \237\131\144\237\151\152 \236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177 \234\176\156\236\136\152"));
trace("\237\131\144\237\151\152 \236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177 \234\176\156\236\136\152",count);
local ocounts={};
for i=1,count,1 do
local k=math.randlist(list);
local x,y=getPlacePos(objecttable[k]["\235\176\176\236\185\152 \236\156\132\236\185\152"],k,i);
if not x then
assert("no explorer position",k,objecttable[k]["\235\176\176\236\185\152 \236\156\132\236\185\152"]);
else
ocounts[k]=(ocounts[k]or 0)+1;
if(objecttable[k]["\236\181\156\235\140\128 \236\131\157\236\132\177"]or 0)>=ocounts[k]then
list[k]=nil;
end

do
local p=countkcc(ev("\237\131\144\237\151\152 \236\152\164\235\184\140\236\160\157\237\138\184 \235\175\184\235\175\185 \235\179\128\237\153\152 \237\153\149\235\165\160",k));
if p and math.randpercent(p)then
k="\235\175\184\235\175\185 "..k;
end
end
reservePos(x,y);
local t={id=k,x=x,y=y};

if ev(k.." \236\151\180\236\135\160 \236\152\164\235\184\140\236\160\157\237\138\184")then
local itemGuid=MakeItem(const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160")[k]);
t.key=itemGuid;
local key=math.randlist(ev(k.." \236\151\180\236\135\160 \236\152\164\235\184\140\236\160\157\237\138\184"));
if itemtable[key]then
assert(itemGuid);
local keyx,keyy=getRandomPos(x,y,const("\236\151\180\236\135\160 \236\181\156\236\134\140 \234\176\132\234\178\169"));
reservePos(keyx,keyy);
objects[MakeGuid("o")]={id="\236\149\132\236\157\180\237\133\156",x=keyx,y=keyy,item=itemGuid};
elseif objecttable[key]then
local keyx,keyy=getRandomPos(x,y,const("\236\151\180\236\135\160 \236\181\156\236\134\140 \234\176\132\234\178\169"),objecttable[key]["\235\176\176\236\185\152 \236\156\132\236\185\152"]);
reservePos(keyx,keyy);
objects[MakeGuid("o")]={id=key,x=keyx,y=keyy,item=itemGuid};
elseif monstertable[key]then
local keyx,keyy=getRandomPos(x,y,const("\236\151\180\236\135\160 \236\181\156\236\134\140 \234\176\132\234\178\169"));
reservePos(keyx,keyy);
npcs[MakeGuid("c")]={id=key,x=keyx,y=keyy,item=itemGuid};
else
assert(false,key);
end
end
objects[MakeGuid("o")]=t;

if objecttable[k]["\236\163\188\235\179\128 \236\131\157\236\132\177"]then
local L=objecttable[k]["\236\163\188\235\179\128 \236\131\157\236\132\177"][3];
local n=math.random(objecttable[k]["\236\163\188\235\179\128 \236\131\157\236\132\177"][1],objecttable[k]["\236\163\188\235\179\128 \236\131\157\236\132\177"][2]);
for i=1,n,1 do
local x2,y2=getNearPos(x,y,0,L);
if x2 and y2 then
objects[MakeGuid("o")]={id=k,x=x2,y=y2};
reservePos(x2,y2);
end
end
end
end
end
end


do
local t=ev("\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128 \235\176\176\236\185\152",typeA);
if t then
local _posReserved=posReserved;
posReserved={};
for k,v in pairs(t)do
local c=math.floor(v+0.5);
for i=1,c,1 do
local x,y=getPlacePos(k,"\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128");
assert(x,"\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128",k);
if x then
local keys={};
if isWall(x,y-1)then table.insert(keys,"up");end
if isWall(x,y+1)then table.insert(keys,"down");end
if isWall(x-1,y)then table.insert(keys,"left");end
if isWall(x+1,y)then table.insert(keys,"right");end
local torch=table.choice(keys);
critical(torch,k,x,y);
local id,a;
if torch=="up"then
a="right";
id="\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128L";
elseif torch=="down"then
a="left";
id="\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128R";
elseif torch=="left"then
id="\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128L";
a="left";
elseif torch=="right"then
a="right";
id="\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128R";
end

if math.randpercent(ev("\237\154\131\235\182\136 \235\176\155\236\185\168\235\140\128 \235\185\136 \237\153\149\235\165\160",typeA))then
objects[MakeGuid("o")]={id=id,x=x,y=y,a=a,torch=torch,state="\236\153\132\235\163\140"};
else
objects[MakeGuid("o")]={id=id,x=x,y=y,a=a,torch=torch};
end







reservePos(x,y);
end
end
end
posReserved=_posReserved;
end
end

do
local count=countkcc(ev(mapType.." \237\138\184\235\158\169 \236\131\157\236\132\177 \234\176\156\236\136\152"));
local list={};
for guid,v in pairs(objecttable)do
if v["\237\131\128\236\158\133"]=="\237\138\184\235\158\169"then
if const("\235\130\173\235\150\160\235\159\172\236\167\128\235\176\169\235\170\169\235\161\157",guid)and not canCliff then
else
list[guid]=v[typeC.." \236\131\157\236\132\177"];
end
end
end

for i=1,count,1 do
local oid=math.randlist(list);
local allowWater=string.starts(objecttable[oid]["\235\176\176\236\185\152 \236\156\132\236\185\152"],"(\235\172\188)");
local id=math.randlist(ev("\237\138\184\235\158\169 \235\176\176\236\185\152"));
local t={};
if id=="\236\149\132\236\157\180\237\133\156 \236\163\188\235\179\128 1\236\185\184"or id=="\236\149\132\236\157\180\237\133\156 \236\163\188\235\179\128 2\236\185\184"or id=="\235\172\184 \236\163\188\235\179\128 2\236\185\184"or id=="\235\172\184 \236\163\188\235\179\128 1\236\185\184"then
local n=1;
local type="\236\158\144\236\155\144";
if string.starts(id,"\235\172\184")then type="\235\172\184";end
if string.ends(id,"2\236\185\184")then n=2;end
for k,v in pairs(objects)do
for i=v.x-n,v.x+n,1 do
for j=v.y-n,v.y+n,1 do
if objecttable[v.id]["\237\131\128\236\158\133"]==type then
local pos=i+j*MAP_W;
if roomTiles[pos]and not posReserved[pos]and(allowWater or not isWater(pos))then
table.insert(t,pos);
end
end
end
end
end
elseif id=="\235\179\181\235\143\132"then
for k,v in pairs(chokePoint)do
if not roomTiles[k]and not posReserved[k]and(allowWater or not isWater(pos))then
table.insert(t,k);
end
end
end

if t[1]then
local idx=math.random(#t);
local pos=t[idx];
local x,y=pos%MAP_W,pos//MAP_W;
trace("\237\138\184\235\158\169 \236\131\157\236\132\177",id,oid,x,y);
objects[MakeGuid("o")]={id=oid,x=x,y=y};
reservePos(x,y);
else
local x,y=getPlacePos(objecttable[oid]["\235\176\176\236\185\152 \236\156\132\236\185\152"],oid);
if x then
trace("\237\138\184\235\158\169 \236\131\157\236\132\177",id,oid,x,y);
objects[MakeGuid("o")]={id=oid,x=x,y=y};
reservePos(x,y);
end
end
end
end



do
local itemTiles=roomTiles;































local function dropItem(group,from)
local itemGuid,o=MakeItem(group,from);
if itemGuid then
local t={}
for k,v in pairs(itemTiles)do
if not posReserved[k]then
table.insert(t,k);
end
end
if#t>0 then
local pos=t[math.random(#t)];
local x,y=pos%MAP_W,pos//MAP_W;
assert(itemGuid);
objects[MakeGuid("o")]={id="\236\149\132\236\157\180\237\133\156",item=itemGuid,x=x,y=y};
reservePos(x,y);
else
assert(false,group,from);

end
end
end

local c=countkcc(ev(mapType.." \236\149\132\236\157\180\237\133\156 \235\147\156\235\158\141 \236\131\157\236\132\177 \234\176\156\236\136\152"));
trace("\236\149\132\236\157\180\237\133\156 \235\147\156\235\158\141 \236\131\157\236\132\177 \234\176\156\236\136\152",c);
for i=1,c,1 do
local list={};
for k,v in pairs(drop1table)do
if(v["\236\167\128\236\151\173"]or 0)<=areaN then
local p;
if mapType=="\237\149\132\235\147\156"or mapType=="\236\158\145\236\157\128 \235\141\152\236\160\132"then
p=v[mapType];
else
p=v[mapType]or v["\234\184\176\237\131\128 \235\141\152\236\160\132"];
end
list[k]=p;
end
end
local group=math.randlist(list);
critical(group,areaN,mapType,list);
dropItem(group);
end

for k,v in pairs(drop1table)do
if(v["\236\167\128\236\151\173"]or 0)<=areaN then
local fixed=v["f"..mapType]or v["f\234\184\176\237\131\128 \235\141\152\236\160\132"];
if fixed then
local c=countkcc(fixed);
trace("\236\149\132\236\157\180\237\133\156\234\179\160\236\160\149\236\131\157\236\132\177",k,c);
for i=1,c,1 do
dropItem(k);
end
end
end
end
end


if typeC=="\235\141\152\236\160\132"and not isBossDepth then



local min_targets={};
local max_targets={};
local all_targets={};
for k,v in pairs(rooms)do
if v.guid.type=="\236\157\188\235\176\152\235\176\169"then
local range=const("\235\141\152\236\160\132 \235\170\172\236\138\164\237\132\176 \235\176\176\236\185\152",v.guid.roomType);
assert(range,v.guid.roomType);
if range then
for i=1,range[1],1 do
table.insert(min_targets,v);
end
for i=1,range[2]-range[1],1 do
table.insert(max_targets,v);
end
table.insert(all_targets,v);
end
end
end
do
local range=const("\235\141\152\236\160\132 \235\170\172\236\138\164\237\132\176 \235\176\176\236\185\152","\235\179\181\235\143\132");
if range then
for i=1,range[1],1 do
table.insert(min_targets,"\235\179\181\235\143\132");
end
for i=1,range[2]-range[1],1 do
table.insert(max_targets,"\235\179\181\235\143\132");
end
table.insert(all_targets,"\235\179\181\235\143\132");
end
end

local function spawn(tb,v,key,elite)
local t={}
local monster=monstertable[key];
critical(monster,tostring(v),tostring(key),elite);
local fish=table.find(monster["\235\182\132\235\165\152"],"\235\172\188\234\179\160\234\184\176");
if not v then
for k,v in pairs(chokePoint)do
if not posReserved[k]and(not fish or isWater(k))then
table.insert(t,k);
end
end
elseif v=="\235\179\181\235\143\132"then
for k,v in pairs(chokePoint)do
if not posReserved[k]and isHallway(k)and(not fish or isWater(k))then
table.insert(t,k);
end
end
else
for k,v in pairs(v.roomTiles)do
if not posReserved[k]and(not fish or isWater(k))then
table.insert(t,k);
end
end
end
if#t>0 then
local pos=t[math.random(#t)];
local x,y=pos%MAP_W,pos//MAP_W;
local guid=MakeGuid("c");
npcs[guid]={id=key,x=x,y=y,elite=elite,regenC=tb and tb["\235\182\132\235\165\152"],regenM=mapId};
reservePos(x,y);
return guid;
end
end

local spawnList={};
local function addSpawn(tb,v,key)

critical(key);
table.insert(spawnList,{tb,v,key});
end
local function doSpawn()
local eliteC=countkcc(const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\131\157\236\132\177\236\136\152"));
local eliteList=table.choicen(spawnList,math.min(#spawnList,eliteC));
for k,v in pairs(eliteList)do
v[4]=true;
end
for k,v in pairs(spawnList)do


spawn(v[1],v[2],v[3],v[4]);
end
end

do
local list={};
for k,v in pairs(objects)do
local t=const("\236\152\164\235\184\140\236\160\157\237\138\184\235\179\132 \236\182\148\234\176\128 \235\170\172\236\138\164\237\132\176",v.id);
if t then
if math.randpercent(t.p)then
list[t.id]=countkcc(t.c);
end
end
end
for k,v in pairs(list)do
for i=1,v,1 do
addSpawn(nil,nil,k);
end
end
end

for _,v in pairs(spawntable)do
if table.find(v["\237\131\128\236\158\133"]or mapType,mapType)and
table.find((v["\236\167\128\236\151\173"]or area),area)and
(v["\234\181\172\236\132\177"]or mapTile)==mapTile and
(v["\236\132\164\234\179\132\235\143\132"]or bpName)==bpName and
table.inrange(v["\236\184\181"],depth)then
local c=countkcc(v["\236\131\157\236\132\177 \234\176\156\236\136\152"]);
if v["\235\182\132\235\165\152"]=="\235\170\172\236\138\164\237\132\176"then
do
local tb=const("\235\141\152\236\160\132 \236\184\181\235\179\132 \235\170\172\236\138\164\237\132\176 \236\131\157\236\132\177 \236\136\152 \236\166\157\234\176\128");
c=c+countkcc(tb[math.min(depth,#tb)]);
end
do
local t=const("\235\170\172\236\138\164\237\132\176 \234\184\176\235\179\184 \236\131\157\236\132\177 \236\136\152",mapType);
c=c+t[areaN+1];
end
c=countkcc(c);
end
local list={};
local cnt=0;
for i=1,6,1 do
if v["\236\131\157\236\132\177"..i]then
list[v["\236\131\157\236\132\177"..i]]=v["p\236\131\157\236\132\177"..i];
cnt=cnt+1;
end
end
trace("!spawn",c,list);
for i=1,c,1 do
local key;
if c<cnt then
key=v["\236\131\157\236\132\177"..i];
else
key=math.randlist(list);
end
critical(key,v);
if#min_targets>0 then
addSpawn(v,table.choiceRemove(min_targets),key);
elseif#max_targets>0 then
addSpawn(v,table.choiceRemove(max_targets),key);
else
addSpawn(v,table.choice(all_targets),key);
end
end
end
end
doSpawn();
elseif typeC=="\237\149\132\235\147\156"then


local areaReserved={};
local function AreaReservePos(x,y)
local r=const("\237\149\132\235\147\156\235\170\172\236\138\164\237\132\176\234\181\172\236\151\173");
for j=y-r,y+r,1 do
for i=x-r,x+r,1 do
if i>=0 and i<MAP_W and j>=0 and j<MAP_H then
areaReserved[i+j*MAP_W]=true;
end
end
end
end

local spawnList={};
local function spawn(tb,key,x,y,elite)
if monstertable[key]["\235\176\156\236\158\144\234\181\173"]then
local xSpawn,ySpawn=getNearPos(x,y,const("\235\176\156\236\158\144\234\181\173\235\170\172\236\138\164\237\132\176 \235\166\172\236\160\160 \235\178\148\236\156\132"),nil,{water=true});
if xSpawn and ySpawn then
objects[MakeGuid("o")]={id=monstertable[key]["\235\176\156\236\158\144\234\181\173"],x=x,y=y,monster={key,xSpawn,ySpawn},elite=elite};
end
else
npcs[MakeGuid("c")]={id=key,x=x,y=y,elite=elite,regenC=tb and tb["\235\182\132\235\165\152"],regenM=mapId};
end
end

local function addSpawn(tb,key,x,y)
trace("addSpawn",tb,key,x,y);
table.insert(spawnList,{tb,key,x,y});
reservePos(x,y);
AreaReservePos(x,y);
end
local function doSpawn()
local eliteC=countkcc(const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\131\157\236\132\177\236\136\152"));
local eliteList=table.choicen(spawnList,math.min(#spawnList,eliteC));
for k,v in pairs(eliteList)do
v[5]=true;
end
for k,v in pairs(spawnList)do
spawn(v[1],v[2],v[3],v[4],v[5]);
end
end

for _,v in pairs(spawntable)do
if table.find(v["\237\131\128\236\158\133"]or mapType,mapType)and
table.find(v["\236\167\128\236\151\173"]or area,area)and
table.find(v["\234\181\172\236\132\177"]or mapTile,mapTile)and
table.find(v["\236\132\164\234\179\132\235\143\132"]or bpName,bpName)
then
local c=countkcc(v["\236\131\157\236\132\177 \234\176\156\236\136\152"]);
if v["\235\182\132\235\165\152"]=="\235\170\172\236\138\164\237\132\176"then
do
local t=const("\235\170\172\236\138\164\237\132\176 \234\184\176\235\179\184 \236\131\157\236\132\177 \236\136\152",mapType);
c=c+t[areaN+1];
end
c=math.floor(c);
end
local list={};
local cnt=0;
for i=1,6,1 do
if v["\236\131\157\236\132\177"..i]then
list[v["\236\131\157\236\132\177"..i]]=v["p\236\131\157\236\132\177"..i];
cnt=cnt+1;
end
end
for i=1,c,1 do
local key;
if c<cnt then
key=v["\236\131\157\236\132\177"..i];
else
key=math.randlist(list);
end
local monster=monstertable[key];
local fish=table.find(monster["\235\182\132\235\165\152"],"\235\172\188\234\179\160\234\184\176");
local t={}
for k,v in pairs(roomTiles)do
if not posReserved[k]and not areaReserved[k]and(not fish or isWater(k))then
table.insert(t,k);
end
end
if#t==0 then
areaReserved={};
else
local pos=t[math.random(#t)];
local x,y=pos%MAP_W,pos//MAP_W;
addSpawn(v,key,x,y);
end
end
end
end
doSpawn();
end























end

local tiles=brogue.getMap();
for k,v in pairs(reservedTiles)do
tiles[k]=v;
end

for k,v in pairs(objects)do
if tiles[v.x+v.y*MAP_W]==TT.WATER and not string.starts(objecttable[v.id]["\235\176\176\236\185\152 \236\156\132\236\185\152"],"(\235\172\188)")then
tiles[v.x+v.y*MAP_W]=TT.FLOOR;
end

end
if not isBossDepth and not houseObjId then
if typeC=="\237\149\132\235\147\156"or typeC=="\235\141\152\236\160\132"then
makeExploreObjects(tiles);
end
makeResourceObjects(tiles);
end

if wsamples then
local t={};
for i,k in ipairs(wsamples)do
if not posReserved[k]then
table.insert(t,k);
end
end
wsamples=t;
end

return{
tiles=tiles,
objects=objects,
npcs=npcs,
wsamples=wsamples,
starts={x=startx,y=starty,a=starta},
ends={x=endx,y=endy,a=enda},
gates=gates,
};
end

function SpawnMonsterId(mapId,filter,nightMonster,aiPattern)
local mData=_S.maps[mapId];
local mapType=mData["\237\131\128\236\158\133"];
local area=mData["\236\167\128\236\151\173"];
local field=mData["\237\149\132\235\147\156"];
local depth=mData["\236\184\181"];
local bpName=mData["\236\132\164\234\179\132\235\143\132"];
local mapTile=mData["\234\181\172\236\132\177"];
local list=Lookup(function()
local list={};
for k,v in pairs(spawntable)do
if table.find(v["\237\131\128\236\158\133"]or mapType,mapType)and
table.find(v["\236\167\128\236\151\173"]or area,area)and
table.find(v["\236\184\181"]or depth,depth)and
(v["\234\181\172\236\132\177"]or mapTile)==mapTile and
(v["\236\132\164\234\179\132\235\143\132"]or bpName)==bpName and
(not filter or table.find(filter,v["\235\182\132\235\165\152"]))then
table.insert(list,k);
end
end
return list;
end,"spawn",mapId,filter);
local k=table.choice(list);
local v=spawntable[k];
if v then
local list={};
if nightMonster then
list[v["\235\176\164 \236\131\157\236\132\177"]]=1;
else
for i=1,6,1 do
if v["\236\131\157\236\132\177"..i]then
list[v["\236\131\157\236\132\177"..i]]=v["p\236\131\157\236\132\177"..i];
end
end
end
if aiPattern then
for k,v in pairs(list)do
if not table.find(aiPattern,monstertable[k]["\237\140\168\237\132\180"])then
trace("\237\140\168\237\132\180 \236\149\136\235\167\158\236\157\140",aiPattern,k);
list[k]=nil;
end
end
end
return math.randlist(list);
end
end



function SpawnMonster(tx,ty,rMin,rMax,monsterId,filter,param,outOfSight,nightMonster,aiPattern,noGoto)
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mData=_S.maps[mapId];
local mapType=mData["\237\131\128\236\158\133"];
local area=mData["\236\167\128\236\151\173"];
local field=mData["\237\149\132\235\147\156"];
local depth=mData["\236\184\181"];
local bpName=mData["\236\132\164\234\179\132\235\143\132"];
local mapTile=mData["\234\181\172\236\132\177"];
local npcs=mData.npcs;
local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",mapType);
local typeB=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152B",mapType);
local typeC=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);
assert(typeA);
assert(typeB);
assert(typeC);
trace("SpawnMonster",tx,ty,rMin,rMax,monsterId,bpName,mapTile);
local x,y=world.ground:TileToMap(tx,ty);
rMin=rMin or 0;
rMax=rMax or 1;

if monsterId and not monstertable[monsterId]then
filter=monsterId;
monsterId=nil;
end
local ox,oy=tx,ty;
local function getNearPos(rMin,rMax)
local pos;
for i=ox-rMax,ox+rMax,1 do
for j=oy-rMax,oy+rMax,1 do
if math.abs(ox-i)>=rMin or math.abs(oy-j)>=rMin then
if world.ground:canTileWalkable(i,j,Filter_Movable)
and(not outOfSight or not world.ground:inLOS(i,j))
and(not nightMonster or not world.ground:inTileLight(i,j))
then
pos=pos or{};
table.insert(pos,{i,j});
end
end
end
end
return pos;
end

for r=0,MAP_W/2,1 do
local pos=getNearPos(r,r);
if pos then
tx,ty=table.unpack(table.choice(pos));
ox,oy=tx,ty;
trace("find center",tx,ty,r);
x,y=world.ground:TileToMap(tx,ty);
break;
end
end

local pos=getNearPos(rMin,rMax);
if not pos then
trace("no monserpos",rMin,rMax);
else
while#pos>0 do
local p=table.choiceRemove(pos);
tx2,ty2=p[1],p[2];
if noGoto or world.ground:getTileGoto(tx,ty,tx2,ty2,Filter_Attack)then
if not monsterId then
















monsterId=SpawnMonsterId(mapId,filter,nightMonster,aiPattern);
end
if monsterId then
local monster=monstertable[monsterId];
local fish=table.find(monster["\235\182\132\235\165\152"],"\235\172\188\234\179\160\234\184\176");
local x,y=tx2,ty2;
if not fish or world.ground:getTile(x,y)==TT.WATER then
local guid=MakeGuid("c");
npcs[guid]={id=monsterId,x=x,y=y,nightMonster=nightMonster};
if param then
for k,v in pairs(param)do
npcs[guid][k]=v;
end
end
local o=world:addNpc(guid,npcs[guid]);
trace("SpawnMonster guid",guid,"x",x,"y",y,"id",monsterId);
return guid,npcs[guid],o;
end
else
trace("no monserId");

end
end
end
end
end




function CloneMonster(data)
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mData=_S.maps[mapId];
local npcs=mData.npcs;
rMin=rMin or 0;
rMax=rMax or 1;

local function getNearPos(tx,ty,r)
local pos;
for i=tx-r,tx+r,1 do
for j=ty-r,ty+r,1 do
if math.abs(tx-i)==r or math.abs(ty-j)==r then
if world.ground:canTileWalkable(i,j,Filter_Movable)and not world.ground:inLOS(i,j)then
pos=pos or{};
table.insert(pos,{i,j});
end
end
end
end
return pos;
end

for r=0,MAP_W/2,1 do
local pos=getNearPos(data.x,data.y,r);
if pos then
tx,ty=table.unpack(table.choice(pos));
local guid=MakeGuid("c");
npcs[guid]=table.copy(data);
npcs[guid].x=tx;
npcs[guid].y=ty;
local o=world:addNpc(guid,npcs[guid]);
return guid,npcs[guid],o;
end
end
end

function countkccmax(c,p,m)
if type(c)=="table"then
if c[1]and c[2]and not c[3]then
return math.floor(math.max(c[1],c[2]));
end
m=c["\236\181\156\235\140\128"]or c[3];
end
m=m or c;
return m;
end

function countkcc(c,p,m)
if type(c)=="table"then
if c[1]and c[2]and not c[3]then
if c[2]>c[1]then
return math.random(math.floor(c[1]),math.floor(c[2]));
else
return c[1];
end
end
p=c["\236\182\148\234\176\128"]or c[2];
m=c["\236\181\156\235\140\128"]or c[3];
c=c["\234\184\176\235\179\184"]or c[1];
end
c=c or 0;
p=p or 0;
m=m or c;
assert(type(c)=="number",c);



local n=math.floor(c);
local r=c-n;
if math.random()<r then
c=n+1;
else
c=n;
end;
while c+1<=m and math.random()<p do
c=c+1;
end
return c;
end
