
function makeSaveData()
userDB.Save();
local db={gameData=userDB.SaveData()};
local s=json.encode(db);
local deflated,eof,bytes_in,bytes_out=zlib.deflate()(s,"finish")
local uns=mime.b64(deflated);
return uns;
end

function makeSlotData(all)
userDB.Save();
local list={};
for i=1,const("\236\160\128\236\158\165\236\138\172\235\161\175\236\136\152"),1 do
local db={slotData={}};
if all or userDB.option.__dirtySlots[i]or userDB.option.__dirtySlots[tostring(i)]then
db.slotData[i]=userDB.LoadSlotData(i);
if db.slotData[i]and(db.slotData[i].playing or 0)==0 then
db.slotData[i]=nil;
end
local s=json.encode(db);
local deflated,eof,bytes_in,bytes_out=zlib.deflate()(s,"finish")
local uns=mime.b64(deflated);
list[i]=uns;
end
end
return list;
end

local function loadSaveData(t,delete)
local function load(data)
local uns=mime.unb64(data);
local inflated,eof,bytes_in,bytes_out=zlib.inflate()(uns)
if inflated then
local d=json.decode(inflated);
if d then
if d.gameData then
userDB.LoadData(d.gameData);
end
if d.slotData then
for slot,data in pairs(d.slotData)do
userDB.SaveSlotData(data,slot);
end
end
return d;
end
end
end
if not load(t.gameData)then
return false;
end
for i=1,const("\236\160\128\236\158\165\236\138\172\235\161\175\236\136\152"),1 do
if delete or t["slotData"..i]then
userDB.DelSlotData(i);
end
if t["slotData"..i]then
load(t["slotData"..i]);
end
end
return true;
end

local function register()
local mc=showPopup(root,"\234\179\132\236\160\149\235\147\177\235\161\157\237\140\157\236\151\133",{size={x=0,y=0,cy=APP_H*0.9}});
SetEditBox(mc.editId,mc.editId.txt);
SetEditBox(mc.editPw,mc.editPw.txt,true);
SetEditBox(mc.editPw2,mc.editPw2.txt,true);
SetEditBox(mc.editEmail,mc.editEmail.txt);
SetButton(mc.btnClose2).onClick=function()
mc:Remove();
end
SetButton(mc.btnOk).onClick=function(self)
self.parent.editId:close();
self.parent.editPw:close();
self.parent.editPw2:close();
self.parent.editEmail:close();
if string.len(self.parent.editId:GetText())<4 then
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang.invalid_idtype);
elseif string.len(self.parent.editPw:GetText())<4 then
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang.invalid_pwtype);
elseif self.parent.editPw:GetText()~=self.parent.editPw2:GetText()then
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang.invalid_pw2);
else
local id=mc.editId:GetText();
local pw=mc.editPw:GetText();
local email=mc.editEmail:GetText();
local onFailed=function(s)
trace("fail");
end
local onComplete=function(s)
if s.status=="ok"then
mc:Remove();
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\236\160\128\236\158\165 \236\132\177\234\179\181"));

userDB.option.__dirtySlots={};
userDB.Save();
else
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L(s.status));
end
end
HttpWaitAsync(mc,
RegisterAccount(onComplete,onFailed,id,md5.sumhexa(pw),email,makeSaveData(),makeSlotData(true)),
lang.waitLoginInfo);
end
end
end

function RateGame()
if string.find(sys.getOS(),"ios")then
sendCommand("openurl","https://itunes.apple.com/app/id1492348462");
elseif string.find(sys.getOS(),"android")then
sendCommand("openurl","market://details?id=com.ctugames.km2");
else
sendCommand("openurl","http://play.google.com/store/apps/details?id=com.ctugames.km2");
end
end

function FindPassword()
local mc=showPopup(world,"\235\185\132\235\178\136\236\176\190\234\184\176\237\140\157\236\151\133",{size={x=0,y=0,cy=APP_H*0.9}});
SetEditBox(mc.editId,mc.editId.txt);
SetEditBox(mc.editEmail,mc.editEmail.txt);
SetButton(mc.btnOk).onClick=function(self)
self.parent.editId:close();
self.parent.editEmail:close();
local id=mc.editId:GetText();
local email=mc.editEmail:GetText();
local onFailed=function(s)
trace("fail");
end
local onComplete=function(s)
if s.status=="ok"then
mc:Remove();
showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\235\185\132\235\178\136\236\176\190\234\184\176\236\132\177\234\179\181"));
else
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\235\185\132\235\178\136\236\176\190\234\184\176\236\139\164\237\140\168"));
end
end
HttpWaitAsync(mc,
sendFindPw(onComplete,onFailed,id,email),
lang.waitLoginInfo);
end
SetButton(mc.btnClose2).onClick=function(self)
mc:Remove();
end
end

function SetOption(owner)
local fps=userDB.option.fpsSpeed;
local fsoundText=function()
if userDB.option.sound then
owner.btnSfx.txt:SetText(_L("\235\129\132\234\184\176"));
else
owner.btnSfx.txt:SetText(_L("\236\188\156\234\184\176"));
end

if userDB.option.bgm then
owner.btnBgm.txt:SetText(_L("\235\129\132\234\184\176"));
else
owner.btnBgm.txt:SetText(_L("\236\188\156\234\184\176"));
end

end

SetHSlider(owner.bgmSlider,150).onDraging=function(self,v)
v=v/100;
userDB.option.bgmVol=v;
sys.setMusicVolume(v);
end
owner.bgmSlider.setScroll(userDB.option.bgmVol*100);

SetHSlider(owner.sfxSlider,150).onDraging=function(self,v)
v=v/100;
userDB.option.soundVol=v;
sys.setEffectVolume(v);
end

function owner.sfxSlider:onEndDrag()
PlayAppSound(self,"button");
end

owner.sfxSlider.setScroll(userDB.option.soundVol*100);

SetHSlider(owner.gsSlider,150,100,_Z.MaxSpeed).onDraging=function(self,v)
v=v/100;
userDB.option.gameSpeed=v;
end
owner.gsSlider.setScroll(userDB.option.gameSpeed*100);

if owner.fpsSlider then
SetHSlider(owner.fpsSlider,150,_Z.MinFps,_Z.MaxFps).onDraging=function(self,v)
v=v/60;
fps=v;
end
owner.fpsSlider.setScroll(fps*60);
end

SetButton(owner.btnSfx).onClick=function(self)
userDB.option.sound=not userDB.option.sound;
userDB.Save();
userDB.ResetSoundState();
fsoundText();
end

SetButton(owner.btnBgm).onClick=function(self)
userDB.option.bgm=not userDB.option.bgm;
userDB.Save();
userDB.ResetSoundState();
if userDB.option.bgm then
sys.playMusic();
else
sys.stopMusic();
end
fsoundText();
end
fsoundText();












if owner.btnRategame then
SetTextButton(owner.btnRategame,lang.btnRategame).onClick=function(self)
RateGame();
end
end

if owner.btnSaveAndExit then
SetTextButton(owner.btnSaveAndExit,_L("\236\160\128\236\158\165\237\149\152\234\179\160 \235\130\152\234\176\128\234\184\176")).onClick=function(self)
root:GotoAndPlay("lobby");
end
end


local function GSaveImpl(force)
local function save()
TryConnect(function()
local wait=showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133",lang.waitLogin);
_G.onSaveGameSuccess=function(self)
wait:Remove();
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\236\160\128\236\158\165 \236\132\177\234\179\181"));
end
_G.onSaveGameFailed=function(self)
wait:Remove();
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\234\181\172\234\184\128\236\160\128\236\158\165\236\139\164\237\140\168"));
end
userDB.Save();
local db={slotData={},gameData=userDB.SaveData()};
for i=1,const("\236\160\128\236\158\165\236\138\172\235\161\175\236\136\152"),1 do
db.slotData[i]=userDB.LoadSlotData(i);
if db.slotData[i]and(db.slotData[i].playing or 0)==0 then
db.slotData[i]=nil;
end
end
local s=json.encode(db);
local deflated,eof,bytes_in,bytes_out=zlib.deflate()(s,"finish")
local uns=mime.b64(deflated);
sendCommand("savegame",uns);
end);
end
if force then
save();
else
local mc2=showPopup(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\237\129\180\235\157\188\236\154\176\235\147\156\236\160\128\236\158\165?"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
save();
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
end
end

local function GSave(force)
local wait=showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133",lang.waitLogin);

_G.onLoadGameFailed=function(self)
trace("onLoadGameFailed");
wait:Remove();
GSaveImpl(force);
end


_G.onLoadGameSuccess=function(self,data)
trace("onLoadGameSuccess",data);
local conflict=false;
local d;
if data then
local uns=mime.unb64(data);
local inflated,eof,bytes_in,bytes_out=zlib.inflate()(uns)
if inflated then
d=json.decode(inflated);
if d then
local db=d.gameData;
if db and db.userInfo then
if db.userInfo.userId~=userDB.userInfo.userId or db.userInfo.__v>userDB.userInfo.__v then
conflict=true;
end
end
end
end
end

if conflict then
wait:Remove();
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\237\129\180\235\157\188\236\154\176\235\147\156\236\160\128\236\158\165 \236\139\164\237\140\168"));
else
wait:Remove();
GSaveImpl(force);
end
end
sendCommand("loadgame");
end

local function GLoad()
local wait=showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133",lang.waitLogin);

_G.onLoadGameFailed=function(self)
trace("onLoadGameFailed");
wait:Remove();
end


_G.onLoadGameSuccess=function(self,data)
trace("onLoadGameSuccess",data);
local conflict;
local newaccount;
local d;
if data then
local uns=mime.unb64(data);
local inflated,eof,bytes_in,bytes_out=zlib.inflate()(uns)
if inflated then
d=json.decode(inflated);
if d then
local db=d.gameData;
if db and db.userInfo then
newaccount=db.userInfo.userId~=userDB.userInfo.userId;
if db.userInfo.userId~=userDB.userInfo.userId or db.userInfo.__v>userDB.userInfo.__v then
conflict=true;
end
end
end
end
end

if not conflict then
wait:Remove();
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\237\129\180\235\157\188\236\154\176\235\147\156\235\161\156\235\147\156 \236\139\164\237\140\168"));
elseif newaccount then
wait:Remove();
local mc2=showPopup(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\237\129\180\235\157\188\236\154\176\235\147\156\235\161\156\235\147\156?"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
local function send(id,pw)
local onFailed=function(s)
trace("fail");
end
local onComplete=function(s)
if s.status=="invalid_id"then
local mc=showPopup(world,"\235\185\132\235\178\136\236\158\133\235\160\165\237\140\157\236\151\133",{size={x=0,y=0,cy=APP_H*0.9}});
SetEditBox(mc.editPw2,mc.editPw2.txt,true);
SetButton(mc.btnClose2).onClick=function(self)
mc:Remove();
end
SetButton(mc.btnOk).onClick=function(self)
self.parent.editPw2:close();
local pw2=mc.editPw2:GetText();
send(id,md5.sumhexa(pw2));
mc:Remove();
end
SetTextButton(mc.btnFindPw,_L("\236\149\148\237\152\184 \236\176\190\234\184\176")).onClick=function(self)
self.parent.editPw2:close();
FindPassword();
end
elseif s.status=="ok"then
userDB.LoadData(d.gameData);
for i=1,const("\236\160\128\236\158\165\236\138\172\235\161\175\236\136\152"),1 do
userDB.DelSlotData(i);
userDB.SaveSlotData(d.slotData[i],i);
end
myInfo=nil;
if s.user then
userDB.SetUserInfo("userId",s.user.guid);
userDB.SetUserInfo("userPw",s.user.pw);
userDB.SetUserInfo("linkid",s.user.linkid);
end
userDB.Save(true);
LoadLang();
PlayBGM();
TryConnect(function()
root:GotoAndStop("loading");
end);
elseif s.status=="already_changed"then
local msg=_L(s.status);
msg=msg..string.format("(%02d:%02d)",math.floor(s.rtime/3600),math.floor(s.rtime/60)%60);
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",msg);
else
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[s.status]or _L("\237\129\180\235\157\188\236\154\176\235\147\156\235\161\156\235\147\156 \236\139\164\237\140\168"));
end
end
HttpWaitAsync(root,
GChangeAccount(onComplete,onFailed,id,pw),
lang.waitLoginInfo);
end
send(d.gameData.userInfo.userId,d.gameData.userInfo.userPw);
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end

else
wait:Remove();
local mc2=showPopup(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\237\129\180\235\157\188\236\154\176\235\147\156\235\161\156\235\147\156?"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
userDB.LoadData(d.gameData);
for i=1,const("\236\160\128\236\158\165\236\138\172\235\161\175\236\136\152"),1 do

userDB.SaveSlotData(d.slotData[i],i);
end

myInfo=nil;
userDB.Save(true);
LoadLang();
PlayBGM();
TryConnect(function()
root:GotoAndStop("loading");
end);
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
end
end
sendCommand("loadgame");
end

local function SSave()
local function save()
TryConnect(function()
if not myInfo.linkid then
showMsg(owner,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\234\179\132\236\160\149\235\147\177\235\161\157\235\168\188\236\160\128")).onClose=function()
register();
end
else
local onFailed=function(s)
end
local onComplete=function(s)
if s.status=="ok"then
userDB.option.__dirtySlots={};
userDB.Save();
local mc=showMsg(owner,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\236\160\128\236\158\165 \236\132\177\234\179\181"));
mc.onClose=function()
GSave(true);
end
else
showMsg(owner,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[s.status]or _L("\237\129\180\235\157\188\236\154\176\235\147\156\236\160\128\236\158\165 \236\139\164\237\140\168"));
end
end
HttpWaitAsync(owner,
sendGameData(onComplete,onFailed,makeSaveData(),makeSlotData(true),"save"),
lang.waitLoginInfo);
end
end);
end
local mc2=showPopup(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\237\129\180\235\157\188\236\154\176\235\147\156\236\160\128\236\158\165?"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
save();
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end

end
local function SLoad()
TryConnect(function()
if not myInfo.linkid then
showMsg(owner,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\234\179\132\236\160\149\235\147\177\235\161\157\235\168\188\236\160\128")).onClose=function()
register();
end
else
local onFailed=function(s)
end
local onComplete=function(s)
if s.status=="ok"then
local mc0=showPopup(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc0.txt:SetText(_L("\237\129\180\235\157\188\236\154\176\235\147\156\235\161\156\235\147\156?"));
SetButton(mc0.btnOk).onClick=function()
mc0:Remove();
if loadSaveData(s)then

myInfo=nil;
userDB.option.__dirtySlots={};
userDB.Save(true);
LoadLang();
PlayBGM();
TryConnect(function()
root:GotoAndStop("loading");
end);
end
end
SetButton(mc0.btnCancel).onClick=function()
mc0:Remove();
end
else
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[s.status]or _L("\237\129\180\235\157\188\236\154\176\235\147\156\235\161\156\235\147\156 \236\139\164\237\140\168"));
end
end
HttpWaitAsync(owner,
sendGameData(onComplete,onFailed,makeSaveData(),makeSlotData(true),"load"),
lang.waitLoginInfo);
end
end);
end
if owner.btnSavegame then
SetTextButton(owner.btnSavegame,_L("\237\129\180\235\157\188\236\154\176\235\147\156 \236\160\128\236\158\165")).onClick=function()
local mc=showPopup(world,"\237\129\180\235\157\188\236\154\176\235\147\156\237\140\157\236\151\133");
mc.title:SetText(_L("\237\129\180\235\157\188\236\154\176\235\147\156 \236\160\128\236\158\165"));
if _Z.IOS then
SetTextButton(mc.btnGSave,_L("\236\149\160\237\148\140")).onClick=function()
mc:Remove();
GSave();
end
else
SetTextButton(mc.btnGSave,_L("\234\181\172\234\184\128")).onClick=function()
mc:Remove();
GSave();
end
end
SetTextButton(mc.btnSSave,_L("\237\154\140\236\155\144 \234\179\132\236\160\149")).onClick=function()
mc:Remove();
SSave();
end
SetButton(mc.btnClose).onClick=function(self)
mc:Remove();
end
end
end
if owner.btnLoadgame then
SetTextButton(owner.btnLoadgame,_L("\237\129\180\235\157\188\236\154\176\235\147\156 \235\161\156\235\147\156")).onClick=function()
local mc=showPopup(world,"\237\129\180\235\157\188\236\154\176\235\147\156\237\140\157\236\151\133");
mc.title:SetText(_L("\237\129\180\235\157\188\236\154\176\235\147\156 \235\161\156\235\147\156"));
if _Z.IOS then
SetTextButton(mc.btnGSave,_L("\236\149\160\237\148\140")).onClick=function()
mc:Remove();
GLoad();
end
else
SetTextButton(mc.btnGSave,_L("\234\181\172\234\184\128")).onClick=function()
mc:Remove();
GLoad();
end
end
SetTextButton(mc.btnSSave,_L("\237\154\140\236\155\144 \234\179\132\236\160\149")).onClick=function()
mc:Remove();
SLoad();
end
SetButton(mc.btnClose).onClick=function(self)
mc:Remove();
end
end
end

if owner.btnAccount then
SetTextButton(owner.btnAccount,_L("\236\160\145\236\134\141 \236\160\149\235\179\180")).onClick=function()
TryConnect(function()
local owner=showPopup(world,"\236\160\145\236\134\141\236\160\149\235\179\180\237\140\157\236\151\133");
owner.txt:SetText(myInfo.linkid or myInfo.guid);
SetButton(owner.btnOk).onClick=function(self)
owner:Remove();
end
owner.btnChangePW:SetVisible(myInfo.linkid);
SetTextButton(owner.btnChangePW,_L("\236\149\148\237\152\184 \235\179\128\234\178\189")).onClick=function()
local mc=showPopup(world,"\235\185\132\235\178\136\235\179\128\234\178\189\237\140\157\236\151\133",{size={x=0,y=0,cy=APP_H*0.9}});
SetEditBox(mc.editPw,mc.editPw.txt,true);
SetEditBox(mc.editPw2,mc.editPw2.txt,true);
SetButton(mc.btnClose2).onClick=function(self)
mc:Remove();
end
SetButton(mc.btnOk).onClick=function(self)
self.parent.editPw:close();
self.parent.editPw2:close();
local pw=mc.editPw:GetText();
local pw2=mc.editPw2:GetText();
local onFailed=function(s)
trace("fail");
end
local onComplete=function(s)
if s.status=="ok"then
mc:Remove();
showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\235\185\132\235\178\136\235\179\128\234\178\189\236\132\177\234\179\181"));
else
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\235\185\132\235\178\136\235\179\128\234\178\189\236\139\164\237\140\168"));
end
end
HttpWaitAsync(mc,
sendChangePw(onComplete,onFailed,md5.sumhexa(pw),md5.sumhexa(pw2)),
lang.waitLoginInfo);
end
end
SetTextButton(owner.btnChangeAccount,_L("\234\179\132\236\160\149 \235\179\128\234\178\189")).onClick=function()
local function login()
local mc=showPopup(world,"\234\179\132\236\160\149\235\179\128\234\178\189\237\140\157\236\151\133",{size={x=0,y=0,cy=APP_H*0.9}});
SetEditBox(mc.editId,mc.editId.txt);
SetEditBox(mc.editPw,mc.editPw.txt,true);
SetButton(mc.btnOk).onClick=function(self)
self.parent.editId:close();
self.parent.editPw:close();
if string.len(self.parent.editId:GetText())<4 then
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang.invalid_idtype);
elseif string.len(self.parent.editPw:GetText())<4 then
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang.invalid_pwtype);
else
local id=mc.editId:GetText();
local pw=mc.editPw:GetText();
local onFailed=function(s)
trace("fail");
end
local onComplete=function(s)
if s.status=="ok"then
mc:Remove();
if loadSaveData(s,true)then
myInfo=nil;
userDB.option.__dirtySlots={};
if s.user then
userDB.SetUserInfo("userId",s.user.guid);
userDB.SetUserInfo("userPw",s.user.pw);
userDB.SetUserInfo("linkid",s.user.linkid);
end
userDB.Save(true);
LoadLang();
PlayBGM();
TryConnect(function()
root:GotoAndStop("loading");
end);
end
elseif s.status=="already_changed"then
local msg=_L(s.status);
msg=msg..string.format("(%02d:%02d)",math.floor(s.rtime/3600),math.floor(s.rtime/60)%60);
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",msg);
else
showMsg(mc,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L(s.status));
end
end
HttpWaitAsync(mc,
ChangeAccount(onComplete,onFailed,id,md5.sumhexa(pw)),
lang.waitLoginInfo);
end
end

SetTextButton(mc.btnFindPw,_L("\236\149\148\237\152\184 \236\176\190\234\184\176")).onClick=function(self)
self.parent.editId:close();
self.parent.editPw:close();
FindPassword();
end

SetButton(mc.btnClose2).onClick=function(self)
mc:Remove();

end
end

local mc2=showPopup(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\234\179\132\236\160\149\235\179\128\234\178\189?"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
login();
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
end

if owner.btnCoupon then
owner.btnCoupon:SetVisible(userDB.option.bcoupon==1);
SetTextButton(owner.btnCoupon,_L("\236\191\160\237\143\176 \236\158\133\235\160\165")).onClick=function()
local mc=showPopup(world,"\236\191\160\237\143\176\236\158\133\235\160\165\237\140\157\236\151\133",{size={x=0,y=0,cy=APP_H*0.9}});
SetEditBox(mc.editid,mc.editid.txt);
mc.editid:SetText("");

mc.editid.onEndEdit=function(this,msg)
end
SetButton(mc.btnClose).onClick=function(self)
mc:Remove();
end
SetTextButton(mc.btnOk,_L("\236\160\156\236\182\156")).onClick=function(self)
self.parent.editid:close();
TryConnect(function()
local onS=function(t)
local mc2=showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y");
if t.status=="ok"then
mc:Remove();
mc2.txt:SetText(_L("\236\191\160\237\143\176 \236\130\172\236\154\169\236\151\144 \236\132\177\234\179\181\237\150\136\236\138\181\235\139\136\235\139\164."));
elseif t.status=="expired"then
mc2.txt:SetText(_L("\235\167\140\235\163\140\235\144\156 \236\191\160\237\143\176\236\158\133\235\139\136\235\139\164."));
elseif t.status=="used"then
mc2.txt:SetText(_L("\236\157\180\235\175\184 \236\130\172\236\154\169\235\144\156 \236\191\160\237\143\176\236\158\133\235\139\136\235\139\164."));
elseif t.status=="invalid_id"then
mc2.txt:SetText(_L("\236\158\152\235\170\187\235\144\156 \236\191\160\237\143\176 \235\178\136\237\152\184\236\158\133\235\139\136\235\139\164."));
end
end
local onF=function()
end
HttpWaitAsync(mc,
sendCoupon(mc.editid:GetText(),onS,onF),
lang.waitLoginInfo);
end);
end
end
end
end);
end
end


if owner.btnLang then
SetTextButton(owner.btnLang,_L("\236\150\184\236\150\180 \235\179\128\234\178\189")).onClick=function()
local mc=showPopup(world,"\236\150\184\236\150\180\235\179\128\234\178\189\237\140\157\236\151\133");
local list={ko="\237\149\156\234\181\173\236\150\180",en="\236\152\129\236\150\180",th="\237\131\156\234\181\173\236\150\180",ja="\236\157\188\235\179\184\236\150\180",vi="\235\178\160\237\138\184\235\130\168\236\150\180",pt="\237\143\172\235\165\180\237\136\172\234\176\136\236\150\180",id="\236\157\184\235\143\132\235\132\164\236\139\156\236\149\132\236\150\180",ru="\235\159\172\236\139\156\236\149\132\236\150\180",zh="\236\164\145\234\181\173\236\150\180(\235\178\136\236\178\180)",de="\235\143\133\236\157\188\236\150\180",fr="\237\148\132\235\158\145\236\138\164\236\150\180",es="\236\138\164\237\142\152\236\157\184\236\150\180"};
for k,v in pairs(list)do
local btn=mc["btn_"..k];
if btn then
SetTextButton(btn,_L(v)).onClick=function(self)
userDB.option.lang=k;
userDB.Save();
LoadLang();
root:GotoAndStop("loading");
end
btn.check:SetVisible(k==curLang);
end
end

SetButton(mc.btnClose).onClick=function(self)
mc:Remove();
end
end
end
if owner.btnCredit then
SetTextButton(owner.btnCredit,_L("\237\129\172\235\160\136\235\148\167")).onClick=function()
root:GotoAndStop("credit");
end
end

SetTextButton(owner.btnClose,"OK").onClick=function(self)
userDB.Save();
owner:Remove();
if fps~=userDB.option.fpsSpeed then
userDB.option.fpsSpeed=fps;
userDB.ResetFps();
end
end
end