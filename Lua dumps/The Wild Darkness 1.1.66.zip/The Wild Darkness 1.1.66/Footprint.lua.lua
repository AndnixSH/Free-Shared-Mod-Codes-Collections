Footprint=Object:new({
})

function Footprint:init(guid,sdata,...)
do
local tb=objecttable[sdata.id];
local cx,cy=world.ground:MapToScreenVector(sdata.monster[2]-sdata.x,sdata.monster[3]-sdata.y);


if cx>0 then
sdata.a="left";
else
sdata.a="right";
end
if cy>0 then
sdata.skin=tb.skin[1];
else
sdata.skin=tb.skin[2];
end
end
Object.init(self,guid,sdata,...);
end

function Footprint:canTouch()
end

function Footprint:onResetTurn(AP)
if AP>0 then
if self.sdata.npcGuid then

if not world:findCharac(self.sdata.npcGuid)then
self:die();
end
else

if world.ground:inLOS(self.tile.x,self.tile.y)then
self.sdata.npcGuid=SpawnMonster(self.sdata.monster[2],self.sdata.monster[3],nil,nil,self.sdata.monster[1]);
end
end
end
end
