--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2017 TianJi Information Technology Inc.
--

require "app.easy.bind.effect"
require "app.easy.bind.scroll"
