--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2016 TianJi Information Technology Inc.
--
-- Capture
--

local Capture = class("Capture", require("app.models.base"))

return Capture