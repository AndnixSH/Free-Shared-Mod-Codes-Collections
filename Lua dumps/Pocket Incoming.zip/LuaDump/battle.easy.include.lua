--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2019 TianJi Information Technology Inc.
--


globals.battleEasy = {}

require "battle.easy.func"
require "battle.easy.effect"
require "battle.easy.pos"
require "battle.easy.damage"
require "battle.easy.log"