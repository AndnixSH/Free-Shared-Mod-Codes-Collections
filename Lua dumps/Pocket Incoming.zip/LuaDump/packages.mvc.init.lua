--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2017 TianJi Information Technology Inc.
--
local _M = {}

_M.AppBase  = require("packages.mvc.AppBase")
_M.ViewBase = require("packages.mvc.ViewBase")

return _M
