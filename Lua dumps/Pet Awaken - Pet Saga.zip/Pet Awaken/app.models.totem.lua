--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2016 TianJi Information Technology Inc.
--
-- Totem
--

local Totem = class("Totem", require("app.models.base"))

return Totem