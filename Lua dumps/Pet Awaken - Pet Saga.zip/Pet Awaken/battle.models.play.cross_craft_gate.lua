

local CrossCraftGateRecord = class("CrossCraftGateRecord", battlePlay.CraftGateRecord)
battlePlay.CrossCraftGateRecord = CrossCraftGateRecord

-- 战斗模式设置 全自动
CrossCraftGateRecord.OperatorArgs = {
	isAuto 			= true,
	isFullManual 	= false,
	canHandle 		= false,
	canPause 		= false,
	canSpeedAni 	= true,
	canSkip 		= true,
}

function CrossCraftGateRecord:init(data)
	self.isFinal = true
	battlePlay.Gate.init(self, data)

	self.backUp = {{},{}} -- 存roleOut 初始化
	self.waveResultList = {} --每轮次的结果 {1,2,1,2,1}
	self.loserRoleOut = {{},{}} --被淘汰的

	self:playStartAni()
end

function CrossCraftGateRecord:makeEndViewInfos()
	local ratio = csv.cross.craft.base[1].damageScoreRatio
	local score,enemyScore = 0,0
	local tb = self.scene.extraRecord:getEvent(battle.ExRecordEvent.score)
	if tb then
		tb[1] = tb[1] or 0
		tb[2] = tb[2] or 0
		score = math.floor(tb[1] / ratio)
		enemyScore = math.floor(tb[2] / ratio)
	end
	self.score = score
	self.enemyScore = enemyScore
	return {result = self.result,score = self.score}
end