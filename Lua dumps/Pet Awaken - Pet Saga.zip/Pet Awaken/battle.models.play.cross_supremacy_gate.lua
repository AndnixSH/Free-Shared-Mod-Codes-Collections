local CrossSupremacyGate = class("CrossSupremacyGate", battlePlay.CrossMineGate)
battlePlay.CrossSupremacyGate = CrossSupremacyGate

CrossSupremacyGate.SpecEndRuleCheck = {
	battle.EndSpecialCheck.HpRatioCheck,
	battle.EndSpecialCheck.ForceNum,
}

-- 世界锦标赛
function CrossSupremacyGate:init(data)
	battlePlay.CrossMineGate.init(self, data)
end

function CrossSupremacyGate:postEndResultToServer(cb)
	if self.hasPost then
		return
	end
	self.hasPost = true
	local endInfos = self:makeEndViewInfos()

	gRootViewProxy:raw():postEndResultToServer("/game/cross/supremacy/battle/end", function(tb)
		if tb then
			local score = tb.view.score + tb.view.score_move
			-- 分数数据 lerp, limit
			--[[
					score	old		delta	new
					1.		10		10		20
					2.		10		40		50 up 0/(100-50)
					3.		10		-10		0
					4.		60		-50		10 down 10/(100-50)
			]]
			endInfos.preData = {lerp = tb.view.score, score = tb.view.score, limit = 0}
			endInfos.curData = {lerp = score, score = score, limit = 0}

			local function collect(v, data)
				if data.tag then return end
				if v.score > data.score then
					data.limit = v.score
				else
					data.lerp = data.score - v.score
					data.limit = data.limit - v.score
					data.rankScore = v.score
					data.stageName = v.stageName
					data.stageLevel = v.stageLevel
					data.stagePinyin = v.stagePinyin
					data.tag = true
				end
			end

			for i, v in orderCsvPairs(csv.cross.supremacy.grade) do
				collect(v, endInfos.curData)
				collect(v, endInfos.preData)
			end
			endInfos.teamScore = {0 ,0}
			for k, v in ipairs(endInfos.waveResult) do
				endInfos.teamScore[v] = endInfos.teamScore[v] + 1
			end
			-- 分数补充
			local winforce = endInfos.result == "win" and 1 or 2
			endInfos.teamScore[winforce] = endInfos.teamScore[winforce] + 1
		end
		cb(endInfos, tb)
	end, endInfos.result, self:isTopBattle(endInfos))
end

function CrossSupremacyGate:checkRoundLimit()
	local _, result = self:specialEndCheck()
	return true, result == "win" and 1 or 2
end

-- 跨服资源战pvp战报
local CrossSupremacyGateRecord = class("CrossSupremacyGateRecord", battlePlay.CrossSupremacyGate)
battlePlay.CrossSupremacyGateRecord = CrossSupremacyGateRecord

-- 战斗模式设置 手动
CrossSupremacyGateRecord.OperatorArgs = {
	isAuto 			= true,
	isFullManual 	= false,
	canHandle 		= false,
	canPause 		= true,
	canSpeedAni 	= true,
	canSkip 		= true,
}