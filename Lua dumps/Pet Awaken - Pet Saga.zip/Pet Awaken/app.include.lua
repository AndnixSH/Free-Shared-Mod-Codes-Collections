--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2017 TianJi Information Technology Inc.
--

require "app.defines.include"
require "app.servers.include"
require "app.easy.include"

require "app.sdk.init"
require "app.guarder.init"

