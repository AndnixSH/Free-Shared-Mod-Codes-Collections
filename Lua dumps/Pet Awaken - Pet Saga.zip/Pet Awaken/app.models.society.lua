-- @Date:   2018-10-23
-- @Desc:


local Society = class("Society", require("app.models.base"))

return Society