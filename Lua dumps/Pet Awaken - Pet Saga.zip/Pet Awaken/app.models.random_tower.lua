--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2016 TianJi Information Technology Inc.
--
-- RandomTower
--

local RandomTower = class("RandomTower", require("app.models.base"))

return RandomTower