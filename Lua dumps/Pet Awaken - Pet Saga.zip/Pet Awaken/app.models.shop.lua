-- @Date:   2018-10-29
-- @Desc:
-- @Last Modified time: 2018-10-29
local Shop = class("Shop", require("app.models.base"))

return Shop