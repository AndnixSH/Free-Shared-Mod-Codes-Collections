local languagePlist = cc.FileUtils:getInstance():getValueMapFromFile('res/language.plist')
globals.LOCAL_LANGUAGE = languagePlist.localization or 'cn'
print('LOCAL_LANGUAGE', LOCAL_LANGUAGE)

globals.LanguageTexts = {
	cn = {
		checkUpdate = '请稍等...',
		downloading = '正在下载安装中... 文件数量: %d / %d  文件大小: %dK / %dK',
		downloadingM = '正在下载安装中... 文件数量: %d / %d  文件大小: %.2fM / %.2fM',
		-- noConnected = '无法连接，QQ群283206793',
		noConnected = '无法更新, 请检查你的网络',
		reConnect = '剩余%d个文件未更新，是否重试？',
		unzipFailed = '解压失败',
		oldApp = '版本过旧\n需要重新下载最新的客户端',
		loginUpdating = '登录服务器正在更新中，请稍等',
		umcompress = '进入游戏中，请稍等',
		wifiTip = '当前处于非WIFI环境，本次更新文件大小为 %0.2fM，确定消耗流量进行更新？',
		loadTips = {
			"小提示：升级可以提升战斗力哦",
			"小提示：记得给好友赠送一波体力",
			"小提示：精灵等级不能超过玩家的等级哦",
		},
		placardActivity = '活动公告',
		placardUpdate = '更新内容',
	},
	tw = {
		checkUpdate = '请稍等...',
		downloading = '正在下载安装中... 文件数量:%6d / %6d  文件大小:%7dK / %7dK',
		downloadingM = '正在下载安装中... 文件数量: %d / %d  文件大小: %.2fM / %.2fM',
		noConnected = '无法连接',
		reConnect = '请重新连接',
		unzipFailed = '解压失败',
		oldApp = '版本过旧\n需要重新下载最新的客户端',
		loginUpdating = '登录服务器正在更新中，请稍等',
		umcompress = '進入遊戲中,請稍等',
		wifiTip = '資源較大，請在wifi環境下下載資源 土豪請隨意',
		loadTips = {
			"小提示：升級可以提升戰鬥力哦",
		},
	},
	en = {
		checkUpdate = 'please wait...',
		downloading = 'downloading... file:%6d / %6d  size:%7dK / %7dK',
		downloadingM = 'downloading... file:%6d / %6d  size:%7dM / %7dM',
		noConnected = 'no network',
		reConnect = 'please retry connect',
		unzipFailed = 'uncompress failed',
		oldApp = 'old client version\nplease download new client',
		loginUpdating = 'server updateing, please wait a moment',
		umcompress = 'Enter the game, please wait',
		wifiTip = 'your network not in WIFI, are you confirm to update?',
		loadTips = {
			"Tip: Level up can makes you stronger.",
		},
	},
	vn = {
		checkUpdate = 'please wait...',
		downloading = 'downloading... file:%6d / %6d  size:%7dK / %7dK',
		downloadingM = 'downloading... file:%6d / %6d  size:%7dM / %7dM',
		noConnected = 'no network',
		reConnect = 'please retry connect',
		unzipFailed = 'uncompress failed',
		oldApp = 'old client version\nplease download new client',
		loginUpdating = 'server updateing, please wait a moment',
		umcompress = 'Enter the game, please wait',
		wifiTip = 'your network not in WIFI, are you confirm to update?',
		loadTips = {
			"Tiểu đề bày ra: Thăng cấp có thể tăng lên sức chiến đấu a",
		},
	},
}
globals.Language = LanguageTexts[LOCAL_LANGUAGE]
if Language == nil then
	Language = LanguageTexts.cn
end
Language = setmetatable(Language, {__index = function()
	return "text_placeholder"
end})