-- 连线特效管理
local LinkEffect = class('LinkEffect', battleModule.CBase)

function LinkEffect:ctor(parent)
	battleModule.CBase.ctor(self, parent)

	self.lines = {}
	self.pos = {}
	self.kPos = {}

	self.caster2Keys = {}
	self.isShow = true

	self.updateObjKey = nil
	self.updateObjNode = nil
	self.lastx = 0
	self.lasty = 0
end

function LinkEffect:alterLine(objKey1, objKey2, line, scaleX)
	if not (self.pos[objKey1] and self.pos[objKey2]) then
		return
	end

	local x1 = self.pos[objKey1][1] + self.kPos[objKey1].x
	local y1 = self.pos[objKey1][2] + self.kPos[objKey1].y
	local x2 = self.pos[objKey2][1] + self.kPos[objKey2].x
	local y2 = self.pos[objKey2][2] + self.kPos[objKey2].y

	local len = math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2))
	if line.boxWidth == 0 then
		line.boxWidth = line:getBoundingBox().width
	end
	local _scaleX = scaleX * (len / line.boxWidth)

	local p = {}
	p.x = x1 - x2
	p.y = y1 - y2
	local r = math.atan2(p.y, p.x)*180/math.pi

	line:scaleX(_scaleX):setRotation(-r)
end

function LinkEffect:refreshByObj(objKey)
	for key, data in pairs(self.lines) do
		local newKey = self:tryGetCaster(data.casterKey)
		if newKey == objKey or data.holderKey == objKey then
			self:alterLine(newKey, data.holderKey, data.line, data.scaleX)
		end
	end
end

function LinkEffect:checkObjMove()
	local pos = self.pos[self.updateObjKey]
	if not pos then
		return false
	end
	local x, y = pos[1], pos[2]
	if x ~= self.lastx or y ~= self.lasty then
		self.lastx, self.lasty = x, y
		return true
	end
	return false
end

function LinkEffect:onUpdate(delta)
	if not (self.updateObjKey and self.isShow and self:checkObjMove()) then
		return
	end

	self:refreshByObj(self.updateObjKey)
end

--{effectRes = "buff/lianjie/hero_yipeiertaer.skel";aniName =  "effect_lianjiexian_loop"; deep = 12; offsetPos = {'x'=0;'y'=0}}
function LinkEffect:onAddLinkEffect(holderKey, casterKey, cfg, buffId)
	local key = buffId
	if self.lines[key] then
		return
	end

	local effectRes = cfg.effectRes
	local aniName = cfg.aniName
	local offsetPos = cfg.offsetPos
	local deep = cfg.deep
	local scaleX = cfg.scaleX or 1
	local holderSpr = self:call('getSceneObj', holderKey)

	offsetPos = offsetPos and cc.p(offsetPos.x, offsetPos.y) or cc.p(0, 0)
	if holderSpr.force == 2 then
		offsetPos = cc.p(-offsetPos.x, offsetPos.y)
	end
	local effectPos = holderSpr.unitCfg.everyPos.hitPos
	effectPos = cc.pAdd(effectPos, offsetPos)

	local newLine = newCSpriteWithOption(effectRes)
	newLine:addTo(holderSpr, deep)
	newLine:setPosition(effectPos)
	newLine:play(aniName)
	newLine:setVisible(self.isShow)
	newLine.boxWidth = 0

	self.kPos[holderKey] = effectPos
	self:savePosition(holderSpr, holderKey)
	self.lines[key] = {
		line = newLine,
		buffId = buffId,
		holderKey = holderKey,
		casterKey = casterKey,
		scaleX = scaleX
	}

	self.caster2Keys[casterKey] = self.caster2Keys[casterKey] or {}
	if holderKey == casterKey then
		table.insert(self.caster2Keys[casterKey], 1, key)
	else
		table.insert(self.caster2Keys[casterKey], key)
	end

	local newKey = self:tryGetCaster(casterKey)
	self:refreshByObj(newKey)

	performWithDelay(newLine, function()
		local tmpKey = self:tryGetCaster(casterKey)
		newLine.boxWidth = newLine:getBoundingBox().width
		self:alterLine(tmpKey, holderKey, newLine, scaleX)
	end, 0)
end

function LinkEffect:onDelLinkEffect(buffId)
	local key = buffId
	if not self.lines[key] then
		return
	end

	local tmpCasterKey = self.lines[key].casterKey
	if self.caster2Keys[tmpCasterKey] then
		for k, objKey in ipairs(self.caster2Keys[tmpCasterKey]) do
			if objKey == key then
				table.remove(self.caster2Keys[tmpCasterKey], k)
				break
			end
		end
	end

	self.pos[self.lines[key].holderKey] = nil
	self.kPos[self.lines[key].holderKey] = nil
	local line = self.lines[key].line
	removeCSprite(line)
	self.lines[key] = nil

	self:refreshByObj(self:tryGetCaster(tmpCasterKey))
end

function LinkEffect:onShowLinkEffect(isShow)
	if isShow == self.isShow then
		return
	end
	self.isShow = isShow
	for k, v in pairs(self.lines) do
		v.line:setVisible(isShow)
	end
end

function LinkEffect:onDoShiftPos(objKey)
	local spr = self:call('getSceneObj', objKey)
	self:savePosition(spr, objKey)
	self:refreshByObj(objKey)
end

function LinkEffect:onUpdateLinkEffect(needUpdate, objKey)
	local spr = self:call('getSceneObj', objKey)
	if needUpdate then
		if spr then
			local linkShadow = cc.Node:new()
			spr:addChild(linkShadow, 1, "linkShadow")
			self.updateObjNode = linkShadow
			self.updateObjKey = objKey
			self.updateObjNode:scheduleUpdate(function()
				self:savePosition(spr, objKey)
			end)
			self.updateObjNode:registerScriptHandler(function(state)
				if state == "cleanup" and self.updateObjNode == linkShadow then
					self.updateObjNode = nil
				end
			end)
		end
	elseif objKey == self.updateObjKey then
		if self.updateObjNode then
			self.updateObjNode:unscheduleUpdate()
			self.updateObjNode:removeFromParent()
		end
		self.updateObjKey = nil
		self.updateObjNode = nil
		self.lastx = 0
		self.lasty = 0
		if spr then
			self:savePosition(spr, objKey)
		end
		self:refreshByObj(objKey)
	end
end

function LinkEffect:tryGetCaster(objKey)
	local key = self.caster2Keys[objKey] and self.caster2Keys[objKey][1]
	if key and self.lines[key] then
		return self.lines[key].holderKey
	end
end

function LinkEffect:savePosition(spr, objKey)
	if not (spr and objKey) then
		return
	end
	if self.updateObjKey == objKey then
		self.pos[objKey] = {spr:xy()}
	else
		self.pos[objKey] = {spr:getSelfPos()}
	end
end

return LinkEffect