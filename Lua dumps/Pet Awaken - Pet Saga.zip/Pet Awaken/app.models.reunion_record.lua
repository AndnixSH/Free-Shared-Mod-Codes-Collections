-- @Date: 2020-10-20
-- @Desc:


local ReunionRecord = class("ReunionRecord", require("app.models.base"))

return ReunionRecord