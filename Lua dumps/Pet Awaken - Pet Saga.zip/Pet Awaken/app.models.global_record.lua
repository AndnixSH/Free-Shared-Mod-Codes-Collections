--
-- Copyright (c) 2014 YouMi Information Technology Inc.
-- Copyright (c) 2016 TianJi Information Technology Inc.
--
-- GlobalRecord
--

local GlobalRecord = class("GlobalRecord", require("app.models.base"))

return GlobalRecord